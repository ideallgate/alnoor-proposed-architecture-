#!/bin/bash
# Independent cross-check with wrk (c=100, 8 threads, 30 s) for every stack in $STACKS.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
. "$ROOT/env.sh"
[ -n "$WRK" ] || { echo "wrk not installed" >&2; exit 3; }
BASE=http://127.0.0.1:8080
IFS=, read -r -a STACK_LIST <<< "$STACKS"
ENDPOINTS=(health radio_now hadith); PATHS=(/health /radio/now /hadith/4242)
OUT="$ROOT/results/wrk_summary.csv"
mkdir -p "$ROOT/results/wrk"
[ -f "$OUT" ] || echo 'stack,endpoint,concurrency,duration,rps,p50,p95,p99' > "$OUT"
for stack in "${STACK_LIST[@]}"; do
 "$ROOT/benchctl" "$stack"; sleep 3
 for i in 0 1 2; do
  endpoint="${ENDPOINTS[$i]}"; file="$ROOT/results/wrk/$stack/$endpoint.txt"; mkdir -p "$(dirname "$file")"
  "$WRK" -t8 -c100 -d30s --latency "$BASE${PATHS[$i]}" > "$file" 2>&1 || true
  "$PYTHON" - "$stack" "$endpoint" "$file" "$OUT" <<'PY'
import csv,re,sys
stack,endpoint,raw,out=sys.argv[1:]
s=open(raw).read(); rate=re.search(r'Requests/sec:\s*([0-9.]+)',s)
pct={int(a):b.strip() for a,b in re.findall(r'^\s*(\d+)%\s+(.+)$',s,re.M)}
with open(out,'a',newline='') as f: csv.writer(f).writerow([stack,endpoint,100,'30s',rate.group(1) if rate else '',pct.get(50,''),pct.get(95,''),pct.get(99,'')])
PY
 done
 "$ROOT/benchctl" stop
done
