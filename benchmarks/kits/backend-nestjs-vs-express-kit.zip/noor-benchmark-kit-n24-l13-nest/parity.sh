#!/bin/bash
# Correctness gate: every stack must return the same JSON. Run before any benchmark.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
. "$ROOT/env.sh"
OUT="$ROOT/results/parity"; rm -rf "$OUT"; mkdir -p "$OUT"
IFS=, read -r -a stacks <<< "$STACKS"
case ",$STACKS," in *,node,*) ;; *) stacks=(node "${stacks[@]}");; esac   # node is the reference
for stack in "${stacks[@]}"; do
  "$ROOT/benchctl" "$stack"
  for route in health radio/now hadith/42 hadith/20000 hadith/999999; do
    file="$OUT/${stack}_$(echo "$route" | tr '/' '_').json"
    code=$(curl -sS -o "$file" -w '%{http_code}' "http://127.0.0.1:8080/$route")
    case "$route" in hadith/999999) expected=404;; *) expected=200;; esac
    if [ "$code" != "$expected" ]; then echo "$stack $route expected $expected got $code" >&2; "$ROOT/benchctl" stop; exit 1; fi
  done
done
"$ROOT/benchctl" stop
for route in hadith_42.json hadith_20000.json; do
  for stack in "${stacks[@]}"; do [ "$stack" = node ] || diff -u "$OUT/node_$route" "$OUT/${stack}_$route"; done
done
"$PYTHON" - "$OUT" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1])
for route in ['hadith_42.json','hadith_20000.json']:
 for f in p.glob('*_'+route):
  data=json.loads(f.read_text())
  assert len(data['riwayat'])==3
  assert isinstance(data['riwayat'][0]['text'],str) and 'حَدَّثَنَا' in data['riwayat'][0]['text']
radio=[]
for f in p.glob('*_radio_now.json'):
 d=json.loads(f.read_text()); assert set(d)=={'current','position_s','next'}
 assert isinstance(d['position_s'],int) and 0 <= d['position_s'] < d['current']['duration_s']
 radio.append({k:d[k] for k in ('current','next')})
assert all(x==radio[0] for x in radio), 'radio current/next records differ'
print('PARITY OK: hadith bodies byte-identical; radio shape and records match')
PY
