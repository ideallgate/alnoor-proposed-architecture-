#!/usr/bin/env python3
"""Run the local native benchmark; no Docker involvement."""
import csv, os, re, shlex, statistics, subprocess, sys, time, shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent
RESULTS=ROOT/'results'; RAW=RESULTS/'raw'; BASE='http://127.0.0.1:8080'
STACKS=os.getenv('STACKS','node,nest-express,nest-fastify,node-cluster,laravel-fpm,laravel-fpm-persistent,laravel-octane').split(',')
ENDPOINTS={'health':'/health','radio_now':'/radio/now','hadith':'/hadith/4242'}
CONCURRENCIES=[int(x) for x in os.getenv('CONCURRENCIES','100,500,1000,1500').split(',')]
RUNS=int(os.getenv('RUNS','5')); REQUESTS=int(os.getenv('REQUESTS','20000')); WARMUP=int(os.getenv('WARMUP','2000')); PAUSE=int(os.getenv('PAUSE','10'))
AB=os.getenv('AB') or shutil.which('ab') or '/usr/sbin/ab'; SAMPLE_FILE=RESULTS/'resource_samples.csv'; OUTCSV=RESULTS/'results.csv'

def parse_ab(text,expected=0,returncode=0):
 def num(pat, default=0.0):
  m=re.search(pat,text,re.M); return float(m.group(1).replace(',','')) if m else default
 pct={int(a):float(b) for a,b in re.findall(r'^\s*(\d+)%\s+([0-9.]+)',text,re.M)}
 failed=num(r'Failed requests:\s*(\d+)',-1)
 if failed<0:
  complete=re.search(r'Complete requests:\s*([0-9,]+)',text) or re.search(r'Total of\s*([0-9,]+) requests completed',text)
  done=int(complete.group(1).replace(',','')) if complete else 0
  failed=max(0,expected-done)
  if returncode and failed==0: failed=1
 return {'rps':num(r'Requests per second:\s*([0-9.]+)'), 'mean':num(r'Time per request:\s*([0-9.]+)'),
         'p50':pct.get(50,''),'p95':pct.get(95,''),'p99':pct.get(99,''),
         'failed':failed,'non2xx':num(r'Non-2xx responses:\s*(\d+)')}

PREV_CPU={}; PREV_TS=None

def cpu_seconds(value):
 value=value.strip(); days=0
 if '-' in value:
  daypart,value=value.split('-',1); days=int(daypart)
 parts=value.split(':')
 if len(parts)==3: hours,minutes,seconds=int(parts[0]),int(parts[1]),float(parts[2])
 elif len(parts)==2: hours,minutes,seconds=0,int(parts[0]),float(parts[1])
 else: hours,minutes,seconds=0,0,float(parts[0])
 return days*86400+hours*3600+minutes*60+seconds

def sample():
 global PREV_CPU, PREV_TS
 p=subprocess.run(['ps','-axo','pid,cputime,rss,command'],text=True,capture_output=True,check=True)
 app_rss=db_rss=0.0; current={}; kinds={}
 for line in p.stdout.splitlines()[1:]:
  x=line.strip().split(None,3)
  if len(x)<4: continue
  try: pid=int(x[0]); cpu=cpu_seconds(x[1]); rss=float(x[2])/1024
  except ValueError: continue
  cmd=x[3].lower()
  is_db=('postgres' in cmd and ('postgresql@16' in cmd or '/postgresql/' in cmd or cmd.startswith('postgres: ')))
  is_app=(('node' in cmd and (str(ROOT/'node/server.js').lower() in cmd or str(ROOT/'nest/dist/main-').lower() in cmd)) or 'php-fpm' in cmd or 'nginx: worker' in cmd or 'rr serve' in cmd or ('artisan octane:start' in cmd) or str(ROOT/'laravel/vendor/bin/roadrunner-worker').lower() in cmd)
  if is_db: db_rss+=rss; current[pid]=cpu; kinds[pid]='db'
  if is_app: app_rss+=rss; current[pid]=cpu; kinds[pid]='app'
 now=time.monotonic(); app_cpu=db_cpu=0.0
 if PREV_TS is not None:
  elapsed=max(now-PREV_TS,0.001)
  for pid,value in current.items():
   if pid in PREV_CPU:
    delta=max(0.0,value-PREV_CPU[pid]); utilization=delta/elapsed*100
    if kinds[pid]=='app': app_cpu+=utilization
    else: db_cpu+=utilization
 PREV_CPU=current; PREV_TS=now
 return app_cpu,app_rss,db_cpu,db_rss

def run_wrk(stack,endpoint,path):
 if not shutil.which('wrk'): return
 folder=RESULTS/'wrk'/stack; folder.mkdir(parents=True,exist_ok=True)
 duration=os.getenv('WRK_DURATION','30s')
 cmd=['wrk','-t8','-c100',f'-d{duration}','--latency',BASE+path]
 proc=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 raw=folder/f'{endpoint}.txt'; raw.write_text(proc.stdout)
 rate=re.search(r'Requests/sec:\s*([0-9.]+)',proc.stdout)
 pct={int(a):b.strip() for a,b in re.findall(r'^\s*(\d+)%\s+(.+)$',proc.stdout,re.M)}
 out=RESULTS/'wrk_summary.csv'; new=not out.exists()
 with out.open('a',newline='') as f:
  w=csv.writer(f)
  if new:w.writerow(['stack','endpoint','concurrency','duration','rps','p50','p90','p99'])
  w.writerow([stack,endpoint,100,duration,float(rate.group(1)) if rate else '',pct.get(50,''),pct.get(90,''),pct.get(99,'')])
 if proc.returncode: print(f'wrk exited {proc.returncode}; see {raw}',file=sys.stderr)

def run_ab(n,c,target,raw=None,sampling=False):
 cmd=[AB,'-k','-l','-n',str(n),'-c',str(c),target]
 if sampling:
  samples=[]
  proc=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  while proc.poll() is None:
   vals=sample(); samples.append(vals)
   with SAMPLE_FILE.open('a',newline='') as f:
    w=csv.writer(f)
    if f.tell()==0: w.writerow(['timestamp','stack','endpoint','concurrency','run','app_cpu_pct','app_rss_mb','postgres_cpu_pct','postgres_rss_mb'])
    w.writerow([time.time(),current_stack,current_endpoint,current_concurrency,current_run,*vals])
   time.sleep(1)
  text=proc.stdout.read(); rc=proc.wait()
 else:
  q=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT); text=q.stdout; rc=q.returncode; samples=[]
 if raw: raw.write_text(text)
 if rc: print(f'ab exited {rc} for {target}; see {raw}',file=sys.stderr)
 return parse_ab(text,n,rc),samples,text

RESULTS.mkdir(exist_ok=True); RAW.mkdir(exist_ok=True)
if os.getenv('RESET_RESULTS')=='1':
 if RAW.exists(): shutil.rmtree(RAW)
 RAW.mkdir(parents=True,exist_ok=True)
 for file in [OUTCSV,SAMPLE_FILE,RESULTS/'memory_idle.csv',RESULTS/'soak.csv',RESULTS/'wrk_summary.csv',RESULTS/'queue.csv',RESULTS/'audio/ffmpeg.csv',RESULTS/'audio/queue.csv']:
  file.unlink(missing_ok=True)
 for sub in [RAW,RESULTS/'wrk']:
  if sub.exists(): shutil.rmtree(sub)
 audio_dir=RESULTS/'audio'
 if audio_dir.exists():
  for file in audio_dir.glob('*.mp3'): file.unlink(missing_ok=True)
if not OUTCSV.exists():
 with OUTCSV.open('w',newline='') as f: csv.writer(f).writerow(['stack','endpoint','concurrency','run','rps','mean','p50','p95','p99','failed','non2xx'])
for stack_index,stack in enumerate(STACKS):
 if stack_index and int(os.getenv('STACK_PAUSE','35'))>0:
  print(f'Cooling down {os.getenv("STACK_PAUSE","35")} seconds for macOS local TCP ports.',flush=True)
  time.sleep(int(os.getenv('STACK_PAUSE','35')))
 print(f'=== {stack} ===',flush=True)
 subprocess.run([str(ROOT/'benchctl'),stack],check=True)
 # Warm the process and connection path before sampling idle memory.
 time.sleep(3)
 idle=sample()
 with (RESULTS/'memory_idle.csv').open('a',newline='') as f:
  w=csv.writer(f)
  if f.tell()==0:w.writerow(['stack','app_rss_mb','postgres_rss_mb','app_cpu_pct','postgres_cpu_pct'])
  w.writerow([stack,idle[1],idle[3],idle[0],idle[2]])
 for endpoint,path in ENDPOINTS.items():
  folder=RAW/stack/endpoint
  for c in CONCURRENCIES:
   for run in range(1,RUNS+1):
    current_stack,current_endpoint,current_concurrency,current_run=stack,endpoint,c,run
    print(f'{stack} {endpoint} c={c} run={run}/{RUNS}',flush=True)
    warm,_,_=run_ab(WARMUP,50,BASE+path)
    raw=folder/f'c{c}'/f'run{run}.txt'; raw.parent.mkdir(parents=True,exist_ok=True)
    metrics,samples,_=run_ab(REQUESTS,c,BASE+path,raw=raw,sampling=True)
    with OUTCSV.open('a',newline='') as f:
     csv.writer(f).writerow([stack,endpoint,c,run,metrics['rps'],metrics['mean'],metrics['p50'],metrics['p95'],metrics['p99'],metrics['failed'],metrics['non2xx']])
    if metrics['failed'] or metrics['non2xx']:
     print(f'ERRORS: {metrics["failed"]} failed; {metrics["non2xx"]} non-2xx',flush=True)
    if run<RUNS: time.sleep(PAUSE)
 if int(os.getenv('SOAK_SECONDS','600'))>0:
  seconds=int(os.getenv('SOAK_SECONDS','600')); current_stack,current_endpoint,current_concurrency,current_run=stack,'radio_now',200,'soak'
  start=sample(); began=time.monotonic(); deadline=began+seconds; requests=failed=non2xx=0; chunks=[]
  while time.monotonic()<deadline:
   p=subprocess.run([AB,'-k','-l','-n','50000','-c','200',BASE+'/radio/now'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
   chunks.append(p.stdout)
   m=re.search(r'Complete requests:\s*([0-9,]+)',p.stdout); requests+=int(m.group(1).replace(',','')) if m else 0
   m=re.search(r'Failed requests:\s*(\d+)',p.stdout); failed+=int(m.group(1)) if m else 0
   m=re.search(r'Non-2xx responses:\s*(\d+)',p.stdout); non2xx+=int(m.group(1)) if m else 0
  elapsed=time.monotonic()-began; end=sample()
  raw_soak=RAW/stack/'radio_now'/'soak.txt'; raw_soak.parent.mkdir(parents=True,exist_ok=True); raw_soak.write_text('\n\n'.join(chunks))
  soakfile=RESULTS/'soak.csv'; new=not soakfile.exists()
  with soakfile.open('a',newline='') as f:
   w=csv.writer(f)
   if new:w.writerow(['stack','duration_s','requests','errors','start_rss_mb','end_rss_mb','failed','non2xx'])
   w.writerow([stack,round(elapsed,2),requests,failed+non2xx,start[1],end[1],failed,non2xx])
 subprocess.run([str(ROOT/'benchctl'),'stop'],check=False)
if os.getenv('CROSSCHECK_WRK','1')=='1' and shutil.which('wrk'):
 for stack in STACKS:
  print(f'=== wrk cross-check: {stack} ===',flush=True)
  subprocess.run([str(ROOT/'benchctl'),stack],check=True)
  time.sleep(3)
  for endpoint,path in ENDPOINTS.items(): run_wrk(stack,endpoint,path)
  subprocess.run([str(ROOT/'benchctl'),'stop'],check=False)
if os.getenv('RUN_AUDIO','1')=='1':
 subprocess.run([str(ROOT/'run_ffmpeg.sh')],check=True)
 subprocess.run([str(ROOT/'run_queues.sh')],check=True)
print(f'Data written to {OUTCSV}',flush=True)
subprocess.run([sys.executable,str(ROOT/'report.py')],check=False)
