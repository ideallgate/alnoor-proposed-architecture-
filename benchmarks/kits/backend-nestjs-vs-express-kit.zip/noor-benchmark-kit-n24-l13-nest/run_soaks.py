#!/usr/bin/env python3
"""Run ten-minute native soaks by chaining AB's 50k-request maximum batches."""
import csv, os, subprocess, sys, time
from pathlib import Path
ROOT=Path(__file__).resolve().parent; R=ROOT/'results'; AB=os.getenv('AB') or __import__('shutil').which('ab') or '/usr/sbin/ab'
stacks=os.getenv('STACKS','node,nest-express,nest-fastify,node-cluster,laravel-fpm,laravel-fpm-persistent,laravel-octane').split(',')
seconds=int(os.getenv('SOAK_SECONDS','600')); outcsv=R/'soak.csv'; rawroot=R/'raw'
def app_rss():
 p=subprocess.run(['ps','-axo','rss,command'],text=True,capture_output=True,check=True); total=0
 for line in p.stdout.splitlines()[1:]:
  try: kb,cmd=line.strip().split(None,1)
  except ValueError: continue
  c=cmd.lower()
  if (('node' in c and (str(ROOT/'node/server.js').lower() in c or str(ROOT/'nest/dist/main-').lower() in c)) or 'php-fpm' in c or 'nginx: worker' in c or 'rr serve' in c or 'artisan octane:start' in c or str(ROOT/'laravel/vendor/bin/roadrunner-worker').lower() in c): total+=int(kb)
 return total/1024
if os.getenv('APPEND')!='1' or not outcsv.exists():
 with outcsv.open('w',newline='') as f: csv.writer(f).writerow(['stack','duration_s','requests','errors','start_rss_mb','end_rss_mb','failed','non2xx'])
for stack in stacks:
 print(f'=== {stack} soak {seconds}s ===',flush=True)
 subprocess.run([str(ROOT/'benchctl'),stack],check=True); time.sleep(3)
 start=app_rss(); began=time.monotonic(); deadline=began+seconds; requests=failed=non2xx=0; next_progress=30; raw=rawroot/stack/'radio_now'/'soak.txt';raw.parent.mkdir(parents=True,exist_ok=True); raw.write_text('duration_s,requests,failed,non2xx,rps\n'); batches=0
 while time.monotonic()<deadline:
  batches+=1
  p=subprocess.run([AB,'-k','-l','-n','50000','-c','200','http://127.0.0.1:8080/radio/now'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  import re
  with raw.open('a') as rawf:
   vals=[]
   for pat in (r'Time taken for tests:\s*([0-9.]+) seconds',r'Complete requests:\s*([0-9,]+)',r'Failed requests:\s*(\d+)',r'Non-2xx responses:\s*(\d+)',r'Requests per second:\s*([0-9.]+)'):
    m=re.search(pat,p.stdout); vals.append(m.group(1).replace(',','') if m else '0')
   rawf.write(','.join(vals)+'\n')
  m=re.search(r'Complete requests:\s*([0-9,]+)',p.stdout); requests+=int(m.group(1).replace(',','')) if m else 0
  m=re.search(r'Failed requests:\s*(\d+)',p.stdout); failed+=int(m.group(1)) if m else max(0,50000-requests)
  m=re.search(r'Non-2xx responses:\s*(\d+)',p.stdout); non2xx+=int(m.group(1)) if m else 0
  elapsed=time.monotonic()-began
  if elapsed>=next_progress: print(f'{stack}: soak active; elapsed ~{int(elapsed)}s, requests={requests}',flush=True); next_progress+=30
 elapsed=time.monotonic()-began; end=app_rss()
 with outcsv.open('a',newline='') as f: csv.writer(f).writerow([stack,round(elapsed,2),requests,failed+non2xx,round(start,2),round(end,2),failed,non2xx])
 subprocess.run([str(ROOT/'benchctl'),'stop'],check=False)
 print(f'{stack}: completed {elapsed:.1f}s, {requests} requests, {failed+non2xx} errors in {batches} batches',flush=True)
