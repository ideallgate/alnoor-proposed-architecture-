<?php
header('Content-Type: application/json; charset=utf-8');
$dsn='pgsql:host='.getenv('DB_HOST').';port=5432;dbname=noor';
$pdo=new PDO($dsn,'bench','bench',[PDO::ATTR_PERSISTENT=>true,PDO::ATTR_EMULATE_PREPARES=>false,PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
$path=parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
function send($v,$status=200){http_response_code($status);$body=json_encode($v,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);header('Content-Length: '.strlen($body));echo $body;}
if($path==='/health'){send(['ok'=>true]);exit;}
if($path==='/radio/now'){
 $offset=time()%2096700;
 $s=$pdo->prepare('SELECT id,title,duration_s,starts_at_s,audio_url FROM radio_items WHERE starts_at_s <= ? ORDER BY starts_at_s DESC LIMIT 1');$s->execute([$offset]);$c=$s->fetch(PDO::FETCH_ASSOC);
 $s=$pdo->prepare('SELECT id,title,audio_url FROM (SELECT id,title,audio_url,starts_at_s FROM radio_items WHERE starts_at_s > ? ORDER BY starts_at_s LIMIT 1) a UNION ALL SELECT id,title,audio_url FROM (SELECT id,title,audio_url FROM radio_items ORDER BY starts_at_s LIMIT 1) b LIMIT 1');$s->execute([$offset]);$n=$s->fetch(PDO::FETCH_ASSOC);send(['current'=>$c,'position_s'=>$offset-$c['starts_at_s'],'next'=>$n]);exit;
}
if(preg_match('#^/hadith/(\d+)$#',$path,$m)){
 $s=$pdo->prepare("SELECT h.id,h.number,h.book_id,h.chapter_id, rw.id AS riwaya_id, rw.source, rw.grade, rw.text_ar, rw.is_default, ra.id AS rawi_id, ra.name AS rawi_name, ra.tabaqa FROM hadith h JOIN riwaya rw ON rw.hadith_id=h.id JOIN rawi ra ON ra.id=rw.rawi_id WHERE h.id=? AND h.status='published' ORDER BY rw.is_default DESC, rw.id");$s->execute([(int)$m[1]]);$rows=$s->fetchAll(PDO::FETCH_ASSOC);if(!$rows){send(['error'=>'not found'],404);exit;}$f=$rows[0];$out=['id'=>(int)$f['id'],'number'=>(int)$f['number'],'book_id'=>(int)$f['book_id'],'chapter_id'=>(int)$f['chapter_id'],'riwayat'=>[]];foreach($rows as $x)$out['riwayat'][]=['id'=>(int)$x['riwaya_id'],'source'=>$x['source'],'grade'=>$x['grade'],'text'=>$x['text_ar'],'default'=>(bool)$x['is_default'],'rawi'=>['id'=>(int)$x['rawi_id'],'name'=>$x['rawi_name'],'tabaqa'=>$x['tabaqa']]];send($out);exit;
}
send(['error'=>'not found'],404);
