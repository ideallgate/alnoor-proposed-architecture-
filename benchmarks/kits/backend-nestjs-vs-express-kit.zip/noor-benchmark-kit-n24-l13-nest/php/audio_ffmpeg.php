<?php
[$script,$input,$outputDir,$repeat]=array_pad($argv,4,'1');
$csv=$outputDir.'/ffmpeg.csv';
if(!file_exists($csv))file_put_contents($csv,"runner,group,job,seconds,peak_rss_mb\n");
for($group=1;$group<=(int)$repeat;$group++)for($job=1;$job<=3;$job++){
 $output=$outputDir."/php-$group-$job.mp3";
 $cmd='ffmpeg -y -loglevel error -i '.escapeshellarg($input).' -af '.escapeshellarg('loudnorm=I=-16:TP=-1.5:LRA=11,silenceremove=start_periods=1:start_threshold=-50dB').' -b:a 64k '.escapeshellarg($output).' 2>&1';
 $start=hrtime(true);exec($cmd,$unused,$code);$seconds=(hrtime(true)-$start)/1e9;
 if($code!==0)throw new RuntimeException("ffmpeg failed ($code)");
 file_put_contents($csv,sprintf("php,%d,%d,%.4f,\n",$group,$job,$seconds),FILE_APPEND);
}
