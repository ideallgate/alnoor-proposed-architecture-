Reference output of the ORIGINAL run: Apple M1 8 GB, macOS, Node 22, Laravel 12.x, Octane on RoadRunner, native (no Docker). Kept for rough comparison only.
