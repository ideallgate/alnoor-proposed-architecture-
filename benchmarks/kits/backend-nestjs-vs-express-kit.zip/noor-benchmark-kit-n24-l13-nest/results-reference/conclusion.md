# Conclusion

- health, c=100: php fastest (30606.3 req/s). Difference is not significant (under 10% or within run-to-run spread).
- health, c=500: node-cluster fastest (42599.7 req/s).
- health, c=1000: node-cluster fastest (35039.0 req/s).
- health, c=1500: node-cluster fastest (35531.4 req/s).
- radio_now, c=100: node-cluster fastest (12002.6 req/s). Difference is not significant (under 10% or within run-to-run spread).
- radio_now, c=500: node-cluster fastest (11892.9 req/s). Difference is not significant (under 10% or within run-to-run spread).
- radio_now, c=1000: node fastest (10329.9 req/s). Difference is not significant (under 10% or within run-to-run spread).
- radio_now, c=1500: node-cluster fastest (11459.9 req/s). Difference is not significant (under 10% or within run-to-run spread).
- hadith, c=100: php fastest (12473.1 req/s).
- hadith, c=500: node-cluster fastest (11364.8 req/s).
- hadith, c=1000: node-cluster fastest (12322.5 req/s). Difference is not significant (under 10% or within run-to-run spread).
- hadith, c=1500: node-cluster fastest (11311.6 req/s). Difference is not significant (under 10% or within run-to-run spread).
- PHP-FPM and Laravel-FPM had frequent non-2xx responses from c=500; reported throughput at those levels includes errors and is not successful capacity. Their c=100 runs completed without errors.
- Octane-to-FPM gap at c=1000 for health is not comparable because Laravel-FPM had non-2xx responses.
- Octane-to-FPM gap at c=1000 for radio_now is not comparable because Laravel-FPM had non-2xx responses.
- Octane-to-FPM gap at c=1000 for hadith is not comparable because Laravel-FPM had non-2xx responses.

135 measured runs had request failures or non-2xx responses; 360 measured runs are included.

Caveats: native macOS cannot enforce per-app CPU or memory caps, its listen backlog is capped at 128, and the host load generator shares CPU with PostgreSQL and the active app.
