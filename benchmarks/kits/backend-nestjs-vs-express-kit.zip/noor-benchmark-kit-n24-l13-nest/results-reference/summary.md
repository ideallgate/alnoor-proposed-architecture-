# Benchmark summary

Raw measured runs: 360. Median across available runs; raw results are in `results.csv`.

## Throughput and latency

Values are median req/s; p50/p95/p99 in milliseconds; errors = failed requests / non-2xx responses. Throughput includes error responses; treat it as successful capacity only when both error counts are zero.

| Stack | Endpoint | c=100 | c=500 | c=1000 | c=1500 |
|---|---|---|---|---|---|
| node | health | 17704.93 (16417.52–18184.18); 5.00/7.00/9.00; 0/0 | 16385.59 (16081.02–17600.85); 29.00/36.00/45.00; 0/0 | 17485.44 (15915.89–17832.69); 55.00/64.00/70.00; 0/0 | 17626.39 (16683.07–17915.59); 81.00/97.00/114.00; 0/0 |
| node | radio_now | 10656.71 (9566.67–10842.54); 9.00/11.00/14.00; 0/0 | 10272.69 (9556.32–10465.01); 47.00/57.00/68.00; 0/0 | 10329.87 (9808.13–10567.94); 94.00/108.00/111.00; 0/0 | 10181.24 (7899.42–10315.76); 140.00/160.00/178.00; 0/0 |
| node | hadith | 9683.95 (8952.30–9769.78); 10.00/13.00/15.00; 0/0 | 8863.92 (8369.36–9607.26); 51.00/67.00/76.00; 0/0 | 9469.22 (8227.08–9792.58); 102.00/125.00/132.00; 0/0 | 9200.26 (8233.38–9600.82); 154.00/178.00/199.00; 0/0 |
| node-cluster | health | 28681.52 (24324.83–38069.13); 2.00/10.00/25.00; 0/0 | 42599.69 (37024.01–44310.33); 9.00/26.00/42.00; 0/0 | 35039.03 (29861.44–45798.45); 22.00/59.00/86.00; 0/0 | 35531.43 (28464.97–42839.40); 34.00/85.00/114.00; 0/0 |
| node-cluster | radio_now | 12002.63 (9596.78–12087.54); 6.00/21.00/86.00; 0/0 | 11892.92 (10127.23–13291.18); 31.00/118.00/159.00; 0/0 | 9960.28 (9868.68–11747.34); 65.00/233.00/296.00; 0/0 | 11459.93 (9534.60–12338.83); 109.00/252.00/279.00; 0/0 |
| node-cluster | hadith | 11124.32 (10594.39–12723.76); 5.00/18.00/71.00; 0/0 | 11364.77 (9331.64–12073.20); 30.00/146.00/172.00; 0/0 | 12322.54 (8263.10–13435.03); 64.00/172.00/232.00; 0/0 | 11311.60 (7115.66–12134.76); 110.00/263.00/309.00; 0/0 |
| php | health | 30606.26 (29032.97–36672.22); 3.00/5.00/6.00; 0/0 | 54273.64 (49703.52–60203.06); 4.00/26.00/87.00; 0/92877 | 56555.81 (46048.89–58506.56); 13.00/40.00/136.00; 0/96981 | 54899.81 (49150.56–57565.72); 16.00/66.00/119.00; 0/98101 |
| php | radio_now | 10596.51 (10328.21–10844.41); 9.00/12.00/16.00; 0/0 | 57175.37 (50548.45–58765.46); 4.00/22.00/115.00; 0/97397 | 53515.71 (49868.97–58164.05); 9.00/47.00/127.00; 0/98167 | 50163.41 (47308.84–55922.47); 15.00/72.00/96.00; 0/98482 |
| php | hadith | 12473.10 (12086.72–13030.24); 8.00/10.00/13.00; 0/0 | 53943.40 (51680.25–55734.53); 4.00/25.00/126.00; 0/97273 | 53334.47 (50841.55–57817.34); 9.00/48.00/124.00; 0/98272 | 53807.99 (47491.95–55039.86); 17.00/71.00/96.00; 0/98519 |
| laravel-fpm | health | 2931.05 (2840.50–3002.58); 32.00/47.00/69.00; 0/0 | 34566.73 (30349.20–36465.01); 7.00/51.00/137.00; 0/95482 | 36296.78 (32050.87–37180.25); 17.00/77.00/143.00; 0/95850 | 36347.18 (34855.65–42457.53); 30.00/85.00/157.00; 0/96522 |
| laravel-fpm | radio_now | 801.12 (756.21–861.40); 118.00/163.00/197.00; 0/0 | 34888.97 (32627.39–39231.15); 6.00/14.00/68.00; 0/99040 | 36745.05 (32117.27–40138.72); 13.00/34.00/72.00; 0/99134 | 34435.68 (30979.51–37872.05); 21.00/51.00/114.00; 0/99120 |
| laravel-fpm | hadith | 744.83 (630.19–795.09); 128.00/186.00/235.00; 0/0 | 33908.88 (30282.29–37018.87); 6.00/15.00/51.00; 0/98979 | 35197.57 (34563.33–37400.44); 14.00/33.00/165.00; 0/99032 | 35986.04 (33143.48–39068.30); 21.00/53.00/100.00; 0/99165 |
| laravel-fpm-persistent | health | 3002.52 (2872.28–3062.63); 31.00/44.00/63.00; 0/0 | 30081.29 (27825.39–35965.92); 5.00/66.00/176.00; 0/96676 | 36093.46 (28960.03–36812.48); 8.00/115.00/243.00; 0/96478 | 36497.82 (29154.99–40363.84); 22.00/126.00/190.00; 0/96135 |
| laravel-fpm-persistent | radio_now | 2136.77 (2037.25–2344.07); 43.00/67.00/83.00; 0/0 | 41689.68 (39473.42–42197.65); 6.00/20.00/168.00; 0/98203 | 42591.61 (31203.68–44316.03); 13.00/46.00/203.00; 0/98587 | 38846.79 (37995.15–41779.12); 22.00/87.00/169.00; 0/98674 |
| laravel-fpm-persistent | hadith | 2017.98 (1792.25–2185.39); 47.00/65.00/85.00; 0/0 | 39755.42 (37673.37–42338.53); 7.00/20.00/186.00; 0/98188 | 42639.10 (39688.13–48564.44); 14.00/45.00/158.00; 0/98409 | 42661.66 (37103.14–44295.22); 21.00/64.00/146.00; 0/98703 |
| laravel-octane | health | 2933.62 (2438.79–3157.75); 31.00/55.00/88.00; 0/0 | 2672.82 (2265.45–2729.56); 179.00/291.00/355.00; 0/0 | 2588.27 (2408.49–2662.76); 367.00/489.00/550.00; 0/0 | 2643.17 (2249.62–2865.25); 540.00/683.00/711.00; 0/0 |
| laravel-octane | radio_now | 2192.65 (2079.14–2278.65); 42.00/66.00/82.00; 0/0 | 2033.31 (1877.09–2193.83); 235.00/339.00/390.00; 0/0 | 1842.40 (1655.68–1923.97); 525.00/708.00/732.00; 0/0 | 1894.96 (1648.88–2190.88); 785.00/971.00/1002.00; 0/0 |
| laravel-octane | hadith | 2172.83 (2089.12–2231.34); 42.00/75.00/101.00; 0/0 | 2073.39 (1653.81–2254.00); 237.00/336.00/491.00; 0/0 | 1932.68 (1864.60–1953.28); 499.00/691.00/717.00; 0/0 | 1953.77 (1871.36–1991.13); 754.00/920.00/974.00; 0/0 |

## Relative throughput vs Node (single process)

| Endpoint | Concurrency | node | node-cluster | php | laravel-fpm | laravel-fpm-persistent | laravel-octane |
|---|---|---|---|---|---|---|---|
| health | 100 | 100.0% | 162.0% | 172.9% | 16.6% | 17.0% | 16.6% |
| health | 500 | 100.0% | 260.0% | — | — | — | 16.3% |
| health | 1000 | 100.0% | 200.4% | — | — | — | 14.8% |
| health | 1500 | 100.0% | 201.6% | — | — | — | 15.0% |
| radio_now | 100 | 100.0% | 112.6% | 99.4% | 7.5% | 20.1% | 20.6% |
| radio_now | 500 | 100.0% | 115.8% | — | — | — | 19.8% |
| radio_now | 1000 | 100.0% | 96.4% | — | — | — | 17.8% |
| radio_now | 1500 | 100.0% | 112.6% | — | — | — | 18.6% |
| hadith | 100 | 100.0% | 114.9% | 128.8% | 7.7% | 20.8% | 22.4% |
| hadith | 500 | 100.0% | 128.2% | — | — | — | 23.4% |
| hadith | 1000 | 100.0% | 130.1% | — | — | — | 20.4% |
| hadith | 1500 | 100.0% | 122.9% | — | — | — | 21.2% |

## Memory and CPU

RSS is process RSS summed by stack; CPU is host process CPU percent. Resource profiles were refreshed separately with one 20,000-request run per endpoint at c=100 and c=1,000, using a corrected PostgreSQL process matcher. The load generator and app share the Mac.

| Stack | Idle RSS MB | Avg RSS MB | Peak sampled RSS MB | App CPU c=100 | App CPU c=1000 | PostgreSQL RSS avg / peak MB | PostgreSQL CPU c=100 / c=1000 |
|---|---:|---:|---:|---:|---:|---:|---:|
| node | 48.25 | 141.55 | 156.77 | 72.52 | 80.67 | 77.59 / 116.91 | 70.26 / 72.31 |
| node-cluster | 413.58 | 731.62 | 779.77 | 263.25 | 235.75 | 63.38 / 110.14 | 93.06 / 99.84 |
| php | 68.81 | 114.98 | 120.86 | 178.85 | 111.87 | 108.83 / 124.11 | 136.33 / 21.86 |
| laravel-fpm | 37.11 | 207.34 | 217.11 | 205.26 | 106.65 | 7.89 / 8.69 | 30.29 / 4.39 |
| laravel-fpm-persistent | 45.97 | 212.30 | 222.81 | 458.92 | 169.13 | 65.53 / 114.03 | 38.54 / 5.32 |
| laravel-octane | 314.14 | 465.81 | 561.56 | 361.04 | 347.71 | 76.16 / 121.38 | 32.09 / 31.25 |

Charts omit any stack/concurrency group that had request failures or non-2xx responses.

## Soak test

| Stack | Duration | Requests | Errors | Start RSS MB | End RSS MB |
|---|---:|---:|---:|---:|---:|
| node | 600.02 | 6450000 | 0 | 41.14 | 98.27 |
| node-cluster | 601.82 | 6500000 | 0 | 382.34 | 546.28 |
| php | 600.88 | 28450000 | 26908628 | 69.06 | 71.44 |
| laravel-fpm | 600.86 | 29100000 | 28880808 | 53.55 | 208.77 |
| laravel-fpm-persistent | 600.88 | 31400000 | 30907185 | 90.39 | 207.25 |
| laravel-octane | 604.76 | 1250000 | 0 | 337.17 | 442.94 |

## FFmpeg and queue workloads

| Workload | Runs / jobs | Concurrency | Total seconds | Median job seconds | Peak RSS MB | Errors |
|---|---:|---:|---:|---:|---:|---:|
| node CLI | 9 | 1 | 130.22 | 14.46 | not sampled | — |
| php CLI | 9 | 1 | 131.00 | 14.53 | not sampled | — |
| node-bullmq queue | 20 | 2 | 148.818 | — | 61.9 | 0 |
| laravel-redis queue | 20 | 2 | 149.199 | — | 95.3 | 0 |

## wrk cross-check

wrk ran separately at c=100, eight threads, keep-alive defaults, fixed hadith id 4242. Values are not mixed into ApacheBench results.

| Stack | Endpoint | Req/s | p50 ms | p90 ms | p99 ms |
|---|---|---:|---:|---:|---:|
| laravel-fpm | hadith | 837.88 | 134.56 | 150.58 | 189.31 |
| laravel-fpm | health | 3492.0 | 25.86 | 31.92 | 61.99 |
| laravel-fpm | radio_now | 877.88 | 104.34 | 129.25 | 156.07 |
| laravel-fpm-persistent | hadith | 2371.97 | 39.01 | 43.8 | 73.87 |
| laravel-fpm-persistent | health | 3364.77 | 27.09 | 32.43 | 55.09 |
| laravel-fpm-persistent | radio_now | 2302.33 | 40.27 | 46.69 | 67.72 |
| laravel-octane | hadith | 2431.63 | 37.86 | 49.29 | 77.17 |
| laravel-octane | health | 3476.23 | 24.61 | 41.78 | 106.28 |
| laravel-octane | radio_now | 2304.32 | 38.67 | 54.63 | 96.78 |
| node | hadith | 9812.98 | 9.55 | 11.2 | 15.82 |
| node | health | 17998.24 | 5.11 | 6.38 | 8.55 |
| node | radio_now | 10450.47 | 8.87 | 10.5 | 18.49 |
| node-cluster | hadith | 11405.71 | 6.01 | 60.59 | 137.71 |
| node-cluster | health | 44179.01 | 1.86 | 6.28 | 40.72 |
| node-cluster | radio_now | 10692.87 | 6.21 | 57.42 | 135.41 |
| php | hadith | 11364.55 | 7.04 | 12.21 | 22.36 |
| php | health | 32649.11 | 2.78 | 3.76 | 5.07 |
| php | radio_now | 10790.08 | 7.51 | 14.43 | 36.2 |

## Configuration

| Stack | Configuration applied |
|---|---|
| node | Node 22 LTS; Express; pg pool max 10; production; one process |
| node-cluster | Node 22 LTS; 8 workers; aggregate pg pool max 10 (first 2 workers max 2, others max 1); production |
| php | PHP-FPM 8.3 static 10 children; OPcache enabled; persistent PDO; nginx access logs off |
| laravel-fpm | Laravel 12 production; FPM static 10 children; DB::select; cached config/routes/events; default nonpersistent PDO |
| laravel-fpm-persistent | Same as Laravel FPM with PDO persistent enabled |
| laravel-octane | Laravel 12 Octane with RoadRunner 2025.1.15; 10 workers; max 500 requests; no proxy |

Notes: apps ran one at a time. Native macOS does not provide Docker cgroup CPU/memory limits; all processes shared the host CPU and memory. nginx error logging was raised to critical severity for the soak runs after routine 502 logging filled 9.5 GB; the main matrix used the default error level. No values are filled in for unmeasured cases.
