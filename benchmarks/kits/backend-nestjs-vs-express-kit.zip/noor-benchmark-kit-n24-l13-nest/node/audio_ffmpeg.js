const { execFileSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const [input, outputDir, repeat = '1'] = process.argv.slice(2);
const csv = path.join(outputDir, 'ffmpeg.csv');
if (!fs.existsSync(csv)) fs.writeFileSync(csv, 'runner,group,job,seconds,peak_rss_mb\n');
for (let group = 1; group <= Number(repeat); group++) for (let job = 1; job <= 3; job++) {
 const output = path.join(outputDir, `node-${group}-${job}.mp3`);
 const start = process.hrtime.bigint();
 execFileSync('ffmpeg', ['-y','-loglevel','error','-i',input,'-af','loudnorm=I=-16:TP=-1.5:LRA=11,silenceremove=start_periods=1:start_threshold=-50dB','-b:a','64k',output], {stdio:'ignore'});
 const seconds = Number(process.hrtime.bigint()-start)/1e9;
 fs.appendFileSync(csv, `node,${group},${job},${seconds.toFixed(4)},\n`);
}
