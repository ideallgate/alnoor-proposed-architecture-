const express = require('express');
const { Pool } = require('pg');
const cluster = require('cluster');
const os = require('os');
const TOTAL = Number(process.env.TOTAL || 2096700);
if (process.env.CLUSTER === '1' && cluster.isPrimary) {
  for (let i = 0; i < os.cpus().length; i++) cluster.fork({ POOL_MAX: String(i < 2 ? 2 : 1) });
  process.on('SIGTERM', () => { for (const worker of Object.values(cluster.workers)) worker?.kill(); process.exit(0); });
} else {
const pool = new Pool({ host: process.env.DB_HOST || 'postgres', user: 'bench', password: 'bench', database: 'noor', max: Number(process.env.POOL_MAX || (process.env.CLUSTER === '1' ? 1 : 10)) });
const app = express(); app.disable('x-powered-by');
app.get('/health', (_req, res) => res.json({ ok: true }));
app.get('/radio/now', async (_req, res, next) => { try {
 const offset = Math.floor(Date.now()/1000) % TOTAL;
 const cur = await pool.query('SELECT id,title,duration_s,starts_at_s,audio_url FROM radio_items WHERE starts_at_s <= $1 ORDER BY starts_at_s DESC LIMIT 1',[offset]);
 const c=cur.rows[0];
 const nxt=await pool.query('SELECT id,title,audio_url FROM (SELECT id,title,audio_url,starts_at_s FROM radio_items WHERE starts_at_s > $1 ORDER BY starts_at_s LIMIT 1) a UNION ALL SELECT id,title,audio_url FROM (SELECT id,title,audio_url FROM radio_items ORDER BY starts_at_s LIMIT 1) b LIMIT 1',[offset]);
 res.json({current:c,position_s:offset-c.starts_at_s,next:nxt.rows[0]});
 } catch(e){next(e)} });
app.get('/hadith/:id', async (req,res,next)=>{try{
 const r=await pool.query('SELECT h.id,h.number,h.book_id,h.chapter_id, rw.id AS riwaya_id, rw.source, rw.grade, rw.text_ar, rw.is_default, ra.id AS rawi_id, ra.name AS rawi_name, ra.tabaqa FROM hadith h JOIN riwaya rw ON rw.hadith_id=h.id JOIN rawi ra ON ra.id=rw.rawi_id WHERE h.id=$1 AND h.status=\'published\' ORDER BY rw.is_default DESC, rw.id',[req.params.id]);
 if(!r.rows.length)return res.status(404).json({error:'not found'}); const f=r.rows[0];
 res.json({id:f.id,number:f.number,book_id:f.book_id,chapter_id:f.chapter_id,riwayat:r.rows.map(x=>({id:x.riwaya_id,source:x.source,grade:x.grade,text:x.text_ar,default:x.is_default,rawi:{id:x.rawi_id,name:x.rawi_name,tabaqa:x.tabaqa}}))});
 }catch(e){next(e)}});
app.listen(Number(process.env.PORT || 8080),'127.0.0.1');
}
