const { Queue, Worker, QueueEvents } = require('bullmq');
const { execFile } = require('node:child_process');
const { promisify } = require('node:util');
const { setMaxListeners } = require('node:events');
const fs = require('node:fs');
const path = require('node:path');
const execFileAsync = promisify(execFile);
const [input, outputDir, countArg='20'] = process.argv.slice(2);
const count=Number(countArg), queueName='noor-ffmpeg';
const connection={host:'127.0.0.1',port:6379,maxRetriesPerRequest:null};
(async()=>{
 const queue=new Queue(queueName,{connection}); const events=new QueueEvents(queueName,{connection}); setMaxListeners(0,queue,events); await events.waitUntilReady();
 let peak=process.memoryUsage().rss; const timer=setInterval(()=>{peak=Math.max(peak,process.memoryUsage().rss)},100);
 const worker=new Worker(queueName,async job=>{
  const out=path.join(outputDir,`node-queue-${job.id}.mp3`);
  await execFileAsync('ffmpeg',['-y','-loglevel','error','-i',input,'-af','loudnorm=I=-16:TP=-1.5:LRA=11,silenceremove=start_periods=1:start_threshold=-50dB','-b:a','64k',out]);
  return {output:out};
 },{connection,concurrency:2});
 const started=process.hrtime.bigint();
 const jobs=await Promise.all(Array.from({length:count},(_,i)=>queue.add('transcode',{i},{removeOnComplete:false,removeOnFail:false})));
 let errors=0;
 await Promise.all(jobs.map(j=>j.waitUntilFinished(events).catch(()=>{errors++})));
 const seconds=Number(process.hrtime.bigint()-started)/1e9; clearInterval(timer); peak=Math.max(peak,process.memoryUsage().rss);
 await worker.close(); await events.close(); await queue.obliterate({force:true}); await queue.close();
 const csv=path.join(outputDir,'..','queue.csv'); if(!fs.existsSync(csv))fs.writeFileSync(csv,'runner,jobs,concurrency,total_seconds,peak_rss_mb,errors\n');
 fs.appendFileSync(csv,`node-bullmq,${count},2,${seconds.toFixed(3)},${(peak/1048576).toFixed(1)},${errors}\n`);
 console.log(`${count} BullMQ jobs completed in ${seconds.toFixed(2)} seconds; errors=${errors}; peak worker RSS=${(peak/1048576).toFixed(1)} MB`);
})().catch(e=>{console.error(e);process.exit(1)});
