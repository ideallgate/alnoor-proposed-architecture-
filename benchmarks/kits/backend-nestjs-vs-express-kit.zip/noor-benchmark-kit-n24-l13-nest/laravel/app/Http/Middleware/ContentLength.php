<?php
namespace App\Http\Middleware;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
class ContentLength {
 public function handle(Request $request, Closure $next): Response {
  $response=$next($request); $content=$response->getContent();
  if(is_string($content) && !$response->headers->has('Content-Length')) $response->headers->set('Content-Length',(string)strlen($content));
  return $response;
 }
}
