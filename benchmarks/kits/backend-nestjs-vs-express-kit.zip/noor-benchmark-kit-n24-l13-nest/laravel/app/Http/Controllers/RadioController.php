<?php
namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
class RadioController extends Controller {
 private const TOTAL=2096700;
 public function now(){
  $offset=time()%self::TOTAL;
  $current=DB::selectOne('SELECT id,title,duration_s,starts_at_s,audio_url FROM radio_items WHERE starts_at_s <= ? ORDER BY starts_at_s DESC LIMIT 1',[$offset]);
  $next=DB::selectOne('SELECT id,title,audio_url FROM (SELECT id,title,audio_url,starts_at_s FROM radio_items WHERE starts_at_s > ? ORDER BY starts_at_s LIMIT 1) a UNION ALL SELECT id,title,audio_url FROM (SELECT id,title,audio_url FROM radio_items ORDER BY starts_at_s LIMIT 1) b LIMIT 1',[$offset]);
  $c=(array)$current;$n=(array)$next;foreach(['id','duration_s','starts_at_s'] as $k)$c[$k]=(int)$c[$k];foreach(['id'] as $k)$n[$k]=(int)$n[$k];
  return response()->json(['current'=>$c,'position_s'=>$offset-$c['starts_at_s'],'next'=>$n],200,[],JSON_UNESCAPED_UNICODE);
 }
}
