<?php
namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
class HadithController extends Controller {
 public function show(int $id){
  $rows=DB::select("SELECT h.id,h.number,h.book_id,h.chapter_id, rw.id AS riwaya_id, rw.source, rw.grade, rw.text_ar, rw.is_default, ra.id AS rawi_id, ra.name AS rawi_name, ra.tabaqa FROM hadith h JOIN riwaya rw ON rw.hadith_id=h.id JOIN rawi ra ON ra.id=rw.rawi_id WHERE h.id=? AND h.status='published' ORDER BY rw.is_default DESC, rw.id",[$id]);
  if(!$rows)return response()->json(['error'=>'not found'],404);
  $f=(array)$rows[0];$out=['id'=>(int)$f['id'],'number'=>(int)$f['number'],'book_id'=>(int)$f['book_id'],'chapter_id'=>(int)$f['chapter_id'],'riwayat'=>[]];
  foreach($rows as $row){$x=(array)$row;$out['riwayat'][]=['id'=>(int)$x['riwaya_id'],'source'=>$x['source'],'grade'=>$x['grade'],'text'=>$x['text_ar'],'default'=>(bool)$x['is_default'],'rawi'=>['id'=>(int)$x['rawi_id'],'name'=>$x['rawi_name'],'tabaqa'=>$x['tabaqa']]];}
  return response()->json($out,200,[],JSON_UNESCAPED_UNICODE);
 }
}
