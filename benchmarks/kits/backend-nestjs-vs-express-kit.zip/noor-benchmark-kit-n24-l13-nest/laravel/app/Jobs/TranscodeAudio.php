<?php
namespace App\Jobs;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Symfony\Component\Process\Process;
class TranscodeAudio implements ShouldQueue {
 use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;
 public int $tries=1;
 public int $timeout=600;
 public function __construct(public string $input, public string $output) {}
 public function handle(): void {
  (new Process(['ffmpeg','-y','-loglevel','error','-i',$this->input,'-af','loudnorm=I=-16:TP=-1.5:LRA=11,silenceremove=start_periods=1:start_threshold=-50dB','-b:a','64k',$this->output]))->setTimeout(600)->mustRun();
 }
}
