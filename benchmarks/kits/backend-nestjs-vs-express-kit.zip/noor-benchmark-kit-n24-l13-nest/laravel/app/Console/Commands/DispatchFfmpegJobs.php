<?php
namespace App\Console\Commands;
use App\Jobs\TranscodeAudio;
use Illuminate\Console\Command;
class DispatchFfmpegJobs extends Command {
 protected $signature='bench:ffmpeg-dispatch {input} {outputDir} {count=20}';
 protected $description='Dispatch benchmark FFmpeg jobs across two Redis queues';
 public function handle(): int {
  $input=$this->argument('input');$dir=$this->argument('outputDir');$count=(int)$this->argument('count');
  for($i=1;$i<=$count;$i++){ $queue='ffmpeg-'.(($i%2)+1); TranscodeAudio::dispatch($input,$dir.'/laravel-queue-'.$i.'.mp3')->onQueue($queue); }
  $this->info("Dispatched {$count} jobs to two Redis queues."); return self::SUCCESS;
 }
}
