<?php
use App\Http\Controllers\RadioController;
use App\Http\Controllers\HadithController;
use Illuminate\Support\Facades\Route;
Route::get('/health', fn () => response()->json(['ok' => true]));
Route::get('/radio/now', [RadioController::class, 'now']);
Route::get('/hadith/{id}', [HadithController::class, 'show'])->whereNumber('id');
