CREATE TABLE radio_items (
  id serial PRIMARY KEY,
  position int NOT NULL,
  title text NOT NULL,
  duration_s int NOT NULL,
  starts_at_s int NOT NULL,
  audio_url text NOT NULL
);
INSERT INTO radio_items (position,title,duration_s,starts_at_s,audio_url)
SELECT g, 'Hadith lecture '||g, 120 + (g*37 % 600), 0, 'https://cdn.example/audio/'||g||'.mp3' FROM generate_series(1,5000) g;
UPDATE radio_items r SET starts_at_s = c.s FROM (
  SELECT id, COALESCE(SUM(duration_s) OVER (ORDER BY position ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING),0) AS s FROM radio_items) c WHERE c.id=r.id;
CREATE INDEX ON radio_items(starts_at_s);

CREATE TABLE rawi (id serial PRIMARY KEY, name text, tabaqa text, bio text);
CREATE TABLE hadith (id serial PRIMARY KEY, book_id int, chapter_id int, number int, status text DEFAULT 'published');
CREATE TABLE riwaya (id serial PRIMARY KEY, hadith_id int REFERENCES hadith(id), source text, grade text, text_ar text, is_default bool, rawi_id int REFERENCES rawi(id));
INSERT INTO rawi SELECT g, 'Rawi '||g, 'Tabaqa '||(g%12), repeat('bio ',40) FROM generate_series(1,3000) g;
INSERT INTO hadith SELECT g, g%20, g%400, g, 'published' FROM generate_series(1,20000) g;
INSERT INTO riwaya (hadith_id,source,grade,text_ar,is_default,rawi_id)
SELECT h, 'Source '||(r), 'Sahih', repeat('حَدَّثَنَا عَبْدُ اللَّهِ ',12), r=1, (h*7+r)%3000+1 FROM generate_series(1,20000) h, generate_series(1,3) r;
CREATE INDEX ON riwaya(hadith_id);
ANALYZE;
