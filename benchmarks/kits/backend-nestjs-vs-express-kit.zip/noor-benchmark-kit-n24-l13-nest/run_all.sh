#!/bin/bash
# Full matrix (about 5-7 hours with defaults). Overrides: STACKS CONCURRENCIES RUNS REQUESTS WARMUP PAUSE STACK_PAUSE SOAK_SECONDS RUN_AUDIO CROSSCHECK_WRK RESET_RESULTS
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
. "$ROOT/env.sh"
ulimit -n 65535 2>/dev/null || ulimit -n "$(ulimit -Hn)" || true
trap '"$ROOT/benchctl" stop >/dev/null 2>&1 || true' EXIT INT TERM
"$PYTHON" "$ROOT/run_all.py"
