import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { pgPoolProvider } from './pool.provider';

@Module({ controllers: [AppController], providers: [AppService, pgPoolProvider] })
export class AppModule {}
