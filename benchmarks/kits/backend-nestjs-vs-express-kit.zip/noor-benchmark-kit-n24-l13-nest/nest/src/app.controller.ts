import { Controller, Get, HttpException, Param } from '@nestjs/common';
import { AppService } from './app.service';

@Controller()
export class AppController {
  constructor(private readonly svc: AppService) {}

  @Get('health') health() { return this.svc.health(); }

  @Get('radio/now') radioNow() { return this.svc.radioNow(); }

  @Get('hadith/:id') async hadith(@Param('id') id: string) {
    const body = await this.svc.hadith(id);
    if (!body) throw new HttpException({ error: 'not found' }, 404);
    return body;
  }
}
