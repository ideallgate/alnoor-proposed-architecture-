import { Inject, Injectable } from '@nestjs/common';
import { Pool } from 'pg';
import { PG_POOL } from './pool.provider';

const TOTAL = Number(process.env.TOTAL || 2096700);

@Injectable()
export class AppService {
  constructor(@Inject(PG_POOL) private readonly pool: Pool) {}

  health() { return { ok: true }; }

  async radioNow() {
    const offset = Math.floor(Date.now() / 1000) % TOTAL;
    const cur = await this.pool.query('SELECT id,title,duration_s,starts_at_s,audio_url FROM radio_items WHERE starts_at_s <= $1 ORDER BY starts_at_s DESC LIMIT 1', [offset]);
    const c = cur.rows[0];
    const nxt = await this.pool.query('SELECT id,title,audio_url FROM (SELECT id,title,audio_url,starts_at_s FROM radio_items WHERE starts_at_s > $1 ORDER BY starts_at_s LIMIT 1) a UNION ALL SELECT id,title,audio_url FROM (SELECT id,title,audio_url FROM radio_items ORDER BY starts_at_s LIMIT 1) b LIMIT 1', [offset]);
    return { current: c, position_s: offset - c.starts_at_s, next: nxt.rows[0] };
  }

  async hadith(id: string) {
    const r = await this.pool.query('SELECT h.id,h.number,h.book_id,h.chapter_id, rw.id AS riwaya_id, rw.source, rw.grade, rw.text_ar, rw.is_default, ra.id AS rawi_id, ra.name AS rawi_name, ra.tabaqa FROM hadith h JOIN riwaya rw ON rw.hadith_id=h.id JOIN rawi ra ON ra.id=rw.rawi_id WHERE h.id=$1 AND h.status=\'published\' ORDER BY rw.is_default DESC, rw.id', [id]);
    if (!r.rows.length) return null;
    const f = r.rows[0];
    return { id: f.id, number: f.number, book_id: f.book_id, chapter_id: f.chapter_id, riwayat: r.rows.map(x => ({ id: x.riwaya_id, source: x.source, grade: x.grade, text: x.text_ar, default: x.is_default, rawi: { id: x.rawi_id, name: x.rawi_name, tabaqa: x.tabaqa } })) };
  }
}
