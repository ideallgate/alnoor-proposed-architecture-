import { Pool } from 'pg';
export const PG_POOL = 'PG_POOL';
export const pgPoolProvider = {
  provide: PG_POOL,
  useFactory: () => new Pool({ host: process.env.DB_HOST || 'postgres', user: 'bench', password: 'bench', database: 'noor', max: 10 }),
};
