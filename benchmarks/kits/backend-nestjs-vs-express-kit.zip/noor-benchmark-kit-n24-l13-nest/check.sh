#!/bin/bash
# Reports what is installed and what is missing. Exit code 0 = ready for the full benchmark.
ROOT="$(cd "$(dirname "$0")" && pwd)"; . "$ROOT/env.sh"
bad=0
row(){ # label value required(1/0) hint
  if [ -n "$2" ]; then printf '  [ok]   %-12s %s\n' "$1" "$2"
  elif [ "$3" = 1 ]; then printf '  [MISS] %-12s %s\n' "$1" "$4"; bad=1
  else printf '  [skip] %-12s %s\n' "$1" "$4"; fi; }
echo "Platform: $(uname -sm)   cores: $(getconf _NPROCESSORS_ONLN 2>/dev/null)"
echo "Tools:"
row node "$NODE" 1 "need Node 24"
if [ -n "$NODE" ]; then
  nv="$("$NODE" -v 2>&1)"; nrc=$?
  if [ $nrc -ne 0 ] || ! echo "$nv" | grep -q '^v24\.'; then
    echo "  [FAIL] node cannot run or is not v24: ${nv%%$'\n'*}"
    echo "         macOS 'Library not loaded ... libsimdjson': run  brew reinstall simdjson node@24"
    bad=1
  else echo "         $nv"; fi
fi
row php "$PHP" 1 "need PHP 8.3 with pdo_pgsql"; [ -n "$PHP" ] && { pv="$("$PHP" -v 2>&1)" || { echo "  [FAIL] php cannot run: ${pv%%$'\n'*}"; bad=1; }; echo "         ${pv%%$'\n'*}"; "$PHP" -m | grep -qi pdo_pgsql || { echo "  [MISS] php extension pdo_pgsql"; bad=1; }; }
row composer "$(command -v composer)" 1 "https://getcomposer.org"
row php-fpm "$FPM" 1 "needed for laravel-fpm stacks"
row nginx "$NGINX_BIN" 1 "needed for laravel-fpm stacks"
row psql "$PSQL" 1 "PostgreSQL 16 client/server"
row ab "$AB" 1 "ApacheBench (apache2-utils on Debian)"
row wrk "$WRK" 0 "optional cross-check"
row ffmpeg "$(command -v ffmpeg)" 0 "optional audio workload"
row redis "$(command -v redis-server)" 0 "optional queue workload"
echo "Config:"
echo "  DB_HOST=$DB_HOST  NGINX_CONF_DIR=$NGINX_CONF_DIR  STACKS=$STACKS"
if [ -d "$ROOT/laravel/vendor" ] && [ -n "$PHP" ]; then
  echo "  versions: $(cd "$ROOT/laravel" && "$PHP" artisan --version 2>/dev/null | head -1)"
  command -v composer >/dev/null && (cd "$ROOT/laravel" && composer show laravel/framework laravel/octane 2>/dev/null | grep -E '^(name|versions)' | paste - - | sed 's/^/           /')
fi
[ -d "$ROOT/nest/dist" ] && echo "  [ok]   nest build" || { echo "  [MISS] nest build"; bad=1; }
[ -d "$ROOT/node/node_modules" ] && echo "  [ok]   node deps" || { echo "  [MISS] node deps  -> ./setup.sh"; bad=1; }
[ -d "$ROOT/laravel/vendor" ] && echo "  [ok]   laravel deps" || { echo "  [MISS] laravel deps -> ./setup.sh"; bad=1; }
[ -f "$ROOT/laravel/.env" ] && echo "  [ok]   laravel/.env" || { echo "  [MISS] laravel/.env -> ./setup.sh"; bad=1; }
if [ -n "$PSQL" ]; then
  s=$(PGPASSWORD=bench "$PSQL" -h "$DB_HOST" -U bench -d noor -Atc 'SELECT SUM(duration_s) FROM radio_items' 2>/dev/null)
  [ "$s" = 2096700 ] && echo "  [ok]   database seeded (checksum 2096700)" || { echo "  [MISS] database not seeded or unreachable (got '${s}') -> ./setup.sh"; bad=1; }
fi
[ "$bad" = 0 ] && echo "READY" || echo "NOT READY - fix the [MISS] lines"
exit $bad
