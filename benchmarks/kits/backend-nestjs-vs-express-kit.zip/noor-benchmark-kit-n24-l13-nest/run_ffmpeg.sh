#!/bin/bash
# FFmpeg CLI workload: same filter chain launched 3x3 times from Node and from PHP.
# AUDIO_INPUT=/path/to/real_recitation.wav uses your own file instead of the generated one.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
. "$ROOT/env.sh"
OUT="$ROOT/results/audio"; mkdir -p "$OUT"
if [ -n "${AUDIO_INPUT:-}" ]; then cp "$AUDIO_INPUT" "$OUT/in.wav"
else ffmpeg -y -f lavfi -i 'anullsrc=r=44100:cl=stereo' -t 300 -c:a pcm_s16le "$OUT/in.wav"; fi
rm -f "$OUT/ffmpeg.csv"
"$NODE" "$ROOT/node/audio_ffmpeg.js" "$OUT/in.wav" "$OUT" 3
"$PHP" "$ROOT/php/audio_ffmpeg.php" "$OUT/in.wav" "$OUT" 3
