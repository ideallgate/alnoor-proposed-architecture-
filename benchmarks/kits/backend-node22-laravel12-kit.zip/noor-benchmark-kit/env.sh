# Sourced by every script. Detects tool locations; any value can be overridden
# by exporting it before running (e.g. `PHP=/usr/bin/php8.3 ./run_all.sh`).
# shellcheck shell=bash
BENCH_ROOT="${BENCH_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
OS_NAME="$(uname -s)"

# Homebrew prefix (macOS Apple Silicon /opt/homebrew, Intel /usr/local, Linuxbrew)
BREW_PREFIX=""
if command -v brew >/dev/null 2>&1; then BREW_PREFIX="$(brew --prefix)"; fi

# Put versioned Homebrew kegs first on PATH when present.
for k in node@22 php@8.3 postgresql@16; do
  for d in "$BREW_PREFIX/opt/$k/bin" "$BREW_PREFIX/opt/$k/sbin"; do
    [ -n "$BREW_PREFIX" ] && [ -d "$d" ] && PATH="$d:$PATH"
  done
done
export PATH

pick() { # pick CMD... -> first one found on PATH
  for c in "$@"; do if command -v "$c" >/dev/null 2>&1; then command -v "$c"; return 0; fi; done
  return 1
}
# php-fpm is in sbin on Homebrew and has a versioned name on Debian/Ubuntu (php-fpm8.3)
export NODE="${NODE:-$(pick node || true)}"
export PHP="${PHP:-$(pick php8.3 php || true)}"
export FPM="${FPM:-$(pick php-fpm php-fpm8.3 php-fpm8.4 || true)}"
[ -z "$FPM" ] && [ -x /usr/sbin/php-fpm8.3 ] && FPM=/usr/sbin/php-fpm8.3
[ -z "$FPM" ] && [ -x /usr/sbin/php-fpm ] && FPM=/usr/sbin/php-fpm
export FPM
export NGINX_BIN="${NGINX_BIN:-$(pick nginx || true)}"
[ -z "$NGINX_BIN" ] && [ -x /usr/sbin/nginx ] && NGINX_BIN=/usr/sbin/nginx
export NGINX_BIN
export AB="${AB:-$(pick ab || true)}"
[ -z "$AB" ] && [ -x /usr/sbin/ab ] && AB=/usr/sbin/ab
export AB
export WRK="${WRK:-$(pick wrk || true)}"
export PSQL="${PSQL:-$(pick psql || true)}"
export PYTHON="${PYTHON:-$(pick python3 python || true)}"

# nginx's mime.types / fastcgi_params directory
if [ -z "${NGINX_CONF_DIR:-}" ]; then
  for d in "$BREW_PREFIX/etc/nginx" /etc/nginx /usr/local/etc/nginx /opt/homebrew/etc/nginx; do
    [ -f "$d/mime.types" ] && NGINX_CONF_DIR="$d" && break
  done
fi
export NGINX_CONF_DIR="${NGINX_CONF_DIR:-/etc/nginx}"

# php.ini used by php-fpm. Empty = use that PHP build's default.
if [ -z "${PHP_INI:-}" ] && [ -n "$BREW_PREFIX" ] && [ -f "$BREW_PREFIX/etc/php/8.3/php.ini" ]; then
  PHP_INI="$BREW_PREFIX/etc/php/8.3/php.ini"
fi
export PHP_INI="${PHP_INI:-}"

# Database host. Reference run: PostgreSQL via Unix socket in /tmp (Homebrew, trust auth).
# Linux packages use peer auth on the socket, so default to TCP there.
if [ -z "${DB_HOST:-}" ]; then
  if [ "$OS_NAME" = Darwin ] && [ -S /tmp/.s.PGSQL.5432 ]; then DB_HOST=/tmp; else DB_HOST=127.0.0.1; fi
fi
export DB_HOST
export BASE_URL="${BASE_URL:-http://127.0.0.1:8080}"

# Python plotting deps installed by setup.sh live in .deps
export PYTHONPATH="$BENCH_ROOT/.deps${PYTHONPATH:+:$PYTHONPATH}"

# Default stack list (client comparison). Add `php` for the plain-PHP reference row.
export STACKS="${STACKS:-node,node-cluster,laravel-fpm,laravel-fpm-persistent,laravel-octane}"
