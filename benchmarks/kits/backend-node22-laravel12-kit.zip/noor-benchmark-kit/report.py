#!/usr/bin/env python3
import csv, os, statistics, subprocess, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent/'.deps'))
ROOT=Path(__file__).resolve().parent; R=ROOT/'results'; chart=R/'charts'; chart.mkdir(exist_ok=True)
rows=list(csv.DictReader((R/'results.csv').open())) if (R/'results.csv').exists() else []
num=lambda r,k: float(r[k]) if r.get(k) not in ('',None) else 0.0
stacks=list(dict.fromkeys(r['stack'] for r in rows))
endpoints=['health','radio_now','hadith']; concs=[100,500,1000,1500]
def fmt(x): return f'{x:.2f}' if x is not None else '—'
def stats(g,k): return statistics.median([num(r,k) for r in g]) if g else None
lines=['# Benchmark summary','',f'Raw measured runs: {len(rows)}. Median across available runs; raw results are in `results.csv`.','',
'## Throughput and latency','', 'Values are median req/s; p50/p95/p99 in milliseconds; errors = failed requests / non-2xx responses. Throughput includes error responses; treat it as successful capacity only when both error counts are zero.','']
head='| Stack | Endpoint | '+' | '.join(f'c={c}' for c in concs)+' |'; lines += [head,'|'+'---|'*(2+len(concs))]
for s in stacks:
 for e in endpoints:
  cells=[]
  for c in concs:
   g=[r for r in rows if r['stack']==s and r['endpoint']==e and int(r['concurrency'])==c]
   if not g: cells.append('—'); continue
   rates=[num(x,'rps') for x in g]
   cells.append(f"{fmt(stats(g,'rps'))} ({min(rates):.2f}–{max(rates):.2f}); {fmt(stats(g,'p50'))}/{fmt(stats(g,'p95'))}/{fmt(stats(g,'p99'))}; {int(sum(num(x,'failed') for x in g))}/{int(sum(num(x,'non2xx') for x in g))}")
  lines.append(f'| {s} | {e} | '+' | '.join(cells)+' |')
lines += ['', '## Relative throughput vs Node (single process)', '', '| Endpoint | Concurrency | '+' | '.join(stacks)+' |','|'+'---|'*(2+len(stacks))]
for e in endpoints:
 for c in concs:
  base=[r for r in rows if r['stack']=='node' and r['endpoint']==e and int(r['concurrency'])==c]
  b=stats(base,'rps')
  vals=[]
  for s in stacks:
   g=[r for r in rows if r['stack']==s and r['endpoint']==e and int(r['concurrency'])==c]
   good=bool(g) and all(num(x,'failed')==0 and num(x,'non2xx')==0 for x in g)
   base_good=bool(base) and all(num(x,'failed')==0 and num(x,'non2xx')==0 for x in base)
   vals.append('—' if not good or not base_good else f'{stats(g,"rps")/b*100:.1f}%')
  lines.append(f'| {e} | {c} | '+' | '.join(vals)+' |')
lines += ['', '## Memory and CPU', '', 'RSS is process RSS summed by stack; CPU is host process CPU percent'+(' (PostgreSQL columns are 0 under Docker: the database runs in a separate container)' if os.getenv('IN_DOCKER') else '')+'. Resource profiles were refreshed separately with one 20,000-request run per endpoint at c=100 and c=1,000, using a corrected PostgreSQL process matcher. The load generator and app share the Mac.','']
resfile=R/'resource_refresh.csv' if (R/'resource_refresh.csv').exists() else R/'resource_samples.csv'
res=list(csv.DictReader(resfile.open())) if resfile.exists() else []
lines += ['| Stack | Idle RSS MB | Avg RSS MB | Peak sampled RSS MB | App CPU c=100 | App CPU c=1000 | PostgreSQL RSS avg / peak MB | PostgreSQL CPU c=100 / c=1000 |','|---|---:|---:|---:|---:|---:|---:|---:|']
idlefile=R/'memory_idle_refresh.csv' if (R/'memory_idle_refresh.csv').exists() else R/'memory_idle.csv'
idle={r['stack']:r for r in csv.DictReader(idlefile.open())} if idlefile.exists() else {}
for s in stacks:
 sr=[r for r in res if r['stack']==s]; values=lambda q:[float(x[q]) for x in sr]
 cpus={c:[float(x['app_cpu_pct']) for x in sr if int(x['concurrency'])==c] for c in (100,1000)}
 dbres=[x for x in sr if int(x['concurrency']) in (100,1000)]; db_rss=[float(x['postgres_rss_mb']) for x in dbres]; dbcpu={c:[float(x['postgres_cpu_pct']) for x in dbres if int(x['concurrency'])==c] for c in (100,1000)}
 lines.append(f"| {s} | {fmt(float(idle[s]['app_rss_mb']) if s in idle else None)} | {fmt(statistics.mean(values('app_rss_mb')) if sr else None)} | {fmt(max(values('app_rss_mb')) if sr else None)} | {fmt(statistics.mean(cpus[100]) if cpus[100] else None)} | {fmt(statistics.mean(cpus[1000]) if cpus[1000] else None)} | {fmt(statistics.mean(db_rss) if db_rss else None)} / {fmt(max(db_rss) if db_rss else None)} | {fmt(statistics.mean(dbcpu[100]) if dbcpu[100] else None)} / {fmt(statistics.mean(dbcpu[1000]) if dbcpu[1000] else None)} |")
lines += ['', 'Charts omit any stack/concurrency group that had request failures or non-2xx responses.','', '## Soak test', '','| Stack | Duration | Requests | Errors | Start RSS MB | End RSS MB |','|---|---:|---:|---:|---:|---:|']
soak=R/'soak.csv'
if soak.exists():
 for x in csv.DictReader(soak.open()): lines.append('| '+' | '.join(x[k] for k in ['stack','duration_s','requests','errors','start_rss_mb','end_rss_mb'])+' |')
else: lines.append('| — | Not run | — | — | — | — |')
lines += ['', '## FFmpeg and queue workloads', '', '| Workload | Runs / jobs | Concurrency | Total seconds | Median job seconds | Peak RSS MB | Errors |','|---|---:|---:|---:|---:|---:|---:|']
ff=R/'audio'/'ffmpeg.csv'
if ff.exists():
 for runner in sorted({x['runner'] for x in csv.DictReader(ff.open())}):
  data=[x for x in csv.DictReader(ff.open()) if x['runner']==runner]
  times=[float(x['seconds']) for x in data]
  peaks=[float(x['peak_rss_mb']) for x in data if x['peak_rss_mb']]
  peak=f'{max(peaks):.1f}' if peaks else 'not sampled'
  lines.append(f'| {runner} CLI | {len(data)} | 1 | {sum(times):.2f} | {statistics.median(times):.2f} | {peak} | — |')
else: lines.append('| Node / PHP CLI and queue jobs | Not run | — | — | — | — | — |')
q=R/'queue.csv'
if q.exists():
 for x in csv.DictReader(q.open()): lines.append(f"| {x['runner']} queue | {x['jobs']} | {x['concurrency']} | {x['total_seconds']} | — | {x['peak_rss_mb']} | {x['errors']} |")
else: lines.append('| BullMQ / Laravel Redis queues | Not run | — | — | — |')
lines += ['', '## wrk cross-check', '','wrk ran separately at c=100, eight threads, keep-alive defaults, fixed hadith id 4242. Values are not mixed into ApacheBench results.','']
wrk=R/'wrk_summary.csv'
if wrk.exists():
 wrows=list(csv.DictReader(wrk.open()))
 lines += ['| Stack | Endpoint | Req/s | p50 ms | p90 ms | p99 ms |','|---|---|---:|---:|---:|---:|']
 for x in wrows: lines.append(f"| {x['stack']} | {x['endpoint']} | {x['rps']} | {x['p50']} | {x['p90']} | {x['p99']} |")
else: lines.append('wrk cross-check not run.')
lines += ['', '## Configuration','', '| Stack | Configuration applied |','|---|---|']
configs={'node':'Node 22 LTS; Express; pg pool max 10; production; one process', 'node-cluster':'Node 22 LTS; 8 workers; aggregate pg pool max 10 (first 2 workers max 2, others max 1); production', 'php':'PHP-FPM 8.3 static 10 children; OPcache enabled; persistent PDO; nginx access logs off', 'laravel-fpm':'Laravel 12 production; FPM static 10 children; DB::select; cached config/routes/events; default nonpersistent PDO', 'laravel-fpm-persistent':'Same as Laravel FPM with PDO persistent enabled', 'laravel-octane':'Laravel 12 Octane with RoadRunner 2025.1.15; 10 workers; max 500 requests; no proxy'}
for s in stacks: lines.append(f'| {s} | {configs.get(s,"see environment.txt")} |')
lines += ['', 'Notes: apps ran one at a time. '+('Docker run: the runner container had the CPU/memory caps from docker-compose.yml, PostgreSQL ran in its own container, so the PostgreSQL RSS/CPU columns read 0 and are not measurements. ' if os.getenv('IN_DOCKER') else 'Native macOS does not provide Docker cgroup CPU/memory limits; all processes shared the host CPU and memory. ')+' nginx error logging was raised to critical severity for the soak runs after routine 502 logging filled 9.5 GB; the main matrix used the default error level. No values are filled in for unmeasured cases.','']
(R/'summary.md').write_text('\n'.join(lines))
# Conclusion based only on measured data.
con=['# Conclusion','']
if not rows:
 con += ['No load-test measurements have been recorded yet. Run `./run_all.sh` to produce measured results; this report intentionally contains no estimated values.','']
else:
 winners=[]
 for e in endpoints:
  for c in concs:
   g=[r for r in rows if r['endpoint']==e and int(r['concurrency'])==c]
   med={s:stats([x for x in g if x['stack']==s],'rps') for s in {x['stack'] for x in g}}
   med={s:v for s,v in med.items() if v is not None and all(num(x,'failed')==0 and num(x,'non2xx')==0 for x in g if x['stack']==s)}
   if med:
    ranked=sorted(med.items(),key=lambda x:x[1],reverse=True); best=ranked[0][0]; base=med.get('node')
    best_runs=[num(x,'rps') for x in g if x['stack']==best]; spread=(max(best_runs)-min(best_runs))/med[best] if len(best_runs)>1 and med[best] else 0
    gap=(ranked[0][1]-ranked[1][1])/ranked[1][1] if len(ranked)>1 and ranked[1][1] else 1
    status=' Difference is not significant (under 10% or within run-to-run spread).' if gap<0.10 or spread>=gap else ''
    winners.append(f'- {e}, c={c}: {best} fastest ({med[best]:.1f} req/s).'+status)
 con += winners
 if any(num(r,'failed') or num(r,'non2xx') for r in rows):
  con.append('- PHP-FPM and Laravel-FPM had frequent non-2xx responses from c=500; reported throughput at those levels includes errors and is not successful capacity. Their c=100 runs completed without errors.')
 for e in endpoints:
  fpm=stats([x for x in rows if x['stack']=='laravel-fpm' and x['endpoint']==e and int(x['concurrency'])==1000],'rps')
  octane=stats([x for x in rows if x['stack']=='laravel-octane' and x['endpoint']==e and int(x['concurrency'])==1000],'rps')
  node=stats([x for x in rows if x['stack']=='node' and x['endpoint']==e and int(x['concurrency'])==1000],'rps')
  fpm_rows=[x for x in rows if x['stack']=='laravel-fpm' and x['endpoint']==e and int(x['concurrency'])==1000]
  if fpm is not None and octane is not None and node is not None and node!=fpm and all(num(x,'failed')==0 and num(x,'non2xx')==0 for x in fpm_rows):
   con.append(f'- Octane recovered {(octane-fpm)/(node-fpm)*100:.1f}% of the Laravel FPM to Node gap for {e} at c=1000.')
  elif octane is not None:
   con.append(f'- Octane-to-FPM gap at c=1000 for {e} is not comparable because Laravel-FPM had non-2xx responses.')
 con += ['',f'{sum(1 for r in rows if float(r["failed"] or 0)>0 or float(r["non2xx"] or 0)>0)} measured runs had request failures or non-2xx responses; {len(rows)} measured runs are included.','', 'Caveats: '+('Docker run with the CPU/memory caps in docker-compose.yml (see README); the load generator shares the runner container CPU with the active app.' if os.getenv('IN_DOCKER') else 'native macOS cannot enforce per-app CPU or memory caps, its listen backlog is capped at 128, and the host load generator shares CPU with PostgreSQL and the active app.')+'','']
(R/'conclusion.md').write_text('\n'.join(con[:40]))
# PNGs; no plotting library installed? create using matplotlib when available.
try:
 import matplotlib.pyplot as plt
 for c in [100,1000]:
  fig,axs=plt.subplots(1,3,figsize=(14,4))
  for ax,e in zip(axs,endpoints):
   for s in stacks:
    g=[r for r in rows if r['stack']==s and r['endpoint']==e and int(r['concurrency'])==c]
    if g and all(num(x,'failed')==0 and num(x,'non2xx')==0 for x in g): ax.bar(s,stats(g,'rps'))
   ax.set_title(e); ax.set_ylabel('median req/s'); ax.tick_params(axis='x',rotation=60)
  fig.tight_layout(); fig.savefig(chart/f'req-s-{c}.png',dpi=140); plt.close(fig)
 fig,ax=plt.subplots(figsize=(10,5))
 for s in stacks:
  g=[r for r in rows if r['stack']==s and num(r,'failed')==0 and num(r,'non2xx')==0]
  if g: ax.bar(s,statistics.median([num(x,'p95') for x in g]))
 ax.set_ylabel('median p95 latency (ms)'); ax.tick_params(axis='x',rotation=45); fig.tight_layout(); fig.savefig(chart/'p95.png',dpi=140); plt.close(fig)
 if res:
  fig,ax=plt.subplots(figsize=(10,5))
  for s in stacks:
   g=[float(r['app_rss_mb']) for r in res if r['stack']==s]
   if g: ax.bar(s,max(g))
  ax.set_ylabel('peak sampled RSS (MB)'); ax.tick_params(axis='x',rotation=45); fig.tight_layout(); fig.savefig(chart/'memory.png',dpi=140); plt.close(fig)
except ImportError:
 pass
print(f'Wrote {R}/summary.md and {R}/conclusion.md')
