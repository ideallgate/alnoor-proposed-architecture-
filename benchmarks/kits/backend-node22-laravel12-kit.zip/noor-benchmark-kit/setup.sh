#!/bin/bash
# One-time setup: dependencies, Laravel config, database. Safe to re-run.
#   DB_ADMIN_PSQL  psql command with superuser rights (default: plain psql; Debian: "sudo -u postgres psql")
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"; . "$ROOT/env.sh"
for t in NODE PHP PSQL PYTHON; do [ -n "${!t}" ] || { echo "missing $t - run ./check.sh" >&2; exit 3; }; done
"$NODE" -v >/dev/null 2>&1 || { echo "node is installed but cannot run (macOS: brew reinstall simdjson node@22)" >&2; exit 3; }
"$PHP" -v >/dev/null 2>&1 || { echo "php cannot run" >&2; exit 3; }
command -v composer >/dev/null || { echo "composer missing" >&2; exit 3; }

echo "== Node dependencies"; (cd "$ROOT/node" && npm ci --omit=dev)

echo "== Plotting dependency (matplotlib, optional)"
"$PYTHON" -m pip install --quiet --target "$ROOT/.deps" matplotlib 2>/dev/null \
 || "$PYTHON" -m pip install --quiet --break-system-packages --target "$ROOT/.deps" matplotlib 2>/dev/null \
 || echo "   matplotlib not installed: report.py still writes tables, just no PNG charts"

echo "== Laravel dependencies"
cd "$ROOT/laravel"
composer install --no-dev --no-interaction --optimize-autoloader
[ -f .env ] || cp .env.bench.example .env
sed -i.bak "s|^DB_HOST=.*|DB_HOST=$DB_HOST|" .env && rm -f .env.bak
grep -q '^APP_KEY=.\+' .env || "$PHP" artisan key:generate --force --no-interaction
# RoadRunner binary used by Octane
[ -x ./rr ] || "$PHP" vendor/bin/rr get-binary --no-interaction || echo "   could not fetch RoadRunner; laravel-octane will not start"
"$PHP" artisan config:clear >/dev/null 2>&1 || true
cd "$ROOT"

echo "== Database"
A="${DB_ADMIN_PSQL:-$PSQL}"      # psql as a superuser; Debian/Ubuntu: DB_ADMIN_PSQL="sudo -u postgres psql"
if ! $A -d postgres -Atc "SELECT 1 FROM pg_roles WHERE rolname='bench'" | grep -q 1; then $A -d postgres -c "CREATE USER bench WITH PASSWORD 'bench';"; fi
if ! $A -d postgres -Atc "SELECT 1 FROM pg_database WHERE datname='noor'" | grep -q 1; then
  $A -d postgres -c "CREATE DATABASE noor OWNER bench;"
  $A -d noor < "$ROOT/seed.sql"
  $A -d noor -c "GRANT SELECT ON ALL TABLES IN SCHEMA public TO bench; GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO bench;"
else
  echo "   database 'noor' already exists - leaving it untouched"
fi
echo "== Done. Next: ./check.sh then ./parity.sh"
