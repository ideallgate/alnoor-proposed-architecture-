#!/bin/bash
set -euo pipefail
cd /kit
ulimit -n 65535 2>/dev/null || true
# wait for the database (compose also gates on a healthcheck)
for i in $(seq 1 60); do pg_isready -q -h "$DB_HOST" -U bench -d noor && break; sleep 1; done
# Redis is only used by the optional queue workload
redis-server --daemonize yes --save "" --appendonly no >/dev/null
mkdir -p results
case "${1:-help}" in
  check)    ./check.sh;;
  parity)   ./parity.sh;;
  quick)    ./check.sh && ./parity.sh && \
            RESET_RESULTS=1 CONCURRENCIES="${CONCURRENCIES:-100,500}" RUNS="${RUNS:-2}" REQUESTS="${REQUESTS:-5000}" WARMUP="${WARMUP:-500}" \
            PAUSE="${PAUSE:-2}" STACK_PAUSE="${STACK_PAUSE:-5}" SOAK_SECONDS="${SOAK_SECONDS:-20}" RUN_AUDIO="${RUN_AUDIO:-0}" CROSSCHECK_WRK="${CROSSCHECK_WRK:-0}" ./run_all.sh;;
  full)     ./check.sh && ./parity.sh && ./run_all.sh;;
  shell)    exec bash;;
  *) cat <<'TXT'
Usage: docker compose run --rm bench <command>
  check    show tool/DB status
  parity   all stacks must return identical JSON
  quick    check + parity + short benchmark (about 20-30 min)
  full     check + parity + full matrix (hours)
  shell    interactive shell in the runner
Env overrides (see README): STACKS CONCURRENCIES RUNS REQUESTS WARMUP SOAK_SECONDS RUN_AUDIO ...
Results are written to ./results on the host.
TXT
  ;;
esac
