#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
. "$ROOT/env.sh"
INPUT="$ROOT/results/audio/in.wav"
OUT="$ROOT/results/audio"
mkdir -p "$ROOT/run"
[ -f "$INPUT" ] || { echo 'Run run_ffmpeg.sh first to create the 5-minute WAV.' >&2; exit 2; }
"$NODE" "$ROOT/node/ffmpeg_queue_worker.js" "$INPUT" "$OUT" 20
"$PYTHON" - "$ROOT" "$INPUT" "$OUT" <<'PY'
import os,subprocess,sys,time,csv
from pathlib import Path
root=Path(sys.argv[1]); inp=sys.argv[2]; out=sys.argv[3]; php=os.environ['PHP']; app=root/'laravel'
env=os.environ.copy(); env['QUEUE_CONNECTION']='redis'; env['REDIS_CLIENT']='predis'
subprocess.run([php,'artisan','config:clear'],cwd=app,env=env,check=True,stdout=subprocess.DEVNULL)
subprocess.run([php,'artisan','config:cache'],cwd=app,env=env,check=True,stdout=subprocess.DEVNULL)
subprocess.run([php,'artisan','bench:ffmpeg-dispatch',inp,out,'20'],cwd=app,env=env,check=True)
workers=[]
for i in (1,2):
 log=open(root/'run'/f'laravel-queue-{i}.log','w')
 p=subprocess.Popen([php,'artisan','queue:work','redis',f'--queue=ffmpeg-{i}','--sleep=0','--tries=1','--timeout=600','--max-jobs=10','--no-interaction'],cwd=app,env=env,stdout=log,stderr=subprocess.STDOUT)
 workers.append((p,log))
start=time.perf_counter(); peak=0.0
def sample_rss():
 rss=0.0
 for p,_ in workers:
  if p.poll() is None:
   sample=subprocess.run(['ps','-o','rss=','-p',str(p.pid)],capture_output=True,text=True)
   try:rss+=int(sample.stdout.strip())/1024
   except ValueError:pass
 return rss
peak=sample_rss()
while any(p.poll() is None for p,_ in workers):
 time.sleep(0.2)
 rss=sample_rss()
 peak=max(peak,rss)
for p,log in workers: p.wait();log.close()
elapsed=time.perf_counter()-start
errors=sum('failed' in f.read_text(errors='ignore').lower() for f in [root/'run/laravel-queue-1.log',root/'run/laravel-queue-2.log'])
with (root/'results/queue.csv').open('a',newline='') as f:
 w=csv.writer(f)
 if f.tell()==0:w.writerow(['runner','jobs','concurrency','total_seconds','peak_rss_mb','errors'])
 w.writerow(['laravel-redis',20,2,f'{elapsed:.3f}',f'{peak:.1f}',errors])
print(f'20 Laravel Redis queue jobs completed in {elapsed:.2f} seconds; errors={errors}; peak worker RSS={peak:.1f} MB')
PY
