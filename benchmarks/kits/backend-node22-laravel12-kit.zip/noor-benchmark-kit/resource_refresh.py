#!/usr/bin/env python3
"""Refresh RSS/CPU profiles with PostgreSQL parent and all worker processes included."""
import csv, os, re, subprocess, time
from pathlib import Path
ROOT=Path(__file__).resolve().parent; R=ROOT/'results'; BASE='http://127.0.0.1:8080'; AB=os.getenv('AB') or __import__('shutil').which('ab') or '/usr/sbin/ab'
STACKS=os.getenv('STACKS','node,node-cluster,laravel-fpm,laravel-fpm-persistent,laravel-octane').split(',')
ENDPOINTS={'health':'/health','radio_now':'/radio/now','hadith':'/hadith/4242'}
prev={}; prevtime=None

def cputime(value):
 value=value.strip(); days=0
 if '-' in value: d,value=value.split('-',1);days=int(d)
 p=value.split(':')
 if len(p)==3: h,m,s=int(p[0]),int(p[1]),float(p[2])
 elif len(p)==2: h,m,s=0,int(p[0]),float(p[1])
 else: h,m,s=0,0,float(p[0])
 return days*86400+h*3600+m*60+s

def sample():
 global prev,prevtime
 p=subprocess.run(['ps','-axo','pid,cputime,rss,command'],text=True,capture_output=True,check=True)
 sums={'app_rss_mb':0.0,'postgres_rss_mb':0.0}; cpu={'app':0.0,'postgres':0.0}; now=time.monotonic();current={}
 for line in p.stdout.splitlines()[1:]:
  x=line.strip().split(None,3)
  if len(x)<4:continue
  try:pid=int(x[0]); ct=cputime(x[1]); rss=int(x[2])/1024
  except ValueError:continue
  cmd=x[3].lower()
  isdb=('postgres' in cmd and ('postgresql@16' in cmd or '/postgresql/' in cmd or cmd.startswith('postgres: ')))
  isapp=(('node' in cmd and str(ROOT/'node/server.js').lower() in cmd) or 'php-fpm' in cmd or 'nginx: worker' in cmd or 'rr serve' in cmd or 'artisan octane:start' in cmd or str(ROOT/'laravel/vendor/bin/roadrunner-worker').lower() in cmd)
  kind='postgres' if isdb else ('app' if isapp else None)
  if kind:
   sums['postgres_rss_mb' if kind=='postgres' else 'app_rss_mb']+=rss;current[pid]=(ct,kind)
 if prevtime is not None:
  elapsed=max(now-prevtime,.001)
  for pid,(ct,k) in current.items():
   if pid in prev:cpu[k]+=max(0,ct-prev[pid][0])/elapsed*100
 prev=current;prevtime=now
 return sums,cpu

sample_path=R/'resource_refresh.csv'; idle_path=R/'memory_idle_refresh.csv'
with sample_path.open('w',newline='') as f:csv.writer(f).writerow(['timestamp','stack','endpoint','concurrency','run','app_cpu_pct','app_rss_mb','postgres_cpu_pct','postgres_rss_mb'])
with idle_path.open('w',newline='') as f:csv.writer(f).writerow(['stack','app_rss_mb','postgres_rss_mb'])
for stack in STACKS:
 print(f'=== resource profile {stack} ===',flush=True);subprocess.run([str(ROOT/'benchctl'),stack],check=True);time.sleep(3)
 sample();idle,cpu=sample()
 with idle_path.open('a',newline='') as f:csv.writer(f).writerow([stack,idle['app_rss_mb'],idle['postgres_rss_mb']])
 for endpoint,path in ENDPOINTS.items():
  subprocess.run([AB,'-k','-l','-n','2000','-c','50',BASE+path],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=False)
  for c in (100,1000):
   print(f'{stack} {endpoint} c={c}',flush=True)
   sample(); rawdir=R/'raw'/'resource-refresh'/stack/endpoint/f'c{c}';rawdir.mkdir(parents=True,exist_ok=True)
   proc=subprocess.Popen([AB,'-k','-l','-n','20000','-c',str(c),BASE+path],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
   out=[]; samples=[]
   while proc.poll() is None:
    vals,cvals=sample();samples.append((vals,cvals));time.sleep(.5)
   output=proc.stdout.read();proc.wait();out.append(output)
   vals,cvals=sample();samples.append((vals,cvals));(rawdir/'run1.txt').write_text(output)
   with sample_path.open('a',newline='') as f:
    w=csv.writer(f)
    for v,cpuvals in samples:w.writerow([time.time(),stack,endpoint,c,1,cpuvals['app'],v['app_rss_mb'],cpuvals['postgres'],v['postgres_rss_mb']])
   fails=re.search(r'Failed requests:\s*(\d+)',output);bad=re.search(r'Non-2xx responses:\s*(\d+)',output)
   if (fails and int(fails.group(1))) or (bad and int(bad.group(1))):print(f'  observed failures={fails.group(1) if fails else 0}, non2xx={bad.group(1) if bad else 0}',flush=True)
 subprocess.run([str(ROOT/'benchctl'),'stop'],check=False)
print(f'Wrote {sample_path} and {idle_path}',flush=True)
