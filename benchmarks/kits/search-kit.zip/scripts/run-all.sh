#!/usr/bin/env bash
# Whole benchmark: pass1 (opensearch, meilisearch, postgres), then pass2 with reversed engine order. One engine up at a time.
set -uo pipefail
cd "$(dirname "$0")/.."
export T3_CAP=${T3_CAP:-240}
docker compose --profile runner build 2>&1 | tail -2
for E in opensearch meilisearch postgres; do ./scripts/run-engine.sh $E pass1; done
docker compose --profile runner run --rm -T runner opensearch pack-build --pass pass1
for E in postgres meilisearch opensearch; do ./scripts/run-engine.sh $E pass2; done
echo ALL-DONE
