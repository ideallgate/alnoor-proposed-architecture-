#!/usr/bin/env bash
# usage: run-engine.sh <opensearch|meilisearch|postgres> <pass1|pass2>
# Runs the whole benchmark for ONE engine (only that engine container is up). Docker is the only requirement.
set -uo pipefail
cd "$(dirname "$0")/.."
E=$1; P=$2; OUT=results-$P
INDEX_RUNS=${INDEX_RUNS:-5}; T3_RUNS=${T3_RUNS:-5}; T3_REQS=${T3_REQS:-5000}; T3_CAP=${T3_CAP:-900}; SCALES=${SCALES-"10 50"}; UPD_RUNS=${UPD_RUNS:-5}
C="docker compose --profile $E"
CN=noor-bench-$E-1
mkdir -p $OUT work
log(){ echo "[$(date +%T)] $E $P: $*" | tee -a $OUT/run-$E.log; }
R(){ echo "$1" > work/phase.txt; log "phase $*"; docker compose --profile runner run --rm -T runner $E "$@" --pass $P 2>&1 | tee -a $OUT/run-$E.log | tail -n 5; return ${PIPESTATUS[0]}; }
case $E in
 opensearch) HEALTH='curl -sf "http://127.0.0.1:9200/_cluster/health?wait_for_status=yellow&timeout=1s" >/dev/null'; VOL=noor-bench_os-data;;
 meilisearch) HEALTH='curl -sf http://127.0.0.1:7700/health >/dev/null'; VOL=noor-bench_meili-data;;
 postgres) HEALTH='docker exec '$CN' pg_isready -U postgres -d bench >/dev/null 2>&1'; VOL=noor-bench_pg-data;;
esac
vol(){ docker run --rm -v $VOL:/v alpine du -sk /v | cut -f1; }
$C down -v >/dev/null 2>&1
echo idle > work/phase.txt
# cold start: volumes are fresh, container created and started from scratch
T0=$(date +%s.%N); $C up -d $E >/dev/null 2>&1
until eval "$HEALTH"; do sleep 0.2; done
T1=$(date +%s.%N); echo "{\"engine\":\"$E\",\"coldStartSec\":$(echo "$T1 - $T0" | bc)}" > $OUT/coldstart-$E.json; log "cold start $(echo "$T1 - $T0" | bc)s"
# memory sampler
( while true; do echo "$(date +%s),$(cat work/phase.txt),$(docker stats --no-stream --format '{{.CPUPerc}},{{.MemUsage}}' $CN 2>/dev/null)" >> $OUT/memory-$E.csv; sleep 2; done ) & SAMP=$!
trap 'kill $SAMP 2>/dev/null' EXIT
sleep 20
docker image inspect $(docker inspect -f '{{.Config.Image}}' $CN) --format '{"image":"{{index .RepoDigests 0}}","sizeBytes":{{.Size}}}' > $OUT/image-$E.json 2>/dev/null
R settings
R index --runs $INDEX_RUNS || exit 1
echo "{\"volumeKB\":$(vol)}" > $OUT/volume-after-index-$E.json
[ "${SKIP_T1:-0}" = 1 ] || R t1
R t2
R t3 --label real-full --runs $T3_RUNS --reqs $T3_REQS --cap $T3_CAP
[ "$P" = pass1 ] && R pack-run
R updates --runs $UPD_RUNS
# scaled copies use the LITE schema (matn search + filters only) so that 50x fits on disk; same schema at x1 for comparability
for S in 1 $SCALES; do
  R drop
  R scale --factor $S --index lite_x$S || { log "scale x$S FAILED"; continue; }
  echo "{\"volumeKB\":$(vol)}" > $OUT/volume-after-index-$E-lite-x$S.json
  R t3 --label lite-x$S --index lite_x$S --runs $T3_RUNS --reqs $T3_REQS --cap $T3_CAP
  R drop --index lite_x$S
done
echo idle-end > work/phase.txt; sleep 6
kill $SAMP 2>/dev/null
$C down -v >/dev/null 2>&1
log done
