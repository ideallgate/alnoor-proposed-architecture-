import fs from 'node:fs';
import { median } from './util.js';
const ENG = ['opensearch', 'meilisearch', 'postgres']; const PASS = ['pass1', 'pass2'];
const rd = (p: string) => { try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return null; } };
const f = (x: any, d = 3) => (x === null || x === undefined || Number.isNaN(x) ? '–' : typeof x === 'number' ? x.toFixed(d) : String(x));
const md = (h: string[], rows: any[][]) => `| ${h.join(' | ')} |\n|${h.map(() => '---').join('|')}|\n${rows.map(r => '| ' + r.join(' | ') + ' |').join('\n')}\n`;
const mib = (s: string) => { const m = /([\d.]+)\s*(B|KiB|MiB|GiB|kB|MB|GB)/.exec(s); if (!m) return NaN; const v = Number(m[1]); return m[2] === 'GiB' ? v * 1024 : m[2] === 'MiB' ? v : m[2] === 'KiB' ? v / 1024 : m[2] === 'GB' ? v * 953.7 : m[2] === 'MB' ? v * .9537 : m[2] === 'kB' ? v / 1024 : v / 1048576; };
let o = ''; const T1C: Record<string, any> = {};
// ---- T1
const VAR: Record<string, string> = { o: 'o original (as stored)', a: 'a no diacritics', b: 'b partial diacritics', c1: 'c1 hamza dropped', c2: 'c2 hamza forms swapped', d: 'd ى↔ي', e: 'e ة↔ه', f: 'f article add/remove', g: 'g combination (a+c1+d+e+f)', h: 'h marks reordered (shadda first)' };
o += '## T1 tables (recall@10 / MRR; n = applicable queries)\n\nPass 1 values; `agree` lines state whether pass 2 is identical (T1 is deterministic).\n\n';
for (const field of ['matn_ar', 'text_ar']) for (const mode of ['phrase', 'terms']) {
  const rows: any[][] = [];
  for (const v of Object.keys(VAR)) {
    const r: any[] = [VAR[v]]; let n = '';
    for (const e of ENG) for (const cfg of ['none', 'rec', 'strict', 'merged']) {
      const d = rd(`/results-pass1/t1-${e}.json`); if (d && !d.rebuilt) { const ag: any = {}; for (const l of fs.readFileSync(`/results-pass1/t1-${e}-raw.ndjson`, 'utf8').split('\n')) { if (!l) continue; const [, v2, fl, md2, cf, rc, rr] = JSON.parse(l); if (rc === null || Number.isNaN(rc)) continue; const k = `${fl}|${md2}|${cf}|${v2}`; const a = (ag[k] ??= { n: 0, r: 0, m: 0 }); a.n++; a.r += rc; a.m += rr; } d.summary = Object.entries(ag).map(([k, a]: any) => { const [field2, mode2, cfg2, variant] = k.split('|'); return { field: field2, mode: mode2, cfg: cfg2, variant, n: a.n, recall10: a.r / a.n, mrr: a.m / a.n }; }); d.rebuilt = true; T1C[e] = d; } const s = (T1C[e] ?? d)?.summary.find((x: any) => x.field === field && x.mode === mode && x.cfg === (e === 'meilisearch' && cfg === 'rec' ? 'none' : cfg) && x.variant === v);
      r.push(s ? `${f(s.recall10, 2)} / ${f(s.mrr, 2)}` : '–'); if (s) n = String(s.n);
    }
    r.splice(1, 0, n); rows.push(r);
  }
  const h = ['variant', 'n']; for (const e of ENG) for (const c of ['none', 'rec', 'strict', 'merged']) h.push(`${e.slice(0, 2).toUpperCase()}:${c}`);
  o += `### ${field}, ${mode} query\n\n${md(h, rows)}\n`;
}
let agree = '';
for (const e of ENG) { const a = rd(`/results-pass1/t1-${e}.json`), b = rd(`/results-pass2/t1-${e}.json`); if (a && b) agree += `- ${e}: pass2 ${JSON.stringify(a.summary) === JSON.stringify(b.summary) ? 'identical to' : 'DIFFERS from'} pass1 (jobs ${a.jobs}, errors ${Object.keys(a.errors).length}/${Object.keys(b.errors).length} kinds)\n`; }
const a0 = rd('/results-pass1/t1-opensearch.json'); if (a0) o += `Phrases: ${a0.phrases} used; skipped for >20 matches: ${a0.skippedFreq}; skipped for salutation: ${a0.skippedSalutation}; text_ar field skipped for >20 matches: ${a0.textFieldSkipped}.\n\n${agree}\n`;
// ---- T3
o += '## T3 latency (ms; median of the 5 runs of each cell; both passes)\n\n';
const rows3: any[][] = [];
for (const e of ENG) for (const lab of ['real-full', 'lite-x1', 'lite-x10', 'lite-x50']) for (const c of [1, 10, 50]) {
  const r: any[] = [e, lab, c];
  for (const p of PASS) { const d = rd(`/results-${p}/t3-${e}-${lab}.json`)?.cells.find((x: any) => x.concurrency === c); r.push(d ? `${f(d.median.p50, 1)} / ${f(d.median.p95, 1)} / ${f(d.median.p99, 1)}` : '–', d ? f(d.median.qps, 0) : '–', d ? `${d.totalErrors} (${d.runs.reduce((a: number, x: any) => a + x.requests, 0)} req${d.runs.some((x: any) => x.capped) ? ', time-capped' : ''})` : '–'); }
  rows3.push(r);
}
o += md(['engine', 'corpus', 'conc', 'P1 p50/p95/p99', 'P1 qps', 'P1 errors (requests)', 'P2 p50/p95/p99', 'P2 qps', 'P2 errors (requests)'], rows3) + '\n';
// ---- T4
o += '## T4 indexing, updates, memory\n\n';
const r4: any[][] = [];
for (const e of ENG) { const r: any[] = [e]; for (const p of PASS) { const d = rd(`/results-${p}/t4-index-${e}-real.json`); r.push(d ? `${f(d.medianTotalSec, 1)} (${d.runs.map((x: any) => f(x.totalSec, 0)).join(',')})` : '–', d ? (d.bytes / 1e6).toFixed(0) : '–', d?.afterCompact ? (d.afterCompact.bytes / 1e6).toFixed(0) : '–'); } r4.push(r); }
o += md(['engine', 'P1 index s median (runs)', 'P1 size MB', 'P1 after compact MB', 'P2 index s median (runs)', 'P2 size MB', 'P2 after compact MB'], r4) + '\n';
const rl: any[][] = [];
for (const e of ENG) for (const t of ['lite-x1', 'lite-x10', 'lite-x50']) { const r: any[] = [e, t]; for (const p of PASS) { const d = rd(`/results-${p}/t4-index-${e}-${t}.json`); const v = rd(`/results-${p}/volume-after-index-${e}-${t}.json`); r.push(d ? f(d.medianTotalSec, 0) : '–', d ? (d.bytes / 1e6).toFixed(0) : '–', v ? (v.volumeKB / 1024).toFixed(0) : '–'); } rl.push(r); }
o += md(['engine', 'lite schema', 'P1 index s', 'P1 API size MB', 'P1 volume MB', 'P2 index s', 'P2 API size MB', 'P2 volume MB'], rl) + '\n';
const ru: any[][] = [];
for (const e of ENG) { const r: any[] = [e]; for (const p of PASS) { const d = rd(`/results-${p}/t4-updates-${e}.json`); r.push(d ? `${f(d.median.p50, 0)} / ${f(d.median.p95, 0)}` : '–', d ? f(d.median.bulk1000Ms, 0) : '–', d ? d.runs.reduce((a: number, x: any) => a + x.singleVisible.nanCount, 0) : '–'); } ru.push(r); }
o += md(['engine', 'P1 single→searchable p50/p95 ms', 'P1 bulk 1000 ms', 'P1 not-seen', 'P2 single p50/p95 ms', 'P2 bulk 1000 ms', 'P2 not-seen'], ru) + '\n';
const rm: any[][] = [];
for (const e of ENG) for (const p of PASS) {
  let txt = ''; try { txt = fs.readFileSync(`/results-${p}/memory-${e}.csv`, 'utf8'); } catch { continue; }
  const by: Record<string, number[]> = {}; for (const l of txt.split('\n')) { const c = l.split(','); if (c.length < 4) continue; const m = mib(c[3].split('/')[0]); if (!Number.isNaN(m)) (by[c[1]] ??= []).push(m); }
  const st = (ph: string[]) => { const a = ph.flatMap(x => by[x] ?? []); return a.length ? `${median(a).toFixed(0)} / ${Math.max(...a).toFixed(0)}` : '–'; };
  rm.push([e, p, st(['idle']), st(['index']), st(['t1', 't2']), st(['t3']), st(['updates']), st(['scale'])]);
}
o += '### Container memory (MiB, median / max of docker-stats samples every ~2 s; cap 2048)\n\n' + md(['engine', 'pass', 'idle (after start)', 'index (real)', 't1+t2', 't3 (all sizes)', 'updates', 'scaled index builds'], rm) + '\n';
// ---- T5
o += '## T5 operability\n\n'; const r5: any[][] = [];
for (const e of ENG) { const im = rd(`/results-pass1/image-${e}.json`); const im2 = rd(`/results-pass2/image-${e}.json`); const cs = [rd(`/results-pass1/coldstart-${e}.json`)?.coldStartSec, rd(`/results-pass2/coldstart-${e}.json`)?.coldStartSec]; const st = fs.existsSync(`/results-pass1/settings-${e}.json`) ? fs.readFileSync(`/results-pass1/settings-${e}.json`, 'utf8') : ''; r5.push([e, im ? (im.sizeBytes / 1e6).toFixed(0) + ' MB' : '–', im?.image ?? '–', cs.map(x => f(x, 1)).join(' / '), st ? st.split('\n').length : '–', st ? (st.match(/": /g) ?? []).length : '–']); }
o += md(['engine', 'image size', 'image digest', 'cold start s (P1 / P2)', 'settings dump lines', 'settings keys'], r5);
fs.writeFileSync('/work/tables.md', o);
console.log(o.length, 'chars written');
