import { Client } from '@opensearch-project/opensearch';
import type { Doc } from './data.js';
import { chunk, gradeRank, type Cfg, type Engine, type Field, type Req, type Res } from './engine.js';
import { MARK_CLASS, FOLD_FROM, FOLD_TO } from './norm.js';
import { sleep, streamPool } from './util.js';

const mapStrict = [...FOLD_FROM].map((c, i) => `${c}=>${FOLD_TO[i]}`);
const mapMerged = [...mapStrict, 'ة=>ه'];
export const OS_INDEX_BODY = {
  settings: {
    number_of_shards: 1, number_of_replicas: 0,
    analysis: {
      char_filter: {
        ar_marks: { type: 'pattern_replace', pattern: `[${MARK_CLASS}]`, replacement: '' },
        ar_fold_strict: { type: 'mapping', mappings: mapStrict },
        ar_fold_merged: { type: 'mapping', mappings: mapMerged },
      },
      filter: { ar_article: { type: 'pattern_replace', pattern: '^ال(?=..)', replacement: '' } },
      analyzer: {
        ar_strict: { type: 'custom', tokenizer: 'standard', char_filter: ['ar_marks', 'ar_fold_strict'], filter: ['ar_article'] },
        ar_merged: { type: 'custom', tokenizer: 'standard', char_filter: ['ar_marks', 'ar_fold_merged'], filter: ['ar_article'] },
      },
    },
  },
  mappings: {
    properties: {
      ...Object.fromEntries(['text_ar', 'matn_ar', 'isnad_ar', 'book', 'chapter'].map(f => [f, {
        type: 'text', analyzer: 'standard',
        fields: { rec: { type: 'text', analyzer: 'arabic' }, strict: { type: 'text', analyzer: 'ar_strict' }, merged: { type: 'text', analyzer: 'ar_merged' } },
      }])),
      book_kw: { type: 'keyword' }, chapter_kw: { type: 'keyword' }, grade_class: { type: 'keyword' }, grade_rank: { type: 'integer' }, hadith_number: { type: 'keyword' },
    },
  },
};
export const isLite = (i: string) => i.startsWith('lite');
export const OS_LITE_BODY = { settings: OS_INDEX_BODY.settings, mappings: { properties: { matn_ar: { type: 'text', analyzer: 'ar_merged' }, book_kw: { type: 'keyword' }, grade_class: { type: 'keyword' } } } };
const toLite = (d: Doc) => ({ matn_ar: d.matn_ar, book_kw: d.book, grade_class: d.grade_class });
const fn = (f: Field, cfg: Cfg, lite = false) => (lite || cfg === 'none' ? f : `${f}.${cfg}`);
const toSrc = (d: Doc) => ({ ...d, book_kw: d.book, chapter_kw: d.chapter, grade_rank: gradeRank(d.grade_class) });

export class OpenSearch implements Engine {
  name = 'opensearch';
  c: any = new Client({ node: process.env.OS_URL!, requestTimeout: 120000, maxRetries: 0 });
  async waitReady() { for (let i = 0; i < 300; i++) { try { await this.c.cluster.health({}); return; } catch { await sleep(1000); } } throw new Error('opensearch not ready'); }
  async setup(index: string) {
    await this.drop(index);
    const base = isLite(index) ? OS_LITE_BODY : OS_INDEX_BODY;
    await this.c.indices.create({ index, body: { ...base, settings: { ...base.settings, refresh_interval: '-1' } } });
  }
  async load(index: string, docs: Iterable<Doc>) {
    await streamPool(2, chunk(docs, 1000), async b => {
      const body = b.flatMap(d => [{ index: { _index: index, _id: d.id } }, (isLite(index) ? toLite(d) : toSrc(d))]);
      const r: any = await this.c.bulk({ body, refresh: false });
      if (r.body.errors) throw new Error('bulk errors: ' + JSON.stringify(r.body.items.find((i: any) => i.index.error)).slice(0, 400));
    });
    await this.c.indices.putSettings({ index, body: { index: { refresh_interval: '1s' } } });
    await this.c.indices.refresh({ index });
  }
  private clauses(r: Req, lite = false) {
    const should = r.fields.map(f => {
      const field = fn(f, r.cfg, lite); const boost = r.boosts?.[f] ?? 1;
      if (r.mode === 'phrase') return { match_phrase: { [field]: { query: r.q, boost } } };
      if (r.mode === 'terms') return { match: { [field]: { query: r.q, operator: 'and', boost } } };
      return { match_phrase_prefix: { [field]: { query: r.q, max_expansions: 50, boost } } };
    });
    const filter: any[] = [];
    if (r.book) filter.push({ term: { book_kw: r.book } });
    if (r.grade_class) filter.push({ term: { grade_class: r.grade_class } });
    const bool: any = { must: [{ bool: { should, minimum_should_match: 1 } }], filter };
    if (r.gradeBoost) bool.should = [{ term: { grade_class: { value: 'sahih', boost: 2 } } }, { term: { grade_class: { value: 'hasan', boost: 1 } } }];
    return { bool };
  }
  async search(index: string, r: Req): Promise<Res> {
    const body: any = { size: r.size ?? 10, _source: false, track_total_hits: r.hl ? false : 1000, query: this.clauses(r, isLite(index)) };
    if (r.hl) { const hf = fn('text_ar', r.cfg); body.highlight = { pre_tags: ['<em>'], post_tags: ['</em>'], fields: { [hf]: { type: 'unified', number_of_fragments: 0 } }, require_field_match: true }; }
    const x: any = (await this.c.search({ index, body })).body;
    const hf = fn('text_ar', r.cfg);
    return { total: x.hits.total?.value ?? 0, hits: x.hits.hits.map((h: any) => ({ id: h._id, hl: h.highlight?.[hf]?.[0] })) };
  }
  async count(index: string, r: Req) { return ((await this.c.count({ index, body: { query: this.clauses(r, isLite(index)) } })).body as any).count; }
  async get(index: string, id: string) { try { const x: any = await this.c.get({ index, id }); return x.body._source as Doc; } catch (e: any) { if (e.statusCode === 404) return null; throw e; } }
  async update(index: string, id: string, patch: any) { await this.c.update({ index, id, body: { doc: patch }, refresh: false }); }
  async bulkUpdate(index: string, ups: any[]) {
    const body = ups.flatMap(u => [{ update: { _index: index, _id: u.id } }, { doc: u.patch }]);
    const r: any = await this.c.bulk({ body, refresh: false }); if (r.body.errors) throw new Error('bulk update errors');
  }
  async facet(index: string, field: any, filter: any = {}) {
    const f = field === 'book' ? 'book_kw' : field === 'chapter' ? 'chapter_kw' : 'grade_class';
    const filt: any[] = []; if (filter.book) filt.push({ term: { book_kw: filter.book } }); if (filter.grade_class) filt.push({ term: { grade_class: filter.grade_class } });
    const x: any = (await this.c.search({ index, body: { size: 0, query: { bool: { filter: filt } }, aggs: { a: { terms: { field: f, size: 10000 } } } } })).body;
    return Object.fromEntries(x.aggregations.a.buckets.map((b: any) => [b.key, b.doc_count]));
  }
  async stats(index: string) { const x: any = (await this.c.indices.stats({ index, metric: 'store,docs' })).body; const p = x._all.primaries; return { docs: p.docs.count, bytes: p.store.size_in_bytes }; }
  async compact(index: string) { await this.c.indices.forcemerge({ index, max_num_segments: 1 }, { requestTimeout: 3600000 }); await this.c.indices.refresh({ index }); return { bytes: (await this.stats(index)).bytes }; }
  async drop(index: string) { try { await this.c.indices.delete({ index }); } catch (e: any) { if (e.statusCode !== 404) throw e; } }
  settingsSummary() { return OS_INDEX_BODY; }
  async close() { await this.c.close(); }
}
