import fs from 'node:fs';
import { loadCorpus, type Doc } from './data.js';
import { mulberry32, out, pool, median } from './util.js';
import { normChars, NFC } from './norm.js';
import type { Cfg, Engine, Field } from './engine.js';

const MARKS_RE = /[ً-ْٰ]/g;
const SALUT = /عليه وسلم|صلى الله|صلي الله|صلى اللَّه/;
const isAr = (w: string) => /[ء-ي]/.test(w);
const trimW = (w: string) => w.replace(/^[^\p{L}\p{M}]+|[^\p{L}\p{M}]+$/gu, '');

export interface Phrase { i: number; docId: string; raw: string; gtMatn: string[]; gtText: string[]; variants: Record<string, string> }

function boundaryContains(hay: string, needle: string): boolean {
  let from = 0;
  for (;;) {
    const k = hay.indexOf(needle, from); if (k < 0) return false;
    const before = k ? hay[k - 1] : ' '; const after = hay[k + needle.length] ?? ' ';
    if (!/[\p{L}\p{M}]/u.test(before) && !/[\p{L}\p{M}]/u.test(after)) return true;
    from = k + 1;
  }
}
export function makeVariants(raw: string, r: () => number): Record<string, string> {
  const v: Record<string, string> = { o: raw };
  const nfc = NFC(raw);
  v.a = raw.replace(MARKS_RE, '');
  v.b = raw.replace(MARKS_RE, m => (r() < 0.5 ? '' : m));
  v.c1 = raw.replace(/[أإآ]/g, 'ا').replace(/ؤ/g, 'و').replace(/ئ/g, 'ي');
  v.c2 = raw.replace(/أ/g, '\u0001').replace(/إ/g, 'أ').replace(/\u0001/g, 'إ').replace(/آ/g, 'أ').replace(/(^|\s)ا/g, '$1أ');
  v.d = raw.replace(/[ىي]/g, m => (m === 'ى' ? 'ي' : 'ى'));
  v.e = raw.replace(/[ةه]/g, m => (m === 'ة' ? 'ه' : 'ة'));
  const ws = raw.split(' ');
  ws[0] = /^ال/.test(ws[0]) ? ws[0].replace(/^ال[ً-ْٰ]*/, '') : /^[^ا-ي]*[ا-ي]/.test(ws[0]) && !/^ل/.test(ws[0]) ? 'ال' + ws[0] : ws[0];
  v.f = ws.join(' ');
  let g = raw.replace(MARKS_RE, '').replace(/[أإآ]/g, 'ا').replace(/ؤ/g, 'و').replace(/ئ/g, 'ي').replace(/[ىي]/g, m => (m === 'ى' ? 'ي' : 'ى')).replace(/[ةه]/g, m => (m === 'ة' ? 'ه' : 'ة'));
  const gw = g.split(' '); gw[0] = /^ال/.test(gw[0]) ? gw[0].slice(2) : /^ل/.test(gw[0]) ? gw[0] : 'ال' + gw[0]; v.g = gw.join(' ');
  v.h = nfc.replace(/([ً-ْٰ])ّ/g, 'ّ$1'); // NFC order is vowel+shadda; reorder to shadda+vowel
  return v;
}

export function buildPhrases(docs: Doc[], n = 2000, seed = 424242) {
  const r = mulberry32(seed);
  const nfcMatn = docs.map(d => (d.matn_ar ? NFC(d.matn_ar) : '')); const nfcText = docs.map(d => NFC(d.text_ar));
  const idx = docs.map((_, i) => i).filter(i => docs[i].matn_ar && docs[i].matn_ar!.split(/\s+/).filter(isAr).length >= 3);
  for (let i = idx.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [idx[i], idx[j]] = [idx[j], idx[i]]; }
  const phrases: Phrase[] = []; let skippedFreq = 0, skippedSalut = 0, tried = 0;
  for (const di of idx) {
    if (phrases.length >= n) break; tried++;
    const ws = docs[di].matn_ar!.split(/\s+/).map(trimW).filter(w => w && isAr(w));
    const L = 3 + Math.floor(r() * 3); if (ws.length < L) continue;
    const s = Math.floor(r() * (ws.length - L + 1)); const raw = ws.slice(s, s + L).join(' ');
    if (SALUT.test(normChars(raw, false))) { skippedSalut++; continue; }
    const nf = NFC(raw);
    const gtM: string[] = []; for (let k = 0; k < docs.length; k++) if (nfcMatn[k].includes(nf) && boundaryContains(nfcMatn[k], nf)) gtM.push(docs[k].id);
    if (gtM.length > 20 || !gtM.length) { if (gtM.length > 20) skippedFreq++; continue; }
    const gtT: string[] = []; for (let k = 0; k < docs.length; k++) if (nfcText[k].includes(nf) && boundaryContains(nfcText[k], nf)) gtT.push(docs[k].id);
    phrases.push({ i: phrases.length, docId: docs[di].id, raw, gtMatn: gtM, gtText: gtT, variants: makeVariants(raw, r) });
  }
  return { phrases, skippedFreq, skippedSalut, tried };
}

export function getPhrases() {
  const cache = '/work/t1-phrases.local.json';
  if (fs.existsSync(cache)) return JSON.parse(fs.readFileSync(cache, 'utf8')) as ReturnType<typeof buildPhrases>;
  const P = buildPhrases(loadCorpus()); fs.writeFileSync(cache, JSON.stringify(P)); return P;
}

export async function runT1(e: Engine, index: string, cfgs: Cfg[], outDir: string) {
  const P = getPhrases();
  const { phrases } = P;
  type Job = { p: Phrase; v: string; q: string; field: Field; mode: 'phrase' | 'terms'; cfg: Cfg };
  const jobs: Job[] = [];
  for (const p of phrases) for (const [v, q] of Object.entries(p.variants)) {
    if (v !== 'o' && q === p.raw) continue; // variant not applicable to this phrase
    for (const field of ['matn_ar', 'text_ar'] as Field[]) { if (field === 'text_ar' && p.gtText.length > 20) continue; for (const mode of ['phrase', 'terms'] as const) for (const cfg of cfgs) jobs.push({ p, v, q, field, mode, cfg }); }
  }
  const rows: any[] = []; const errors: Record<string, { n: number; first: string }> = {};
  await pool(8, jobs, async j => {
    const gt = new Set(j.field === 'matn_ar' ? j.p.gtMatn : j.p.gtText);
    try {
      const res = await e.search(index, { q: j.q, fields: [j.field], mode: j.mode, cfg: j.cfg, size: 10 });
      let rr = 0, hit = 0; res.hits.forEach((h, k) => { if (gt.has(h.id)) { hit++; if (!rr) rr = 1 / (k + 1); } });
      rows.push([j.p.i, j.v, j.field, j.mode, j.cfg, hit / Math.min(gt.size, 10), rr, res.hits.length]);
    } catch (err: any) {
      const k = `${j.field}/${j.mode}/${j.cfg}/${j.v}`; const x = (errors[k] ??= { n: 0, first: String(err?.message ?? err).slice(0, 300) }); x.n++;
      rows.push([j.p.i, j.v, j.field, j.mode, j.cfg, null, null, -1]);
    }
  });
  const agg: Record<string, { n: number; recall: number; mrr: number; empty: number; err: number }> = {};
  for (const [, v, field, mode, cfg, rec, rr, nh] of rows) {
    const k = `${field}|${mode}|${cfg}|${v}`; const a = (agg[k] ??= { n: 0, recall: 0, mrr: 0, empty: 0, err: 0 });
    if (nh < 0) { a.err++; continue; } a.n++; a.recall += rec; a.mrr += rr; if (nh === 0) a.empty++;
  }
  const summary = Object.entries(agg).map(([k, a]) => { const [field, mode, cfg, variant] = k.split('|'); return { field, mode, cfg, variant, n: a.n, recall10: a.n ? a.recall / a.n : null, mrr: a.n ? a.mrr / a.n : null, noResultRate: a.n ? a.empty / a.n : null, errors: a.err }; });
  out(outDir, `t1-${e.name}.json`, { engine: e.name, phrases: phrases.length, skippedFreq: P.skippedFreq, skippedSalutation: P.skippedSalut, candidatesTried: P.tried, textFieldSkipped: phrases.filter(p => p.gtText.length > 20).length, jobs: jobs.length, errors, summary });
  fs.writeFileSync(`${outDir}/t1-${e.name}-raw.ndjson`, rows.map(r => JSON.stringify(r)).join('\n'));
  return summary;
}
