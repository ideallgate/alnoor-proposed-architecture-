import { Meilisearch } from 'meilisearch';
import type { Doc } from './data.js';
import { chunk, gradeRank, type Cfg, type Engine, type Field, type Req, type Res } from './engine.js';
import { norm } from './norm.js';
import { sleep } from './util.js';

const F: Field[] = ['text_ar', 'matn_ar', 'isnad_ar', 'book', 'chapter'];
const derived = F.flatMap(f => [`${f}_strict`, `${f}_merged`]);
export const MEILI_SETTINGS = {
  searchableAttributes: [...F, ...derived],
  filterableAttributes: ['book', 'chapter', 'grade_class'],
  sortableAttributes: ['grade_rank'],
  displayedAttributes: ['id', 'text_ar', 'isnad_ar', 'matn_ar', 'book', 'chapter', 'hadith_number', 'grade_class'],
  typoTolerance: { enabled: false },
};
const fname = (f: Field, cfg: Cfg) => (cfg === 'strict' ? `${f}_strict` : cfg === 'merged' ? `${f}_merged` : f);
const key = (id: string) => id.replace(/[^A-Za-z0-9_-]/g, '_');
export const LITE = { searchableAttributes: ['matn_ar_merged'], filterableAttributes: ['book', 'grade_class'], displayedAttributes: ['id'], typoTolerance: { enabled: false } };
const toLite = (d: Doc) => ({ doc_key: key(d.id), id: d.id, matn_ar: d.matn_ar, book: d.book, grade_class: d.grade_class, matn_ar_merged: d.matn_ar ? norm(d.matn_ar, true) : '' });
function toDoc(d: Doc) {
  const o: any = { doc_key: key(d.id), ...d, grade_rank: gradeRank(d.grade_class) };
  for (const f of F) { const v = (d as any)[f]; o[`${f}_strict`] = v ? norm(v, false) : ''; o[`${f}_merged`] = v ? norm(v, true) : ''; }
  return o;
}
const q$ = (s: string) => s.replace(/"/g, ' ');
export class Meili implements Engine {
  name = 'meilisearch';
  c = new Meilisearch({ host: process.env.MEILI_URL!, timeout: 600000 } as any);
  async waitReady() { for (let i = 0; i < 300; i++) { try { await this.c.health(); return; } catch { await sleep(1000); } } throw new Error('meili not ready'); }
  private async wait(uid: number) { const t: any = await this.c.tasks.waitForTask(uid, { timeout: 24 * 3600 * 1000, interval: 200 } as any); if (t.status !== 'succeeded') throw new Error('meili task failed: ' + JSON.stringify(t.error)); return t; }
  async setup(index: string) {
    await this.drop(index);
    await this.wait((await this.c.createIndex(index, { primaryKey: 'doc_key' })).taskUid);
    await this.wait((await this.c.index(index).updateSettings((index.startsWith('lite') ? LITE : MEILI_SETTINGS) as any)).taskUid);
  }
  async load(index: string, docs: Iterable<Doc>) {
    const ids: number[] = [];
    for (const b of chunk(docs, 5000)) { ids.push((await this.c.index(index).addDocuments(b.map(index.startsWith('lite') ? toLite : toDoc))).taskUid); if (ids.length >= 4) await this.wait(ids.shift()!); }
    for (const u of ids) await this.wait(u);
  }
  private params(r: Req) {
    const filter: string[] = [];
    if (r.book) filter.push(`book = "${r.book.replace(/"/g, '\\"')}"`);
    if (r.grade_class) filter.push(`grade_class = "${r.grade_class}"`);
    const qq = r.cfg === 'strict' ? norm(r.q, false) : r.cfg === 'merged' ? norm(r.q, true) : r.q;
    return { q: r.mode === 'phrase' ? `"${q$(qq)}"` : qq, p: { attributesToSearchOn: r.fields.map(f => fname(f, r.cfg)), matchingStrategy: 'all', filter: filter.length ? filter.join(' AND ') : undefined } as any };
  }
  async search(index: string, r: Req): Promise<Res> {
    const { q, p } = this.params(r);
    p.limit = r.size ?? 10; p.attributesToRetrieve = ['id'];
    if (r.hl) { p.attributesToHighlight = ['text_ar']; p.highlightPreTag = '<em>'; p.highlightPostTag = '</em>'; p.attributesToRetrieve = ['id', 'text_ar']; }
    if (r.gradeBoost) p.sort = ['grade_rank:desc'];
    const x: any = await this.c.index(index).search(q, p);
    return { total: x.estimatedTotalHits ?? 0, hits: x.hits.map((h: any) => ({ id: h.id, hl: h._formatted?.text_ar })) };
  }
  async count(index: string, r: Req) { const { q, p } = this.params(r); p.hitsPerPage = 1; p.page = 1; p.attributesToRetrieve = ['id']; return ((await this.c.index(index).search(q, p)) as any).totalHits; }
  async get(index: string, id: string) { try { return (await this.c.index(index).getDocument(key(id))) as any; } catch (e: any) { if (e.cause?.code === 'document_not_found') return null; throw e; } }
  async update(index: string, id: string, patch: any) { const d: any = await this.c.index(index).getDocument(key(id)); await this.c.index(index).updateDocuments([toDoc({ ...d, ...patch })]); }
  async bulkUpdate(index: string, ups: any[]) {
    const docs: any[] = []; for (const u of ups) { const d: any = await this.c.index(index).getDocument(key(u.id)); docs.push(toDoc({ ...d, ...u.patch })); }
    const t = await this.c.index(index).updateDocuments(docs); await this.wait(t.taskUid);
  }
  async facet(index: string, field: any, filter: any = {}) {
    const fl: string[] = []; if (filter.book) fl.push(`book = "${filter.book}"`); if (filter.grade_class) fl.push(`grade_class = "${filter.grade_class}"`);
    const x: any = await this.c.index(index).search('', { facets: [field], limit: 0, filter: fl.join(' AND ') || undefined } as any);
    return x.facetDistribution?.[field] ?? {};
  }
  async stats(index: string) { const s: any = await this.c.index(index).getStats(); const g: any = await this.c.getStats(); return { docs: s.numberOfDocuments, bytes: (g.usedDatabaseSize ?? g.databaseSize) as number }; }
  async setFieldPriority(index: string, order: Field[]) {
    const rest = MEILI_SETTINGS.searchableAttributes.filter(a => !order.includes(a as Field));
    await this.wait((await this.c.index(index).updateSearchableAttributes([...order, ...rest])).taskUid);
  }
  async drop(index: string) { try { await this.wait((await this.c.deleteIndex(index)).taskUid); } catch { /* absent */ } }
  settingsSummary() { return MEILI_SETTINGS; }
  async close() {}
}
