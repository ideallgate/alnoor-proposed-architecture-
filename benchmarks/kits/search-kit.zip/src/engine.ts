import type { Doc } from './data.js';
export type Cfg = 'none' | 'rec' | 'strict' | 'merged';
export type Field = 'text_ar' | 'matn_ar' | 'isnad_ar' | 'book' | 'chapter';
export interface Req { q: string; fields: Field[]; mode: 'phrase' | 'terms' | 'prefix'; cfg: Cfg; size?: number; book?: string; grade_class?: string; hl?: boolean; boosts?: Partial<Record<Field, number>>; gradeBoost?: boolean; }
export interface Hit { id: string; hl?: string }
export interface Res { hits: Hit[]; total: number }
export interface Engine {
  name: string;
  waitReady(): Promise<void>;
  setup(index: string): Promise<void>;
  load(index: string, docs: Iterable<Doc>): Promise<void>;
  search(index: string, r: Req): Promise<Res>;
  count(index: string, r: Req): Promise<number>;
  get(index: string, id: string): Promise<Doc | null>;
  update(index: string, id: string, patch: { text_ar: string; matn_ar: string | null }): Promise<void>;
  bulkUpdate(index: string, ups: { id: string; patch: { text_ar: string; matn_ar: string | null } }[]): Promise<void>;
  facet(index: string, field: 'book' | 'chapter' | 'grade_class', filter?: { book?: string; grade_class?: string }): Promise<Record<string, number>>;
  stats(index: string): Promise<{ docs: number; bytes: number }>;
  compact?(index: string): Promise<{ bytes: number }>;
  drop(index: string): Promise<void>;
  setFieldPriority?(index: string, order: Field[]): Promise<void>;
  settingsSummary(): unknown;
  close(): Promise<void>;
}
export const gradeRank = (g: string | null) => ({ sahih: 4, hasan: 3, qawi: 2, daif: 1, other: 1, maudu: 0 } as Record<string, number>)[g ?? ''] ?? 0;
export function chunk<T>(it: Iterable<T>, n: number): Generator<T[]> {
  return (function* () { let b: T[] = []; for (const x of it) { b.push(x); if (b.length >= n) { yield b; b = []; } } if (b.length) yield b; })();
}
