import fs from 'node:fs';
import path from 'node:path';
export function mulberry32(a: number) {
  return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
export const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));
export const now = () => performance.now();
export function pct(sorted: number[], p: number) { if (!sorted.length) return NaN; return sorted[Math.min(sorted.length - 1, Math.floor(p * sorted.length))]; }
export function median(a: number[]) { const s = [...a].sort((x, y) => x - y); const n = s.length; return n ? (n % 2 ? s[(n - 1) / 2] : (s[n / 2 - 1] + s[n / 2]) / 2) : NaN; }
export function out(dir: string, name: string, data: unknown) {
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, name), typeof data === 'string' ? data : JSON.stringify(data, null, 1));
}
export function arg(name: string, def?: string) { const i = process.argv.indexOf('--' + name); return i > 0 ? process.argv[i + 1] : def; }
export async function pool<T>(n: number, items: T[], fn: (x: T, i: number) => Promise<void>) {
  let i = 0; await Promise.all(Array.from({ length: n }, async () => { while (i < items.length) { const k = i++; await fn(items[k], k); } }));
}
/** bounded-concurrency consumer over a (lazy) iterable, so very large loads stream instead of materialising */
export async function streamPool<T>(n: number, it: Iterable<T>, fn: (x: T) => Promise<void>) {
  const inflight = new Set<Promise<void>>();
  for (const x of it) { const p: Promise<void> = fn(x).finally(() => inflight.delete(p)); inflight.add(p); if (inflight.size >= n) await Promise.race(inflight); }
  await Promise.all(inflight);
}
