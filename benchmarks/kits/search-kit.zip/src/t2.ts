import { getPhrases } from './t1.js';
import { loadCorpus, type Doc } from './data.js';
import { mulberry32, out, median, now } from './util.js';
import { norm, NFC } from './norm.js';
import type { Cfg, Engine, Field, Req } from './engine.js';

const strip = (s: string) => s.replace(/<\/?em>/g, '');
const mean = (a: number[]) => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : NaN);
const seqIn = (hay: string[], nd: string[]) => { for (let i = 0; i + nd.length <= hay.length; i++) if (nd.every((t, k) => hay[i + k] === t)) return true; return false; };

export async function runT2(e: Engine, index: string, cfgs: Cfg[], outDir: string) {
  const docs = loadCorpus(); const byId = new Map(docs.map(d => [d.id, d])); const r = mulberry32(2024);
  const P = getPhrases().phrases as any[];
  const res: any = { engine: e.name };
  const merged: Cfg = 'merged';
  // 1+2 search in text_ar / matn_ar (variant a, phrase, source doc must be in top 10)
  for (const f of ['text_ar', 'matn_ar'] as Field[]) {
    let hit = 0, n = 0; for (const p of P.slice(0, 150)) { const s = await e.search(index, { q: p.variants.a, fields: [f], mode: 'phrase', cfg: merged, size: 10 }); n++; if (s.hits.some(h => h.id === p.docId)) hit++; }
    res[`search_${f}`] = { queries: n, sourceDocInTop10: hit / n };
  }
  // 3 books / chapters
  const books = [...new Set(docs.map(d => d.book))]; let bp: number[] = [];
  for (const b of books) { const s = await e.search(index, { q: b, fields: ['book'], mode: 'phrase', cfg: merged, size: 10 }); bp.push(s.hits.length ? mean(s.hits.map(h => (byId.get(h.id)!.book === b ? 1 : 0))) : 0); }
  const chapters = [...new Set(docs.map(d => d.chapter))]; const cs = Array.from({ length: 60 }, () => chapters[Math.floor(r() * chapters.length)]); const cp: number[] = []; let chEmpty = 0;
  for (const c of cs) { const s = await e.search(index, { q: c, fields: ['chapter'], mode: 'phrase', cfg: merged, size: 10 }); if (!s.hits.length) chEmpty++; cp.push(s.hits.length ? mean(s.hits.map(h => (byId.get(h.id)!.chapter === c ? 1 : 0))) : 0); }
  res.books = { queries: books.length, precisionAt10: mean(bp) }; res.chapters = { queries: cs.length, precisionAt10: mean(cp), emptyResults: chEmpty };
  // 4 suggestions
  { const lat: number[] = []; let nonEmpty = 0, valid = 0, n = 0;
    for (const p of P.slice(200, 400)) { const w = p.variants.a.split(' '); if (w.length < 2) continue; const last = w[1]; const q = w[0] + ' ' + last.slice(0, Math.max(2, Math.min(3, last.length - 1)));
      const t = now(); const s = await e.search(index, { q, fields: ['matn_ar'], mode: 'prefix', cfg: merged, size: 10 }); lat.push(now() - t); n++;
      if (s.hits.length) { nonEmpty++; const qt = norm(q, true).split(' '); const ok = s.hits.filter(h => { const t2 = norm(byId.get(h.id)!.matn_ar ?? '', true).split(' '); return t2.some((tok, i) => tok === qt[0] && t2[i + 1]?.startsWith(qt[1] ?? '')); }).length; valid += ok / s.hits.length; } }
    lat.sort((a, b) => a - b); res.suggest = { queries: n, nonEmptyRate: nonEmpty / n, adjacentPrefixPrecision: valid / Math.max(1, nonEmpty), p50ms: lat[Math.floor(lat.length / 2)] }; }
  // 5 highlighting (original vocalized text_ar), per config
  res.highlight = {};
  for (const cfg of cfgs) {
    const o = { queries: 0, withEm: 0, textIntact: 0, precision: [] as number[], coverage: [] as number[], sample: [] as any[] };
    for (const [vi, v] of ['a', 'g', 'o'].entries()) for (const p of P.slice(500, 560)) {
      const q = p.variants[v]; if (v === 'g' && q === p.raw) continue;
      let s; try { s = await e.search(index, { q, fields: ['text_ar'], mode: 'phrase', cfg, size: 3, hl: true }); } catch { continue; }
      const h = s.hits.find(x => x.id === p.docId) ?? s.hits[0]; if (!h) continue; o.queries++;
      if (!h.hl || !/<em>/.test(h.hl)) { if (o.sample.length < 2 && v === 'a') o.sample.push({ v, q: '(local)', hl: null }); continue; }
      o.withEm++; if (NFC(strip(h.hl)) === NFC(byId.get(h.id)!.text_ar)) o.textIntact++;
      const em = [...h.hl.matchAll(/<em>(.*?)<\/em>/gs)].map(m => m[1]); const et = new Set(em.flatMap(x => norm(x, true).split(' ')).filter(Boolean)); const qt = new Set(norm(q, true).split(' ').filter(Boolean));
      o.precision.push([...et].filter(t => qt.has(t)).length / Math.max(1, et.size)); o.coverage.push([...qt].filter(t => et.has(t)).length / Math.max(1, qt.size));
      if (o.sample.length < 2) o.sample.push({ v, hl: h.hl.slice(0, 200) });
    }
    (res._local ??= { highlightSamples: {} }).highlightSamples[cfg] = o.sample;
    res.highlight[cfg] = { queries: o.queries, withHighlight: o.withEm / o.queries, textUnchanged: o.textIntact / Math.max(1, o.withEm), meanSpanPrecision: mean(o.precision), meanQueryTermCoverage: mean(o.coverage) };
  }
  // 6 ranking controls
  { const words: string[] = []; for (const d of docs.slice(0, 20000)) { if (d.isnad_ar && d.matn_ar && words.length < 40 && r() < .01) { const w = d.isnad_ar.replace(/[ً-ْٰ]/g, '').split(/\s+/).filter(x => x.length > 3 && !/[،,:"]/.test(x)); if (w.length) words.push(w[Math.floor(r() * w.length)]); } }
    const qs = [...new Set(words)].slice(0, 30);
    const fields: Field[] = ['isnad_ar', 'matn_ar'];
    const run = (boosts: any) => Promise.all(qs.map(q => e.search(index, { q, fields, mode: 'terms', cfg: merged, size: 10, boosts })));
    let A: any[], B: any[], mode = 'numeric weights';
    A = await run({ isnad_ar: 1, matn_ar: 1 });
    if (e.setFieldPriority) { mode = 'attribute priority order (no numeric weights); settings update + reindex'; await e.setFieldPriority(index, ['isnad_ar', 'matn_ar']); A = await run({}); await e.setFieldPriority(index, ['matn_ar', 'isnad_ar']); B = await run({}); await e.setFieldPriority(index, ['text_ar', 'matn_ar', 'isnad_ar']); }
    else B = await run({ isnad_ar: 1, matn_ar: 8 });
    const changed = A.filter((a, i) => a.hits.map((h: any) => h.id).join() !== B[i].hits.map((h: any) => h.id).join()).length;
    const ov = A.map((a, i) => { const sa = new Set(a.hits.map((h: any) => h.id)); return B[i].hits.length ? B[i].hits.filter((h: any) => sa.has(h.id)).length / B[i].hits.length : 1; });
    res.fieldBoost = { mechanism: mode, queries: qs.length, top10Changed: changed, meanTop10Overlap: mean(ov) };
    const cq = qs.slice(0, 30); const frac = (rs: any[]) => mean(rs.map(x => x.hits.length ? x.hits.filter((h: any) => byId.get(h.id)!.grade_class === 'sahih').length / x.hits.length : 0));
    const U = await Promise.all(cq.map(q => e.search(index, { q, fields: ['matn_ar'], mode: 'terms', cfg: merged, size: 10 })));
    const G = await Promise.all(cq.map(q => e.search(index, { q, fields: ['matn_ar'], mode: 'terms', cfg: merged, size: 10, gradeBoost: true })));
    res.gradeBoost = { queries: cq.length, sahihShareTop10_unboosted: frac(U), sahihShareTop10_boosted: frac(G), corpusSahihShareOfAll: docs.filter(d => d.grade_class === 'sahih').length / docs.length }; }
  // 7 navigation by document id
  { let ok = 0; const sample = Array.from({ length: 60 }, () => docs[Math.floor(r() * docs.length)]); for (const d of sample) { const g = await e.get(index, d.id); if (g && NFC(g.text_ar) === NFC(d.text_ar) && g.book === d.book && String(g.hadith_number) === d.hadith_number) ok++; } res.navigation = { ids: sample.length, roundTripOk: ok / sample.length }; }
  // 8 narrator names inside isnad_ar
  { const cnt = new Map<string, { n: number; raw: string }>();
    for (const d of docs) { if (!d.isnad_ar) continue; for (const m of d.isnad_ar.matchAll(/عَنْ\s+([^\s،,]+\s+[^\s،,]+)/g)) { const k = norm(m[1], true); const x = cnt.get(k); if (x) x.n++; else cnt.set(k, { n: 1, raw: m[1] }); } }
    const names = [...cnt.entries()].filter(([k, v]) => v.n >= 30 && k.split(' ').length === 2 && !/رسول|نبي/.test(k) && !/ (بن|ابن)$/.test(k)).sort((a, b) => b[1].n - a[1].n).slice(0, 15);
    const tokDocs = docs.map(d => (d.isnad_ar ? norm(d.isnad_ar, true).split(' ') : []));
    const pos = new Map(docs.map((d, i) => [d.id, i]));
    res.narrator = []; for (const [k, v] of names) { const nd = k.split(' '); const oracle = tokDocs.reduce((a, t) => a + (seqIn(t, nd) ? 1 : 0), 0);
      const q = v.raw.replace(/[ً-ْٰ]/g, '');
      const s = await e.search(index, { q, fields: ['isnad_ar'], mode: 'phrase', cfg: merged, size: 10 }); const c = await e.count(index, { q, fields: ['isnad_ar'], mode: 'phrase', cfg: merged });
      const prec = s.hits.length ? mean(s.hits.map(h => (seqIn(tokDocs[pos.get(h.id)!], nd) ? 1 : 0))) : 0;
      (res._local ??= { highlightSamples: {} }).narratorNames = [...(res._local.narratorNames ?? []), k];
      res.narrator.push({ nameIndex: res.narrator.length, oracleDocCount: oracle, engineDocCount: c, precisionAt10: prec }); } }
  // 9 capability on stand-in fields (book, chapter, grade_class)
  { const oracle = (f: 'book' | 'chapter' | 'grade_class', flt?: (d: Doc) => boolean) => { const m: Record<string, number> = {}; for (const d of docs) { if (flt && !flt(d)) continue; const v = d[f]; if (v !== null) m[v] = (m[v] ?? 0) + 1; } return m; };
    const eq = (a: Record<string, number>, b: Record<string, number>) => Object.keys(b).length === Object.keys(a).length && Object.entries(b).every(([k, v]) => Number(a[k]) === v);
    const bk = books[0];
    res.capability = {
      facetBook: eq(await e.facet(index, 'book'), oracle('book')), facetChapter: eq(await e.facet(index, 'chapter'), oracle('chapter')), facetGradeClass: eq(await e.facet(index, 'grade_class'), oracle('grade_class')),
      facetGradeClassWithinBook: eq(await e.facet(index, 'grade_class', { book: bk }), oracle('grade_class', d => d.book === bk)),
      filteredCountMatchesOracle: await (async () => { const q = 'رسول'; const cnt = await e.count(index, { q, fields: ['matn_ar'], mode: 'terms', cfg: 'merged', grade_class: 'sahih' }); const exp = docs.filter(d => d.grade_class === 'sahih' && d.matn_ar && norm(d.matn_ar, true).split(' ').includes('رسول')).length; return { engine: cnt, oracleExactToken: exp }; })(),
    }; }
  const local = res._local; delete res._local; out(outDir, `t2-${e.name}.json`, res); out(outDir, `t2-${e.name}.local.json`, local);
  return res;
}
