import fs from 'node:fs';
import readline from 'node:readline';
import { mulberry32 } from './util.js';
export interface Doc { id: string; text_ar: string; isnad_ar: string | null; matn_ar: string | null; book: string; chapter: string; hadith_number: string; grade_class: string | null; }
const FILE = '/data/open-corpus/hadith.jsonl';
const keep = (r: any): Doc => ({ id: r.id, text_ar: r.text_ar, isnad_ar: r.isnad_ar ?? null, matn_ar: r.matn_ar ?? null, book: r.book, chapter: r.chapter, hadith_number: String(r.hadith_number), grade_class: r.grade_class ?? null });
export function loadCorpus(): Doc[] {
  return fs.readFileSync(FILE, 'utf8').split('\n').filter(Boolean).map(l => keep(JSON.parse(l)));
}
/** Synthetic copy k (k>=1): new id, one random non-first word dropped from text_ar and matn_ar. LATENCY/SIZE USE ONLY. */
export function perturb(d: Doc, k: number): Doc {
  const r = mulberry32((k * 2654435761) ^ hash(d.id));
  const drop = (s: string | null) => { if (!s) return s; const w = s.split(' '); if (w.length < 7) return s; w.splice(1 + Math.floor(r() * (w.length - 1)), 1); return w.join(' '); };
  return { ...d, id: `${d.id}#s${k}`, text_ar: drop(d.text_ar)!, matn_ar: drop(d.matn_ar) };
}
function hash(s: string) { let h = 2166136261; for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619); return h >>> 0; }
export function* scaled(base: Doc[], factor: number): Generator<Doc> {
  for (let k = 0; k < factor; k++) for (const d of base) yield k === 0 ? d : perturb(d, k);
}
export const GRADE_RANK: Record<string, number> = { sahih: 4, hasan: 3, qawi: 2, daif: 1, maudu: 0, other: 1 };
