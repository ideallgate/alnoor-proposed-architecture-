import pg from 'pg';
import type { Doc } from './data.js';
import { chunk, gradeRank, type Cfg, type Engine, type Field, type Req, type Res } from './engine.js';
import { MARK_CLASS, FOLD_FROM, FOLD_TO, TM_FROM, TM_TO, norm } from './norm.js';
import { sleep, streamPool } from './util.js';

const F: Field[] = ['text_ar', 'matn_ar', 'isnad_ar', 'book', 'chapter'];
const CFGS: Cfg[] = ['none', 'rec', 'strict', 'merged'];
const vcol = (f: Field, c: Cfg) => `v_${f}_${c}`;
const tsExpr = (f: Field, c: Cfg) => c === 'none' ? `to_tsvector('simple', coalesce(${f},''))` : c === 'rec' ? `to_tsvector('arabic', coalesce(${f},''))` : `to_tsvector('simple', ar_norm_${c === 'strict' ? 's' : 'm'}(coalesce(${f},'')))`;
const fnSql = (suffix: string, merged: boolean) => `
CREATE OR REPLACE FUNCTION ar_norm_${suffix}(t text) RETURNS text LANGUAGE sql IMMUTABLE PARALLEL SAFE AS $$
 SELECT regexp_replace(translate(regexp_replace(t, '[${MARK_CLASS}]', '', 'g'), '${FOLD_FROM}${merged ? TM_FROM : ''}', '${FOLD_TO}${merged ? TM_TO : ''}'),
        '(^|[^[:alpha:]])ال(?=[[:alpha:]]{2})', '\\1', 'g') $$;`;
export const PG_DDL = (t: string) => `
${fnSql('s', false)}
${fnSql('m', true)}
CREATE TABLE ${t} (
 id text PRIMARY KEY, text_ar text NOT NULL, isnad_ar text, matn_ar text, book text, chapter text, hadith_number text, grade_class text, grade_rank smallint,
 ${F.flatMap(f => CFGS.map(c => `${vcol(f, c)} tsvector GENERATED ALWAYS AS (${tsExpr(f, c)}) STORED`)).join(',\n ')}
);`;
export const PG_LITE_DDL = (t: string) => `
${fnSql('s', false)}
${fnSql('m', true)}
CREATE TABLE ${t} (id text PRIMARY KEY, matn_ar text, book text, grade_class text, ${vcol('matn_ar', 'merged')} tsvector GENERATED ALWAYS AS (${tsExpr('matn_ar', 'merged')}) STORED);`;
export const PG_LITE_POST = (t: string) => [`CREATE INDEX ${t}_v ON ${t} USING gin (${vcol('matn_ar', 'merged')})`, `CREATE INDEX ${t}_book ON ${t}(book)`, `CREATE INDEX ${t}_gc ON ${t}(grade_class)`, `ANALYZE ${t}`];
export const PG_POST = (t: string) => [...F.flatMap(f => CFGS.map(c => `CREATE INDEX ${t}_${vcol(f, c)} ON ${t} USING gin (${vcol(f, c)})`)), `CREATE INDEX ${t}_book ON ${t}(book)`, `CREATE INDEX ${t}_gc ON ${t}(grade_class)`, `ANALYZE ${t}`];

const cfgName = (c: Cfg) => (c === 'rec' ? 'arabic' : 'simple');
export class Pg implements Engine {
  name = 'postgres';
  p = new pg.Pool({ connectionString: process.env.PG_URL, max: 60 });
  async waitReady() { for (let i = 0; i < 300; i++) { try { await this.p.query('select 1'); return; } catch { await sleep(1000); } } throw new Error('pg not ready'); }
  private t = (i: string) => 'd_' + i.replace(/[^a-z0-9_]/gi, '_');
  async setup(index: string) { await this.drop(index); await this.p.query((index.startsWith('lite') ? PG_LITE_DDL : PG_DDL)(this.t(index))); }
  async load(index: string, docs: Iterable<Doc>) {
    const t = this.t(index);
    const lite = index.startsWith('lite');
    await streamPool(2, chunk(docs, 1000), async b => {
      if (lite) { await this.p.query(`INSERT INTO ${t}(id,matn_ar,book,grade_class) SELECT * FROM unnest($1::text[],$2::text[],$3::text[],$4::text[])`, [b.map(d => d.id), b.map(d => d.matn_ar), b.map(d => d.book), b.map(d => d.grade_class)]); return; }
      await this.p.query(`INSERT INTO ${t}(id,text_ar,isnad_ar,matn_ar,book,chapter,hadith_number,grade_class,grade_rank) SELECT * FROM unnest($1::text[],$2::text[],$3::text[],$4::text[],$5::text[],$6::text[],$7::text[],$8::text[],$9::int2[])`,
        [b.map(d => d.id), b.map(d => d.text_ar), b.map(d => d.isnad_ar), b.map(d => d.matn_ar), b.map(d => d.book), b.map(d => d.chapter), b.map(d => d.hadith_number), b.map(d => d.grade_class), b.map(d => gradeRank(d.grade_class))]);
    });
    for (const s of (lite ? PG_LITE_POST : PG_POST)(t)) await this.p.query(s);
  }
  /** tsquery SQL fragment + params */
  private tsq(r: Req, params: any[]) {
    const c = r.cfg; const cfg = cfgName(c);
    const qn = c === 'strict' ? norm(r.q, false) : c === 'merged' ? norm(r.q, true) : r.q;
    if (r.mode === 'prefix') {
      const w = qn.split(/\s+/).filter(Boolean).map(x => `'${x.replace(/'/g, "''").replace(/\\/g, ' ')}'`);
      if (!w.length) return `to_tsquery('${cfg}','')`;
      w[w.length - 1] += ':*'; params.push(w.join(' & ')); return `to_tsquery('${cfg}', $${params.length})`;
    }
    params.push(qn); return `${r.mode === 'phrase' ? 'phraseto_tsquery' : 'plainto_tsquery'}('${cfg}', $${params.length})`;
  }
  private where(r: Req, params: any[]) {
    const tq = this.tsq(r, params);
    const cond = r.fields.map(f => `${vcol(f, r.cfg)} @@ ${tq}`);
    const rank = r.fields.map(f => `${r.boosts?.[f] ?? 1} * ts_rank(${vcol(f, r.cfg)}, ${tq})`).join(' + ');
    let w = `(${cond.join(' OR ')})`;
    if (r.book) { params.push(r.book); w += ` AND book = $${params.length}`; }
    if (r.grade_class) { params.push(r.grade_class); w += ` AND grade_class = $${params.length}`; }
    return { w, rank, tq };
  }
  async search(index: string, r: Req): Promise<Res> {
    const t = this.t(index); const params: any[] = []; const { w, rank, tq } = this.where(r, params);
    const ord = r.gradeBoost ? `(${rank}) * (1 + 0.25 * grade_rank)` : rank;
    const hl = r.hl ? `, ts_headline('simple', text_ar, ${tq}, 'StartSel=<em>,StopSel=</em>,HighlightAll=true') AS hl` : '';
    const x = await this.p.query(`SELECT id${hl} FROM ${t} WHERE ${w} ORDER BY ${ord} DESC, id LIMIT ${r.size ?? 10}`, params);
    return { total: -1, hits: x.rows.map(o => ({ id: o.id, hl: o.hl })) };
  }
  async count(index: string, r: Req) { const params: any[] = []; const { w } = this.where(r, params); return Number((await this.p.query(`SELECT count(*) c FROM ${this.t(index)} WHERE ${w}`, params)).rows[0].c); }
  async get(index: string, id: string) { const x = await this.p.query(`SELECT id,text_ar,isnad_ar,matn_ar,book,chapter,hadith_number,grade_class FROM ${this.t(index)} WHERE id=$1`, [id]); return (x.rows[0] as Doc) ?? null; }
  async update(index: string, id: string, patch: any) { await this.p.query(`UPDATE ${this.t(index)} SET text_ar=$2, matn_ar=$3 WHERE id=$1`, [id, patch.text_ar, patch.matn_ar]); }
  async bulkUpdate(index: string, ups: any[]) {
    await this.p.query(`UPDATE ${this.t(index)} d SET text_ar=u.t, matn_ar=u.m FROM unnest($1::text[],$2::text[],$3::text[]) u(id,t,m) WHERE d.id=u.id`, [ups.map(u => u.id), ups.map(u => u.patch.text_ar), ups.map(u => u.patch.matn_ar)]);
  }
  async facet(index: string, field: any, filter: any = {}) {
    const params: any[] = []; const wh: string[] = [];
    if (filter.book) { params.push(filter.book); wh.push(`book=$${params.length}`); } if (filter.grade_class) { params.push(filter.grade_class); wh.push(`grade_class=$${params.length}`); }
    const x = await this.p.query(`SELECT ${field} k, count(*) c FROM ${this.t(index)} ${wh.length ? 'WHERE ' + wh.join(' AND ') : ''} GROUP BY 1`, params);
    return Object.fromEntries(x.rows.filter(o => o.k !== null).map(o => [o.k, Number(o.c)]));
  }
  async stats(index: string) { const t = this.t(index); const x = await this.p.query(`SELECT pg_total_relation_size('${t}') b, (SELECT count(*) FROM ${t}) n`); return { docs: Number(x.rows[0].n), bytes: Number(x.rows[0].b) }; }
  async compact(index: string) { await this.p.query(`VACUUM FULL ${this.t(index)}`); return { bytes: (await this.stats(index)).bytes }; }
  async drop(index: string) { await this.p.query(`DROP TABLE IF EXISTS ${this.t(index)}`); }
  settingsSummary() { return { ddl: PG_DDL('docs'), post: PG_POST('docs'), server: 'see docker-compose.yml command' }; }
  async close() { await this.p.end(); }
}
