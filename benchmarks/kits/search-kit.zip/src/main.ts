import { loadCorpus, scaled } from './data.js';
import { OpenSearch } from './opensearch.js';
import { Meili } from './meili.js';
import { Pg } from './pg.js';
import type { Cfg, Engine } from './engine.js';
import { runT1 } from './t1.js';
import { runT2 } from './t2.js';
import { runT3 } from './t3.js';
import { indexRuns, updateRuns } from './t4.js';
import { packRun, packBuild } from './pack.js';
import { arg, out } from './util.js';

const [engineName, phase] = process.argv.slice(2);
const pass = arg('pass', 'pass1')!; const outDir = `/results-${pass.replace('pass', 'pass')}`.replace('/results-pass', '/results-pass');
const mk = (n: string): Engine => (n === 'opensearch' ? new OpenSearch() : n === 'meilisearch' ? new Meili() : new Pg());
const cfgsFor = (n: string): Cfg[] => (n === 'meilisearch' ? ['none', 'strict', 'merged'] : ['none', 'rec', 'strict', 'merged']);

async function main() {
  if (phase === 'report') { await import('./report.js'); return; }
  if (phase === 'pack-build') { packBuild('/work', '/review-pack'); return; }
  const e = mk(engineName); await e.waitReady();
  const index = arg('index', 'hadith')!;
  try {
    switch (phase) {
      case 'wait': break;
      case 'settings': out(outDir, `settings-${e.name}.json`, e.settingsSummary()); break;
      case 'index': await indexRuns(e, index, loadCorpus(), Number(arg('runs', '1')), outDir, 'real'); break;
      case 't1': await runT1(e, index, cfgsFor(e.name), outDir); break;
      case 't2': await runT2(e, index, cfgsFor(e.name), outDir); break;
      case 't3': await runT3(e, index, arg('label', 'real')!, outDir, { runs: Number(arg('runs', '5')), reqs: Number(arg('reqs', '5000')), conc: (arg('conc', '1,10,50')!).split(',').map(Number), capSec: Number(arg('cap', '900')), warm: 300 }); break;
      case 'updates': await updateRuns(e, index, Number(arg('runs', '5')), pass, outDir); break;
      case 'scale': { const f = Number(arg('factor')); const base = loadCorpus(); await indexRuns(e, index, () => scaled(base, f), 1, outDir, `lite-x${f}`); break; }
      case 'drop': await e.drop(index); break;
      case 'pack-run': await packRun(e, index, '/work'); break;
      case 'stats': console.log(JSON.stringify(await e.stats(index))); break;
      default: throw new Error('unknown phase ' + phase);
    }
  } finally { await e.close(); }
}
main().catch(err => { console.error('FATAL', err); process.exit(1); });
