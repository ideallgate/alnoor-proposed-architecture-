// Shared Arabic normalization spec, used for (a) OpenSearch/PG chains (generated from these constants)
// and (b) application-side normalization for Meilisearch. Not applied to stored displayed data.
export const MARK_CLASS = '\\u064B-\\u065F\\u0670\\u0640\\u06D6-\\u06ED'; // harakat, shadda, sukun, dagger alef, tatweel, quranic marks
export const FOLD_FROM = 'أإآٱىؤئ';
export const FOLD_TO = 'اااا' + 'ي' + 'و' + 'ي'; // أإآٱ->ا  ى->ي  ؤ->و  ئ->ي
export const TM_FROM = 'ة';
export const TM_TO = 'ه';
const markRe = new RegExp(`[${MARK_CLASS}]`, 'g');
const foldMap = new Map([...FOLD_FROM].map((c, i) => [c, FOLD_TO[i]]));

export function normChars(s: string, merged: boolean): string {
  let t = s.replace(markRe, '');
  let o = '';
  for (const c of t) o += foldMap.get(c) ?? (merged && c === TM_FROM ? TM_TO : c);
  return o;
}
export function tokens(s: string): string[] {
  return s.match(/[\p{L}\p{N}]+/gu) ?? [];
}
/** token-level: strip leading definite article if token has >=2 more letters */
export function stripArticle(w: string): string {
  return /^ال.{2,}/.test(w) ? w.slice(2) : w;
}
export function norm(s: string, merged: boolean): string {
  return tokens(normChars(s, merged)).map(stripArticle).join(' ');
}
export const NFC = (s: string) => s.normalize('NFC');
