import fs from 'node:fs';
import { loadCorpus, type Doc } from './data.js';
import { mulberry32, out } from './util.js';
import { norm } from './norm.js';
import type { Engine, Req } from './engine.js';

const MARKS = /[ً-ْٰ]/g;
const BAD = /وسلم|صلى|صلي|الله|رسول/;
export interface PQ { id: number; kind: string; q: string; mode: Req['mode']; fields: Req['fields'] }
export function pickQueries(docs: Doc[]): PQ[] {
  const r = mulberry32(31337); const Q: PQ[] = []; let id = 1;
  const nxt = () => { for (;;) { const d = docs[Math.floor(r() * docs.length)]; if (!d.matn_ar) continue; const w = d.matn_ar.split(/\s+/).map(x => x.replace(/[^\p{L}\p{M}]/gu, '')).filter(x => x.length > 2 && !BAD.test(x.replace(MARKS, ''))); if (w.length >= 6) return w; } };
  for (let i = 0; i < 10; i++) { const w = nxt(); const s = Math.floor(r() * (w.length - 4)); let q = w.slice(s, s + 3 + (i % 2)).join(' '); if (i % 2) q = q.replace(MARKS, ''); Q.push({ id: id++, kind: i % 2 ? 'phrase-unvocalized' : 'phrase-vocalized', q, mode: 'phrase', fields: ['text_ar'] }); }
  for (let i = 0; i < 5; i++) { const w = nxt(); const s = Math.floor(r() * (w.length - 3)); const last = w[s + 1].replace(MARKS, ''); Q.push({ id: id++, kind: 'prefix', q: w[s].replace(MARKS, '') + ' ' + last.slice(0, 2 + (i % 3)), mode: 'prefix', fields: ['text_ar'] }); }
  const cnt = new Map<string, { n: number; raw: string }>();
  for (const d of docs) if (d.isnad_ar) for (const m of d.isnad_ar.matchAll(/عَنْ\s+([^\s،,]+\s+[^\s،,]+)/g)) { const k = norm(m[1], true); const x = cnt.get(k); if (x) x.n++; else cnt.set(k, { n: 1, raw: m[1] }); }
  const names = [...cnt.entries()].filter(([k, v]) => v.n >= 40 && !/رسول|نبي|له/.test(k)).sort((a, b) => b[1].n - a[1].n).slice(0, 40);
  for (let i = 0; i < 5; i++) { const [, v] = names.splice(Math.floor(r() * names.length), 1)[0]; Q.push({ id: id++, kind: 'narrator-name', q: v.raw.replace(MARKS, ''), mode: 'phrase', fields: ['text_ar'] }); }
  const books = [...new Set(docs.map(d => d.book))]; for (let i = 0; i < 3; i++) Q.push({ id: id++, kind: 'book-name', q: books[Math.floor(r() * books.length)], mode: 'phrase', fields: ['book'] });
  const chs = [...new Set(docs.map(d => d.chapter))].filter(c => c.split(' ').length >= 2); for (let i = 0; i < 2; i++) Q.push({ id: id++, kind: 'chapter-title', q: chs[Math.floor(r() * chs.length)], mode: 'phrase', fields: ['chapter'] });
  for (let i = 0; i < 5; i++) { const w = nxt(); const s = Math.floor(r() * (w.length - 3)); Q.push({ id: id++, kind: 'keywords-any-order', q: [w[s + 2], w[s]].join(' ').replace(MARKS, ''), mode: 'terms', fields: ['text_ar'] }); }
  return Q;
}
export async function packRun(e: Engine, index: string, dir: string) {
  const Q = pickQueries(loadCorpus()); const res: any[] = [];
  for (const q of Q) { const hl = q.fields[0] === 'text_ar'; const s = await e.search(index, { q: q.q, fields: q.fields, mode: q.mode, cfg: 'strict', size: 10, hl }); res.push({ ...q, hits: s.hits }); }
  out(dir, `pack-${e.name}.local.json`, res);
}
const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const escHl = (s: string) => esc(s.replace(/<em>/g, '\u0001').replace(/<\/em>/g, '\u0002')).replace(/\u0001/g, '<em>').replace(/\u0002/g, '</em>');
export function packBuild(workDir: string, outDir: string, engines = ['opensearch', 'meilisearch', 'postgres']) {
  const docs = loadCorpus(); const byId = new Map(docs.map(d => [d.id, d]));
  const R = Object.fromEntries(engines.map(en => [en, JSON.parse(fs.readFileSync(`${workDir}/pack-${en}.local.json`, 'utf8')) as any[]]));
  const r = mulberry32(8675309); const key: string[] = ['query_id,A,B,C']; const csv: string[] = ['query,engine_letter,result_rank,document_id,rating_0_to_3,notes,reviewer'];
  let html = `<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><title>Noor search blind review</title><style>body{font-family:system-ui,"Geeza Pro","Traproductive",serif;margin:20px;background:#fafafa}h2{margin-top:36px;border-top:3px solid #333;padding-top:10px}.cols{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.col{background:#fff;border:1px solid #ccc;padding:8px;min-width:0}.card{border-bottom:1px solid #eee;padding:6px 0;font-size:17px;line-height:1.9}.meta{font-size:12px;color:#555;direction:ltr;text-align:left}em{background:#ffe066;font-style:normal}.t{max-height:11em;overflow:auto}@media(max-width:900px){.cols{grid-template-columns:1fr}}</style><body><h1>مراجعة نتائج البحث (عمياء)</h1><p>Rate each result 0-3 in the CSV: 0 irrelevant, 1 weak, 2 good, 3 excellent. Engines are anonymous (A/B/C, order differs per query).</p>`;
  const nq = R[engines[0]].length;
  for (let i = 0; i < nq; i++) {
    const perm = [...engines]; for (let k = perm.length - 1; k > 0; k--) { const j = Math.floor(r() * (k + 1)); [perm[k], perm[j]] = [perm[j], perm[k]]; }
    const q = R[engines[0]][i]; key.push(`${q.id},${perm.join(',')}`);
    html += `<h2>Q${q.id} <span style="direction:rtl">«${esc(q.q)}»</span> <small>(${q.kind})</small></h2><div class="cols">`;
    perm.forEach((en, li) => { const L = 'ABC'[li]; html += `<div class="col"><h3>${L}</h3>`; const hits = R[en][i].hits as any[];
      if (!hits.length) html += '<p>(no results)</p>';
      hits.forEach((h, k) => { const d = byId.get(h.id)!; csv.push(`"${q.q.replace(/"/g, '""')}",${L},${k + 1},"${h.id}",,,`);
        html += `<div class="card"><div class="meta">#${k + 1} · ${esc(h.id)} · ${esc(d.book)} · ${esc(d.chapter)} · no. ${esc(d.hadith_number)}</div><div class="t">${h.hl ? escHl(h.hl) : esc(d.text_ar)}</div></div>`; });
      html += '</div>'; });
    html += '</div>';
  }
  fs.mkdirSync(outDir, { recursive: true });
  fs.writeFileSync(`${outDir}/blind-review.local.html`, html + '</body></html>');
  fs.writeFileSync(`${outDir}/rating-form.local.csv`, csv.join('\n') + '\n');
  fs.writeFileSync(`${outDir}/ANSWER-KEY-do-not-share-with-reviewer.csv`, key.join('\n') + '\n');
}
