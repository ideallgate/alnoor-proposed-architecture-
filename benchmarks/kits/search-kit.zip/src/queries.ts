import { loadCorpus, type Doc } from './data.js';
import { mulberry32 } from './util.js';
import { normChars } from './norm.js';
import type { Req } from './engine.js';
const MARKS = /[ً-ْٰ]/g;
const SALUT = /وسلم|صلى|صلي|الله/;
const aw = (s: string) => s.replace(MARKS, '').split(/\s+/).map(w => w.replace(/[^\p{L}]/gu, '')).filter(w => w.length > 1 && !SALUT.test(w));
/** T3 query pool: 70% phrase/keyword, 20% prefix suggestion, 10% filtered. Unvocalized, from real matn text. */
export function t3Pool(docs: Doc[], n = 6000, seed = 99): Req[] {
  const r = mulberry32(seed); const pool: Req[] = [];
  const books = [...new Set(docs.map(d => d.book))]; const classes = ['sahih', 'hasan', 'daif'];
  while (pool.length < n) {
    const d = docs[Math.floor(r() * docs.length)]; if (!d.matn_ar) continue;
    const w = aw(d.matn_ar); if (w.length < 5) continue; const x = r();
    const base = { fields: ['matn_ar'] as any, cfg: 'merged' as const, size: 10 };
    const s = Math.floor(r() * (w.length - 4));
    if (x < 0.35) pool.push({ ...base, mode: 'phrase', q: w.slice(s, s + 3 + Math.floor(r() * 2)).join(' ') });
    else if (x < 0.70) pool.push({ ...base, mode: 'terms', q: [w[s], w[s + 1 + Math.floor(r() * 3)]].join(' ') });
    else if (x < 0.90) { const last = w[s + 1]; pool.push({ ...base, mode: 'prefix', q: w[s] + ' ' + last.slice(0, Math.min(last.length - 1, 2 + Math.floor(r() * 3))) }); }
    else { const f = r() < 0.5 ? { book: d.book } : { grade_class: classes[Math.floor(r() * 3)] }; pool.push({ ...base, mode: 'terms', q: [w[s], w[s + 2]].join(' '), ...f }); }
  }
  return pool;
}
