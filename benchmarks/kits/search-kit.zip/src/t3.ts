import { loadCorpus } from './data.js';
import { t3Pool } from './queries.js';
import { mulberry32, out, pct, median, now } from './util.js';
import type { Engine } from './engine.js';

export async function runT3(e: Engine, index: string, label: string, outDir: string, opts: { runs: number; reqs: number; conc: number[]; capSec: number; warm: number }) {
  const pool = t3Pool(loadCorpus());
  const cells: any[] = [];
  for (const conc of opts.conc) {
    const runs: any[] = [];
    for (let run = 0; run < opts.runs; run++) {
      const r = mulberry32(1000 * conc + run);
      const order = Array.from({ length: opts.warm + opts.reqs }, () => pool[Math.floor(r() * pool.length)]);
      // warm-up (discarded)
      let wi = 0; const wt0 = now(); await Promise.all(Array.from({ length: Math.min(conc, 10) }, async () => { while (wi < opts.warm && now() - wt0 < 20000) { const q = order[wi++]; try { await e.search(index, q); } catch { /* warm-up errors ignored but real errors are counted below */ } } }));
      const lat: number[] = []; const errs: Record<string, number> = {}; let i = opts.warm, done = 0, nerr = 0; const t0 = now(); let capped = false;
      await Promise.all(Array.from({ length: conc }, async () => {
        while (i < order.length) {
          if ((now() - t0) / 1000 > opts.capSec) { capped = true; return; }
          const q = order[i++]; const s = now();
          try { await e.search(index, q); lat.push(now() - s); } catch (err: any) { nerr++; const m = String(err?.message ?? err).slice(0, 120); errs[m] = (errs[m] ?? 0) + 1; }
          done++;
        }
      }));
      const wall = (now() - t0) / 1000; lat.sort((a, b) => a - b);
      runs.push({ run, requests: done, errors: nerr, errorKinds: errs, capped, wallSec: wall, qps: done / wall, p50: pct(lat, .5), p95: pct(lat, .95), p99: pct(lat, .99), mean: lat.reduce((a, b) => a + b, 0) / (lat.length || 1) });
    }
    cells.push({ engine: e.name, corpus: label, concurrency: conc, runs, median: { p50: median(runs.map(x => x.p50)), p95: median(runs.map(x => x.p95)), p99: median(runs.map(x => x.p99)), qps: median(runs.map(x => x.qps)) }, totalErrors: runs.reduce((a, x) => a + x.errors, 0) });
    console.log(`[t3] ${e.name} ${label} c=${conc} p50=${cells.at(-1).median.p50.toFixed(1)} p95=${cells.at(-1).median.p95.toFixed(1)} p99=${cells.at(-1).median.p99.toFixed(1)} err=${cells.at(-1).totalErrors}`);
  }
  out(outDir, `t3-${e.name}-${label}.json`, { opts, cells });
}
