import { loadCorpus, scaled, type Doc } from './data.js';
import { mulberry32, out, median, now, sleep } from './util.js';
import type { Engine } from './engine.js';

const LET = 'بتثجحخدذرزسشصضطظعغفقكلمن';
export const token = (pass: string, kind: string, n: number) => 'ظظ' + [...(pass + kind + n)].map(c => LET[c.charCodeAt(0) % LET.length]).join('') + [...n.toString(24).padStart(4, '0')].map(c => LET[parseInt(c, 24)]).join('');

export async function indexRuns(e: Engine, index: string, docs: Iterable<Doc> | (() => Iterable<Doc>), runs: number, outDir: string, tag: string) {
  const res: any[] = [];
  for (let r = 0; r < runs; r++) {
    const t0 = now(); await e.setup(index); const t1 = now();
    await e.load(index, typeof docs === 'function' ? docs() : docs); const t2 = now();
    const st = await e.stats(index);
    res.push({ run: r, setupSec: (t1 - t0) / 1000, loadSec: (t2 - t1) / 1000, totalSec: (t2 - t0) / 1000, docs: st.docs, bytes: st.bytes });
    console.log(`[t4] ${e.name} ${tag} index run ${r}: ${((t2 - t0) / 1000).toFixed(1)}s ${st.docs} docs ${(st.bytes / 1e6).toFixed(0)}MB`);
  }
  const o: any = { engine: e.name, corpus: tag, runs: res, medianTotalSec: median(res.map(x => x.totalSec)), bytes: res.at(-1).bytes };
  if (e.compact && tag === 'real') { const t = now(); o.afterCompact = { ...(await e.compact(index)), sec: (now() - t) / 1000 }; }
  out(outDir, `t4-index-${e.name}-${tag}.json`, o);
  return o;
}

async function visible(e: Engine, index: string, tok: string, want: number, timeoutMs = 120000) {
  const s = now();
  while (now() - s < timeoutMs) { if ((await e.count(index, { q: tok, fields: ['matn_ar'], mode: 'terms', cfg: 'merged' })) >= want) return now() - s; await sleep(5); }
  return NaN;
}
export async function updateRuns(e: Engine, index: string, runs: number, pass: string, outDir: string) {
  const docs = loadCorpus().filter(d => d.matn_ar); const res: any[] = [];
  for (let run = 0; run < runs; run++) {
    const r = mulberry32(5150 + run); const pick = () => docs[Math.floor(r() * docs.length)];
    const single: { ackMs: number; visibleMs: number }[] = [];
    for (let i = 0; i < 100; i++) {
      const d = pick(); const tok = token(pass, 'u' + run, i);
      const s = now(); await e.update(index, d.id, { text_ar: d.text_ar + ' ' + tok, matn_ar: d.matn_ar + ' ' + tok }); const ack = now() - s;
      const vis = await visible(e, index, tok, 1); single.push({ ackMs: ack, visibleMs: ack + vis });
    }
    const ids = new Set<string>(); while (ids.size < 1000) ids.add(pick().id);
    const btok = token(pass, 'b' + run, 0); const byId = new Map(docs.map(d => [d.id, d]));
    const ups = [...ids].map(id => { const d = byId.get(id)!; return { id, patch: { text_ar: d.text_ar + ' ' + btok, matn_ar: d.matn_ar + ' ' + btok } }; });
    const s = now(); await e.bulkUpdate(index, ups); const ack = now() - s; const vis = await visible(e, index, btok, 1000, 600000);
    const sv = single.map(x => x.visibleMs).sort((a, b) => a - b); const sa = single.map(x => x.ackMs).sort((a, b) => a - b);
    res.push({ run, singleVisible: { p50: sv[49], p95: sv[94], max: sv[99], nanCount: sv.filter(Number.isNaN).length }, singleAck: { p50: sa[49], p95: sa[94] }, bulk1000: { ackMs: ack, visibleMs: ack + vis } });
    console.log(`[t4] ${e.name} update run ${run}: single p50=${sv[49].toFixed(0)} p95=${sv[94].toFixed(0)} bulk=${(ack + vis).toFixed(0)}ms`);
  }
  out(outDir, `t4-updates-${e.name}.json`, { engine: e.name, runs: res, median: { p50: median(res.map(x => x.singleVisible.p50)), p95: median(res.map(x => x.singleVisible.p95)), bulk1000Ms: median(res.map(x => x.bulk1000.visibleMs)) } });
}
export { scaled };
