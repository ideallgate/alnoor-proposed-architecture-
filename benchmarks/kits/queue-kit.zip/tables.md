## Pass 1

### S1, concurrency 10 (median of runs; error columns are totals over all runs)

| stack | runs | enqueue/s | total ms | drain after enq ms | jobs/s | pickup p50 ms | p95 | p99 | lost | dups | failed | enq failed | harness err | PG CPU% avg | Redis CPU% avg |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| bullmq-dedicated | 5 | 15,949 | 7,037 | 3,875 | 7,105 | 3,008 | 3,801 | 3,891 | 0 | 0 | 0 | 0 | 0 | 1.7 | 31.2 |
| bullmq-shared | 5 | 19,335 | 5,634 | 3,003 | 8,875 | 2,392 | 3,003 | 3,060 | 0 | 0 | 0 | 0 | 0 | 0.2 | 33.4 |
| pg-boss | 5 | 48,591 | 39,808 | 38,762 | 1,256 | 25,380 | 37,934 | 38,632 | 0 | 0 | 0 | 0 | 0 | 77.1 | - |
| graphile-worker | 5 | 23,969 | 19,883 | 17,805 | 2,515 | 8,663 | 17,194 | 17,704 | 0 | 0 | 0 | 0 | 0 | 84.8 | - |

### S1, concurrency 50 (median of runs; error columns are totals over all runs)

| stack | runs | enqueue/s | total ms | drain after enq ms | jobs/s | pickup p50 ms | p95 | p99 | lost | dups | failed | enq failed | harness err | PG CPU% avg | Redis CPU% avg |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| bullmq-dedicated | 5 | 13,099 | 6,631 | 3,097 | 7,540 | 2,713 | 3,184 | 3,207 | 0 | 0 | 0 | 0 | 0 | 0.7 | 34.2 |
| bullmq-shared | 5 | 17,170 | 5,298 | 2,375 | 9,438 | 2,107 | 2,387 | 2,413 | 0 | 0 | 0 | 0 | 0 | 1.8 | 28.2 |
| pg-boss | 5 | 48,638 | 11,680 | 10,651 | 4,281 | 8,202 | 10,417 | 10,606 | 0 | 0 | 0 | 0 | 0 | 65.8 | - |
| graphile-worker | 5 | 10,948 | 29,706 | 25,294 | 1,683 | 10,809 | 23,620 | 25,101 | 0 | 0 | 0 | 0 | 0 | 90.8 | - |

### S2, concurrency 10 (median of runs; error columns are totals over all runs)

| stack | runs | completion ms | lateness p50 ms | p95 | p99 | lost | dups | failed | enq failed | incomplete runs | harness err | PG CPU% avg | PG mem MiB max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| bullmq-dedicated | 5 | 104,913 | 94,058 | 94,516 | 94,567 | 0 | 0 | 0 | 0 | 0 | 0 | 3.1 | 133 |
| bullmq-shared | 5 | 104,651 | 93,886 | 94,211 | 94,260 | 0 | 0 | 0 | 0 | 0 | 0 | 1.7 | 135 |
| pg-boss | 5 | 110,375 | 2,157 | 3,474 | 3,583 | 0 | 0 | 0 | 0 | 0 | 0 | 7.1 | 153 |
| graphile-worker | 5 | 106,154 | 94,462 | 95,851 | 95,950 | 0 | 0 | 0 | 0 | 0 | 0 | 8.1 | 166 |

### S2, concurrency 50 (median of runs; error columns are totals over all runs)

| stack | runs | completion ms | lateness p50 ms | p95 | p99 | lost | dups | failed | enq failed | incomplete runs | harness err | PG CPU% avg | PG mem MiB max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| bullmq-dedicated | 5 | 22,241 | 11,295 | 11,761 | 11,788 | 0 | 0 | 0 | 0 | 0 | 0 | 0.3 | 130 |
| bullmq-shared | 5 | 22,422 | 11,606 | 11,886 | 11,908 | 0 | 0 | 0 | 0 | 0 | 0 | 0.1 | 130 |
| pg-boss | 5 | 24,482 | 735 | 1,083 | 1,110 | 0 | 0 | 0 | 0 | 0 | 0 | 8.5 | 150 |
| graphile-worker | 5 | 25,598 | 13,424 | 15,155 | 15,342 | 0 | 0 | 0 | 0 | 0 | 0 | 30.9 | 256 |

### S3 API under queue load (ApacheBench c=100, 60 s; median of runs)

| cell | runs | req/s | p50 ms | p95 ms | p99 ms | cache hit % | non-2xx | conn/recv/exc failures | queue load covered window | PG CPU% avg | runner CPU% avg |
|---|---|---|---|---|---|---|---|---|---|---|---|
| baseline-cache | 5 | 19,023 | 5 | 8 | 12 | 98.2 | 0 | 0 | - | 8.6 | 128.2 |
| baseline-shared | 5 | 18,819 | 5 | 8 | 12 | 98.2 | 0 | 0 | - | 8.6 | 129.5 |
| bullmq-dedicated | 5 | 18,845 | 5 | 8 | 12 | 98.2 | 0 | 0 | 5/5 | 8.2 | 131.8 |
| bullmq-shared | 5 | 19,258 | 5 | 8 | 12 | 98.3 | 0 | 0 | 5/5 | 8.6 | 131.1 |
| pg-boss | 5 | 18,691 | 5 | 8 | 12 | 98.2 | 0 | 0 | 5/5 | 12.9 | 130.2 |
| graphile-worker | 5 | 18,946 | 5 | 8 | 12 | 98.2 | 0 | 0 | 5/5 | 10.8 | 129.5 |

### S4a/S4b Redis shared, maxmemory 256 MB, 20,000 waiting BullMQ jobs + 50,000 x 8 KB cache writes

| policy | runs | cache writes ok | cache writes failed (OOM) | evicted keys | wait list length after | job hashes left | listed with hash | listed, hash missing | extra enqueues failed (of 1000) | jobs executed (of 20,000) | jobs lost | worker finished |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| allkeys-lru | 5 | 50,000 | 0 | 43,610 | 0 | 676 | 0 | 0 | 0 | 0 | 20,000 | 0/5 |
| noeviction | 5 | 22,590 | 27,410 | 0 | 20,000 | 20,000 | 20,000 | 0 | 1,000 | 0 | 20,000 | 2/5 |

### S4c Hard kill (SIGKILL) and restart with 20,000 waiting jobs

| stack | store / persistence | runs | jobs found after restart (median) | lost (median) | lost (min-max over runs) | recovery ms | dups |
|---|---|---|---|---|---|---|---|
| bullmq-dedicated | redis-queue / AOF everysec | 5 | 20,000 | 0 | 0-0 | 1,353 | 0 |
| bullmq-shared | redis-shared / none | 5 | 0 | 20,000 | 20000-20000 | 317 | 0 |
| pg-boss | postgres / WAL, synchronous_commit=on (default) | 5 | 20,000 | 0 | 0-0 | 315 | 0 |
| graphile-worker | postgres / WAL, synchronous_commit=on (default) | 5 | 20,000 | 0 | 0-0 | 317 | 0 |

### S5 Transactional enqueue (totals over all runs)

| stack | runs | injected crashes | content committed | committed WITHOUT reindex job | reindex job WITHOUT content | real SIGKILLs | committed w/o job after SIGKILL | control: committed w/o job (no crash) | publish ms/op (no crash) |
|---|---|---|---|---|---|---|---|---|---|
| bullmq-dedicated | 5 | 5000 | 5000 | 5000 | 0 | 100 | 100 | 0 | 0.58 |
| bullmq-shared | 5 | 5000 | 5000 | 5000 | 0 | 100 | 100 | 0 | 0.57 |
| pg-boss | 5 | 5000 | 0 | 0 | 0 | 100 | 0 | 0 | 0.84 |
| graphile-worker | 5 | 5000 | 0 | 0 | 0 | 100 | 0 | 0 | 0.68 |

## Pass 2

### S1, concurrency 10 (median of runs; error columns are totals over all runs)

| stack | runs | enqueue/s | total ms | drain after enq ms | jobs/s | pickup p50 ms | p95 | p99 | lost | dups | failed | enq failed | harness err | PG CPU% avg | Redis CPU% avg |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| bullmq-dedicated | 5 | 16,801 | 6,571 | 3,598 | 7,609 | 2,800 | 3,582 | 3,621 | 0 | 0 | 0 | 0 | 0 | 3.8 | 30.7 |
| bullmq-shared | 5 | 19,380 | 5,514 | 2,945 | 9,068 | 2,380 | 2,920 | 2,985 | 0 | 0 | 0 | 0 | 0 | 3.4 | 32.2 |
| pg-boss | 5 | 49,900 | 38,245 | 37,236 | 1,307 | 25,472 | 36,614 | 37,105 | 0 | 0 | 0 | 0 | 0 | 80.2 | - |
| graphile-worker | 5 | 25,654 | 18,260 | 16,376 | 2,738 | 7,269 | 15,399 | 16,197 | 0 | 0 | 0 | 0 | 0 | 87.3 | - |

### S1, concurrency 50 (median of runs; error columns are totals over all runs)

| stack | runs | enqueue/s | total ms | drain after enq ms | jobs/s | pickup p50 ms | p95 | p99 | lost | dups | failed | enq failed | harness err | PG CPU% avg | Redis CPU% avg |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| bullmq-dedicated | 5 | 14,176 | 6,320 | 2,780 | 7,911 | 2,470 | 2,799 | 2,824 | 0 | 0 | 0 | 0 | 0 | 0 | 30.9 |
| bullmq-shared | 5 | 17,680 | 5,212 | 2,320 | 9,593 | 2,043 | 2,341 | 2,379 | 0 | 0 | 0 | 0 | 0 | 3.5 | 27.8 |
| pg-boss | 5 | 51,493 | 10,842 | 9,852 | 4,612 | 7,162 | 9,709 | 9,833 | 0 | 0 | 0 | 0 | 0 | 52 | - |
| graphile-worker | 5 | 11,666 | 29,564 | 25,388 | 1,691 | 10,196 | 23,493 | 25,013 | 0 | 0 | 0 | 0 | 0 | 93.9 | - |

### S2, concurrency 10 (median of runs; error columns are totals over all runs)

| stack | runs | completion ms | lateness p50 ms | p95 | p99 | lost | dups | failed | enq failed | incomplete runs | harness err | PG CPU% avg | PG mem MiB max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| bullmq-dedicated | 5 | 105,536 | 94,447 | 94,860 | 94,932 | 0 | 0 | 0 | 0 | 0 | 0 | 2 | 95 |
| bullmq-shared | 5 | 104,989 | 93,685 | 94,006 | 94,024 | 0 | 0 | 0 | 0 | 0 | 0 | 2.9 | 95 |
| pg-boss | 5 | 110,996 | 2,457 | 3,831 | 3,928 | 0 | 0 | 0 | 0 | 0 | 0 | 8 | 117 |
| graphile-worker | 5 | 106,271 | 94,557 | 95,767 | 95,873 | 0 | 0 | 0 | 0 | 0 | 0 | 9.5 | 126 |

### S2, concurrency 50 (median of runs; error columns are totals over all runs)

| stack | runs | completion ms | lateness p50 ms | p95 | p99 | lost | dups | failed | enq failed | incomplete runs | harness err | PG CPU% avg | PG mem MiB max |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| bullmq-dedicated | 5 | 22,404 | 11,741 | 12,129 | 12,146 | 0 | 0 | 0 | 0 | 0 | 0 | 0.3 | 93 |
| bullmq-shared | 5 | 22,512 | 11,675 | 11,982 | 11,999 | 0 | 0 | 0 | 0 | 0 | 0 | 2.8 | 93 |
| pg-boss | 5 | 24,593 | 778 | 1,169 | 1,198 | 0 | 0 | 0 | 0 | 0 | 0 | 9.5 | 115 |
| graphile-worker | 5 | 25,968 | 13,461 | 15,348 | 15,539 | 0 | 0 | 0 | 0 | 0 | 0 | 34.6 | 218 |

### S3 API under queue load (ApacheBench c=100, 60 s; median of runs)

| cell | runs | req/s | p50 ms | p95 ms | p99 ms | cache hit % | non-2xx | conn/recv/exc failures | queue load covered window | PG CPU% avg | runner CPU% avg |
|---|---|---|---|---|---|---|---|---|---|---|---|
| baseline-cache | 5 | 18,191 | 5 | 9 | 13 | 98.2 | 0 | 0 | - | 8.2 | 129.5 |
| baseline-shared | 5 | 18,214 | 5 | 9 | 13 | 98.2 | 0 | 0 | - | 9.6 | 127.5 |
| bullmq-dedicated | 5 | 18,298 | 5 | 9 | 13 | 98.2 | 0 | 0 | 5/5 | 9.8 | 130.2 |
| bullmq-shared | 5 | 18,345 | 5 | 9 | 13 | 98.2 | 0 | 0 | 5/5 | 8.1 | 128.9 |
| pg-boss | 5 | 17,038 | 5 | 10 | 15 | 98 | 0 | 0 | 5/5 | 17.8 | 130.7 |
| graphile-worker | 5 | 17,905 | 5 | 9 | 14 | 98.1 | 0 | 0 | 5/5 | 12.1 | 129.3 |

### S4a/S4b Redis shared, maxmemory 256 MB, 20,000 waiting BullMQ jobs + 50,000 x 8 KB cache writes

| policy | runs | cache writes ok | cache writes failed (OOM) | evicted keys | wait list length after | job hashes left | listed with hash | listed, hash missing | extra enqueues failed (of 1000) | jobs executed (of 20,000) | jobs lost | worker finished |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| allkeys-lru | 5 | 50,000 | 0 | 43,907 | 0 | 339 | 0 | 0 | 0 | 0 | 20,000 | 0/5 |
| noeviction | 5 | 22,530 | 27,470 | 0 | 20,000 | 20,000 | 20,000 | 0 | 1,000 | 0 | 20,000 | 1/5 |

### S4c Hard kill (SIGKILL) and restart with 20,000 waiting jobs

| stack | store / persistence | runs | jobs found after restart (median) | lost (median) | lost (min-max over runs) | recovery ms | dups |
|---|---|---|---|---|---|---|---|
| bullmq-dedicated | redis-queue / AOF everysec | 5 | 20,000 | 0 | 0-0 | 1,315 | 0 |
| bullmq-shared | redis-shared / none | 5 | 0 | 20,000 | 20000-20000 | 318 | 0 |
| pg-boss | postgres / WAL, synchronous_commit=on (default) | 5 | 20,000 | 0 | 0-0 | 313 | 0 |
| graphile-worker | postgres / WAL, synchronous_commit=on (default) | 5 | 20,000 | 0 | 0-0 | 326 | 0 |

### S5 Transactional enqueue (totals over all runs)

| stack | runs | injected crashes | content committed | committed WITHOUT reindex job | reindex job WITHOUT content | real SIGKILLs | committed w/o job after SIGKILL | control: committed w/o job (no crash) | publish ms/op (no crash) |
|---|---|---|---|---|---|---|---|---|---|
| bullmq-dedicated | 5 | 5000 | 5000 | 5000 | 0 | 100 | 100 | 0 | 0.58 |
| bullmq-shared | 5 | 5000 | 5000 | 5000 | 0 | 100 | 100 | 0 | 0.51 |
| pg-boss | 5 | 5000 | 0 | 0 | 0 | 100 | 0 | 0 | 0.79 |
| graphile-worker | 5 | 5000 | 0 | 0 | 0 | 100 | 0 | 0 | 0.71 |

