#!/usr/bin/env bash
# Usage: scripts/run.sh smoke | pass1 | pass2 | all     (Docker is the only requirement; everything runs in containers)
set -euo pipefail
cd "$(dirname "$0")/.."
docker compose up -d --build
case "${1:-all}" in
  smoke) docker compose exec -T runner node dist/bench.js --pass 1 --smoke ;;
  pass1) docker compose exec -T runner node dist/bench.js --pass 1 ;;
  pass2) docker compose exec -T runner node dist/bench.js --pass 2 ;;
  all)   docker compose exec -T runner node dist/bench.js --pass 1 | tee results-pass1/run.log
         docker compose exec -T runner node dist/bench.js --pass 2 | tee results-pass2/run.log ;;
esac
