// Builds markdown tables from results-pass*/raw.jsonl. Run in Docker: docker run --rm -v "$PWD":/w -w /w node:24-bookworm-slim node scripts/report.js
const fs = require('fs');
const STACKS = ['bullmq-dedicated', 'bullmq-shared', 'pg-boss', 'graphile-worker'];
const load = (p) => (fs.existsSync(`results-pass${p}/raw.jsonl`) ? fs.readFileSync(`results-pass${p}/raw.jsonl`, 'utf8').split('\n').filter(Boolean).map(JSON.parse) : []);
const med = (a) => { a = a.filter((x) => typeof x === 'number' && !isNaN(x)).sort((x, y) => x - y); return a.length ? a[Math.floor((a.length - 1) / 2) + (a.length % 2 === 0 ? 0 : 0)] : null; };
const sum = (a) => a.reduce((x, y) => x + (y || 0), 0);
const f = (v, d = 0) => (v == null ? 'n/a' : Number(v).toLocaleString('en-US', { maximumFractionDigits: d }));
const sel = (rows, sc, cell, conc) => rows.filter((r) => r.scenario === sc && r.cell === cell && (conc == null || r.conc === conc));
const ok = (rs) => rs.filter((r) => !r.harness_error);
const errs = (rs) => rs.filter((r) => r.harness_error).length;
const get = (r, path) => path.split('.').reduce((o, k) => (o == null ? o : o[k]), r);
const M = (rs, path) => med(ok(rs).map((r) => get(r, path)));
const S = (rs, path) => sum(ok(rs).map((r) => get(r, path)));
const P = { 1: load(1), 2: load(2) };
let out = '';
const w = (s = '') => (out += s + '\n');
function table(head, rows) { w('| ' + head.join(' | ') + ' |'); w('|' + head.map(() => '---').join('|') + '|'); rows.forEach((r) => w('| ' + r.join(' | ') + ' |')); w(); }
for (const pass of [1, 2]) {
  const R = P[pass]; if (!R.length) continue;
  w(`## Pass ${pass}\n`);
  for (const sc of ['S1', 'S2']) for (const conc of [10, 50]) {
    w(`### ${sc}, concurrency ${conc} (median of runs; error columns are totals over all runs)\n`);
    if (sc === 'S1') table(['stack', 'runs', 'enqueue/s', 'total ms', 'drain after enq ms', 'jobs/s', 'pickup p50 ms', 'p95', 'p99', 'lost', 'dups', 'failed', 'enq failed', 'harness err', 'PG CPU% avg', 'Redis CPU% avg'],
      STACKS.map((s) => { const rs = sel(R, sc, s, conc); return [s, ok(rs).length, f(M(rs, 'enq_rate')), f(M(rs, 'total_ms')), f(M(rs, 'drain_after_enq_ms')), f(M(rs, 'throughput')), f(M(rs, 'lat_p50')), f(M(rs, 'lat_p95')), f(M(rs, 'lat_p99')), S(rs, 'lost'), S(rs, 'dups'), S(rs, 'failed'), S(rs, 'enq_failed'), errs(rs), f(M(rs, 'resources.cpu_pct_avg.noor-postgres'), 1), s === 'bullmq-shared' ? f(M(rs, 'resources.cpu_pct_avg.noor-redis-shared'), 1) : s.startsWith('bullmq') ? f(M(rs, 'resources.cpu_pct_avg.noor-redis-queue'), 1) : '-']; }));
    else table(['stack', 'runs', 'completion ms', 'lateness p50 ms', 'p95', 'p99', 'lost', 'dups', 'failed', 'enq failed', 'incomplete runs', 'harness err', 'PG CPU% avg', 'PG mem MiB max'],
      STACKS.map((s) => { const rs = sel(R, sc, s, conc); return [s, ok(rs).length, f(M(rs, 'completion_ms')), f(M(rs, 'late_p50')), f(M(rs, 'late_p95')), f(M(rs, 'late_p99')), S(rs, 'lost'), S(rs, 'dups'), S(rs, 'failed'), S(rs, 'enq_failed'), ok(rs).filter((r) => !r.complete).length, errs(rs), f(M(rs, 'resources.cpu_pct_avg.noor-postgres'), 1), f(M(rs, 'resources.mem_mib_max.noor-postgres'))]; }));
  }
  w('### S3 API under queue load (ApacheBench c=100, 60 s; median of runs)\n');
  table(['cell', 'runs', 'req/s', 'p50 ms', 'p95 ms', 'p99 ms', 'cache hit %', 'non-2xx', 'conn/recv/exc failures', 'queue load covered window', 'PG CPU% avg', 'runner CPU% avg'],
    ['baseline-cache', 'baseline-shared', ...STACKS].map((c) => { const rs = sel(R, 'S3', c); const o = ok(rs); return [c, o.length, f(M(rs, 'rps')), f(M(rs, 'p50')), f(M(rs, 'p95')), f(M(rs, 'p99')), f(med(o.map((r) => 100 * r.cache_hits / (r.cache_hits + r.cache_misses))), 1), S(rs, 'non2xx'), S(rs, 'connect_fail') + S(rs, 'receive_fail') + S(rs, 'exceptions'), c.startsWith('baseline') ? '-' : `${o.filter((r) => r.queue_load && r.queue_load.load_window_covered).length}/${o.length}`, f(M(rs, 'resources.cpu_pct_avg.noor-postgres'), 1), f(M(rs, 'resources.cpu_pct_avg.noor-runner'), 1)]; }));
  w('### S4a/S4b Redis shared, maxmemory 256 MB, 20,000 waiting BullMQ jobs + 50,000 x 8 KB cache writes\n');
  table(['policy', 'runs', 'cache writes ok', 'cache writes failed (OOM)', 'evicted keys', 'wait list length after', 'job hashes left', 'listed with hash', 'listed, hash missing', 'extra enqueues failed (of 1000)', 'jobs executed (of 20,000)', 'jobs lost', 'worker finished'],
    [['S4a', 'allkeys-lru'], ['S4b', 'noeviction']].map(([sc, c]) => { const rs = sel(R, sc, c); return [c, ok(rs).length, f(M(rs, 'cache_writes_ok')), f(M(rs, 'cache_writes_failed')), f(M(rs, 'evicted_keys')), f(M(rs, 'wait_list_len')), f(M(rs, 'job_hashes_present')), f(M(rs, 'listed_with_hash')), f(M(rs, 'listed_missing_hash')), f(M(rs, 'extra_enqueue_failed')), f(M(rs, 'executed')), f(M(rs, 'lost')), `${ok(rs).filter((r) => r.worker_complete).length}/${ok(rs).length}`]; }));
  w('### S4c Hard kill (SIGKILL) and restart with 20,000 waiting jobs\n');
  table(['stack', 'store / persistence', 'runs', 'jobs found after restart (median)', 'lost (median)', 'lost (min-max over runs)', 'recovery ms', 'dups'],
    STACKS.map((s) => { const rs = ok(sel(R, 'S4c', s)); const l = rs.map((r) => r.lost); return [s, rs[0] ? `${rs[0].store} / ${rs[0].persistence}` : 'n/a', rs.length, f(M(rs, 'survivors_after_restart')), f(M(rs, 'lost')), l.length ? `${Math.min(...l)}-${Math.max(...l)}` : 'n/a', f(M(rs, 'recover_ms')), S(rs, 'dups')]; }));
  w('### S5 Transactional enqueue (totals over all runs)\n');
  table(['stack', 'runs', 'injected crashes', 'content committed', 'committed WITHOUT reindex job', 'reindex job WITHOUT content', 'real SIGKILLs', 'committed w/o job after SIGKILL', 'control: committed w/o job (no crash)', 'publish ms/op (no crash)'],
    STACKS.map((s) => { const rs = ok(sel(R, 'S5', s)); return [s, rs.length, S(rs, 'inj.attempts'), S(rs, 'inj.content_committed'), S(rs, 'inj.committed_without_job'), S(rs, 'inj.job_without_commit'), S(rs, 'kills_process_died'), S(rs, 'kill.committed_without_job'), S(rs, 'ctl.committed_without_job'), f(M(rs, 'publish_ms_per_op_no_crash'), 2)]; }));
}
fs.writeFileSync('tables.md', out); console.log(out);
