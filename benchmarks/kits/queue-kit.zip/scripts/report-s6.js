// docker run --rm -v "$PWD":/w -w /w node:24-bookworm-slim node scripts/report-s6.js   -> tables-s6.md
const fs = require('fs');
const O = 'bullmq-dedicated-outbox', CELLS = [O, 'pg-boss', 'graphile-worker'];
const load = (p) => { const f = `results-s6-pass${p}/raw.jsonl`; return fs.existsSync(f) ? fs.readFileSync(f, 'utf8').split('\n').filter(Boolean).map(JSON.parse) : []; };
const med = (a) => { a = a.filter((x) => typeof x === 'number').sort((x, y) => x - y); return a.length ? a[Math.floor((a.length - 1) / 2)] : null; };
const sum = (a) => a.reduce((x, y) => x + (y || 0), 0);
const f = (v, d = 0) => (v == null ? 'n/a' : Number(v).toLocaleString('en-US', { maximumFractionDigits: d }));
const get = (r, p) => p.split('.').reduce((o, k) => (o == null ? o : o[k]), r);
let out = ''; const w = (s = '') => (out += s + '\n');
const table = (h, rows) => { w('| ' + h.join(' | ') + ' |'); w('|' + h.map(() => '---').join('|') + '|'); rows.forEach((r) => w('| ' + r.join(' | ') + ' |')); w(); };
for (const pass of [1, 2]) {
  const R = load(pass); if (!R.length) continue; w(`## S6 pass ${pass}\n`);
  const sel = (sc, c) => R.filter((r) => r.scenario === sc && r.cell === c); const ok = (rs) => rs.filter((r) => !r.harness_error);
  const M = (rs, p) => med(ok(rs).map((r) => get(r, p))); const S = (rs, p) => sum(ok(rs).map((r) => get(r, p)));
  const he = (rs) => rs.filter((r) => r.harness_error).length;
  w('### S6a crash before commit completes (totals over runs; ctl = 1,000 normal publishes per run, inj = 1,000 injected crashes per run)\n');
  table(['stack', 'runs', 'injected crashes', 'content committed (inj)', 'committed w/o job (inj)', 'job w/o content (inj)', 'control: committed', 'control: jobs', 'control: committed w/o job', 'harness err'],
    CELLS.map((c) => { const r = sel('S6a', c); return [c, ok(r).length, S(r, 'injected'), S(r, 'inj.content_committed'), S(r, 'inj.committed_without_job'), S(r, 'inj.job_without_commit'), S(r, 'ctl.content_committed'), S(r, 'ctl.reindex_jobs'), S(r, 'ctl.committed_without_job'), he(r)]; }));
  w('### S6b producer SIGKILL right after COMMIT (50 kills per run), then relay catches up (totals over runs)\n');
  table(['stack', 'runs', 'producers killed', 'content committed', 'jobs present', 'committed w/o job', 'job w/o content', 'relay catch-up ms (median)', 'harness err'],
    CELLS.map((c) => { const r = sel('S6b', c); return [c, ok(r).length, S(r, 'producers_died'), S(r, 'content_committed'), S(r, 'reindex_jobs'), S(r, 'committed_without_job'), S(r, 'job_without_commit'), c === O ? f(M(r, 'relay_catchup_ms')) : '-', he(r)]; }));
  w('### S6c relay killed between queue.add and marking sent (100 kills per run, 1,000 rows per run; totals over runs)\n');
  table(['variant', 'runs', 'relay kills', 'rows', 'distinct executed', 'total executions', 'duplicate executions', 'lost', 'rows still not done', 'harness err'],
    ['worker-running', 'worker-idle', 'worker-running-keep-completed'].map((v) => { const r = sel('S6c', `${O}/${v}`); return [v, ok(r).length, S(r, 'relay_kills'), S(r, 'rows'), S(r, 'executed_distinct'), S(r, 'executions_total'), S(r, 'duplicate_executions'), S(r, 'lost'), S(r, 'outbox_not_done'), he(r)]; }));
  w('### S6d store loss with 5,000 jobs waiting (medians; lost columns also summed over runs)\n');
  table(['stack', 'runs', 'jobs found after wipe/restart (median)', 'lost by wipe/restart (sum)', 'recovered+executed after reconciliation (median)', 'lost after reconciliation (sum)', 'duplicate executions (sum)', 'store restart ms', 'reconcile enqueue ms', 'reconcile -> all executed ms', 'harness err'],
    CELLS.map((c) => { const r = sel('S6d', c); return [c, ok(r).length, f(med(ok(r).map((x) => x.survivors_after_wipe ?? x.survivors_after_restart))), S(r, 'lost_by_wipe') + S(r, 'lost_by_restart'), f(M(r, 'recovered_and_executed')), S(r, 'lost_after_reconcile'), S(r, 'duplicate_executions'), f(M(r, 'restart_ms')), c === O ? f(M(r, 'reconcile_enqueue_ms')) : 'n/a', c === O ? f(M(r, 'reconcile_to_all_executed_ms')) : 'n/a', he(r)]; }));
  w('### S6e cost (medians of runs; 1,000 publishes per run; latency = commit/enqueue timestamp to job start, 10 workers)\n');
  table(['stack', 'runs', 'publish ms/op (no relay/worker)', 'latency p50 ms', 'p95', 'p99', 'dups', 'harness err'],
    CELLS.map((c) => { const r = sel('S6e', c); return [c, ok(r).length, f(M(r, 'publish_ms_per_op'), 2), f(M(r, 'latency_p50')), f(M(r, 'latency_p95')), f(M(r, 'latency_p99')), S(r, 'dups'), he(r)]; }));
}
fs.writeFileSync('tables-s6.md', out); console.log(out);
