import { Queue, Worker } from 'bullmq';
import { PgBoss } from 'pg-boss';
import { Logger, run as gwRun, makeWorkerUtils, Runner, WorkerUtils } from 'graphile-worker';
import { Pool } from 'pg';
import { Job, PG_URL, StackName, queueRedisHost } from './common';

export type Handler = (j: Job) => Promise<void>;
export interface Adapter {
  name: StackName;
  lib: { failed: number; stalled: number; error: number };
  reset(): Promise<void>;            // drop all queue state and (re)open producer side
  open(): Promise<void>;             // open producer side without touching state
  enqueue(jobs: Job[]): Promise<void>;
  startWorker(conc: number, h: Handler): Promise<void>;
  stopWorker(): Promise<void>;
  pending(): Promise<number>;        // waiting + delayed + active in the store
  failed(): Promise<number>;         // failed jobs recorded in the store
  reindexIds(run: string): Promise<number[]>; // content-version ids that have a reindex job stored
  enqueueInTx?(client: any, j: Job): Promise<void>; // enqueue inside the caller's open DB transaction (pg stacks only)
  close(): Promise<void>;
}

// ---------- BullMQ (same code for dedicated and shared Redis) ----------
class BullAdapter implements Adapter {
  lib = { failed: 0, stalled: 0, error: 0 };
  queue?: Queue; worker?: Worker; host: string;
  constructor(public name: StackName) { this.host = queueRedisHost(name); }
  async open() {
    if (this.queue) return;
    this.queue = new Queue('jobs', { connection: { host: this.host, port: 6379 }, defaultJobOptions: { removeOnComplete: true } });
    this.queue.on('error', () => this.lib.error++);
  }
  async reset() { await this.open(); await this.queue!.obliterate({ force: true }); }
  async enqueue(jobs: Job[]) {
    await this.queue!.addBulk(jobs.map((j) => ({ name: j.kind, data: j, opts: j.s ? { delay: Math.max(0, j.s - Date.now()) } : {} })));
  }
  async startWorker(conc: number, h: Handler) {
    this.worker = new Worker('jobs', async (job) => h(job.data as Job), { connection: { host: this.host, port: 6379, maxRetriesPerRequest: null }, concurrency: conc });
    this.worker.on('failed', () => this.lib.failed++);
    this.worker.on('stalled', () => this.lib.stalled++);
    this.worker.on('error', () => this.lib.error++);
    await this.worker.waitUntilReady();
  }
  async stopWorker() { await this.worker?.close(true).catch(() => {}); this.worker = undefined; }
  async pending() { const c = await this.queue!.getJobCounts('waiting', 'delayed', 'active', 'prioritized'); return Object.values(c).reduce((a, b) => a + b, 0); }
  async failed() { return this.queue!.getFailedCount(); }
  async reindexIds(run: string) {
    const jobs = await this.queue!.getJobs(['waiting', 'delayed', 'active', 'completed', 'failed', 'prioritized'], 0, -1);
    return jobs.filter((j) => j?.data?.run === run).map((j) => j.data.cv);
  }
  async close() { await this.stopWorker(); await this.queue?.close().catch(() => {}); this.queue = undefined; }
}

// ---------- pg-boss ----------
class PgBossAdapter implements Adapter {
  name: StackName = 'pg-boss';
  lib = { failed: 0, stalled: 0, error: 0 };
  boss?: PgBoss; pool?: Pool; maxConn = 10;
  private mk(max: number) { const b = new PgBoss({ connectionString: PG_URL, max }); b.on('error', () => this.lib.error++); return b; }
  async open() {
    if (this.boss) return;
    this.boss = this.mk(this.maxConn); await this.boss.start(); await this.boss.createQueue('jobs');
    this.pool = new Pool({ connectionString: PG_URL, max: 4 });
  }
  async reset() {
    const p = new Pool({ connectionString: PG_URL, max: 1 });
    await p.query('DROP SCHEMA IF EXISTS pgboss CASCADE'); await p.end();
    await this.open();
  }
  async enqueue(jobs: Job[]) {
    await this.boss!.insert('jobs', jobs.map((j) => ({ data: j as any, ...(j.s ? { startAfter: new Date(j.s) } : {}) })));
  }
  async enqueueInTx(client: any, j: Job) { await this.boss!.send('jobs', j as any, { db: { executeSql: (t: string, v?: unknown[]) => client.query(t, v) } } as any); }
  async startWorker(conc: number, h: Handler) {
    // pg-boss defaults (localConcurrency=N, batchSize=1) measured at ~N jobs per 2 s polling interval, so concurrency N is
    // expressed as batchSize=N (+ burstWhenBatchFull) instead; see QUEUE-BENCHMARK.md
    this.boss = this.mk(3); await this.boss.start();
    await this.boss.work('jobs', { batchSize: conc, localConcurrency: 1, burstWhenBatchFull: true }, async (jobs: any[]) => { await Promise.all(jobs.map((j) => h(j.data as Job))); });
  }
  async stopWorker() { /* stopped with close() */ }
  private async q(sql: string, v: any[] = []) { const p = this.pool ?? new Pool({ connectionString: PG_URL, max: 1 }); const r = await p.query(sql, v); if (!this.pool) await p.end(); return r.rows; }
  async pending() { const r = await this.q(`SELECT count(*)::int n FROM pgboss.job WHERE name='jobs' AND state IN ('created','retry','active')`); return r[0].n; }
  async failed() { const r = await this.q(`SELECT count(*)::int n FROM pgboss.job WHERE name='jobs' AND state='failed'`); return r[0].n; }
  async reindexIds(run: string) { const r = await this.q(`SELECT (data->>'cv')::int cv FROM pgboss.job WHERE name='jobs' AND data->>'run'=$1`, [run]); return r.map((x) => x.cv); }
  async close() { await this.boss?.stop({ graceful: false }).catch(() => {}); this.boss = undefined; await this.pool?.end().catch(() => {}); this.pool = undefined; }
}

// ---------- graphile-worker ----------
class GraphileAdapter implements Adapter {
  name: StackName = 'graphile-worker';
  lib = { failed: 0, stalled: 0, error: 0 };
  pool?: Pool; utils?: WorkerUtils; runner?: Runner; wpool?: Pool;
  async open() {
    if (this.utils) return;
    this.pool = new Pool({ connectionString: PG_URL, max: 10 }); this.pool.on('error', () => this.lib.error++);
    this.utils = await makeWorkerUtils({ pgPool: this.pool }); await this.utils.migrate();
  }
  async reset() {
    const p = new Pool({ connectionString: PG_URL, max: 1 });
    await p.query('DROP SCHEMA IF EXISTS graphile_worker CASCADE'); await p.end();
    await this.open();
  }
  async enqueue(jobs: Job[]) {
    await this.utils!.addJobs(jobs.map((j) => ({ identifier: 'job', payload: j as any, ...(j.s ? { runAt: new Date(j.s) } : {}) })));
  }
  async enqueueInTx(client: any, j: Job) { await client.query(`SELECT graphile_worker.add_job('job', $1::json)`, [JSON.stringify(j)]); }
  async startWorker(conc: number, h: Handler) {
    this.wpool = new Pool({ connectionString: PG_URL, max: conc + 2 }); this.wpool.on('error', () => this.lib.error++);
    this.runner = await gwRun({ pgPool: this.wpool, concurrency: conc, noHandleSignals: true, logger: new Logger(() => () => {}), taskList: { job: async (payload: any) => { await h(payload as Job); } } });
    this.runner.events.on('job:error', () => this.lib.failed++);
    this.runner.events.on('job:failed', () => this.lib.failed++);
  }
  async stopWorker() { await this.runner?.stop().catch(() => {}); this.runner = undefined; await this.wpool?.end().catch(() => {}); this.wpool = undefined; }
  private async q(sql: string, v: any[] = []) { const p = this.pool ?? new Pool({ connectionString: PG_URL, max: 1 }); const r = await p.query(sql, v); if (!this.pool) await p.end(); return r.rows; }
  async pending() { const r = await this.q(`SELECT count(*)::int n FROM graphile_worker._private_jobs`); return r[0].n; }
  async failed() { const r = await this.q(`SELECT count(*)::int n FROM graphile_worker._private_jobs WHERE last_error IS NOT NULL`); return r[0].n; }
  async reindexIds(run: string) { const r = await this.q(`SELECT (payload->>'cv')::int cv FROM graphile_worker._private_jobs WHERE payload->>'run'=$1`, [run]); return r.map((x) => x.cv); }
  async close() { await this.stopWorker(); try { await this.utils?.release(); } catch {} this.utils = undefined; await this.pool?.end().catch(() => {}); this.pool = undefined; }
}

export function makeAdapter(s: StackName): Adapter {
  if (s === 'pg-boss') return new PgBossAdapter();
  if (s === 'graphile-worker') return new GraphileAdapter();
  return new BullAdapter(s);
}
