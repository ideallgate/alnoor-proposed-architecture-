// Express app: GET /hadith/:id (cache-aside over Redis, PostgreSQL on miss). :id may be "rand".
import express from 'express';
import { Redis } from 'ioredis';
import { Pool } from 'pg';
import { PG_URL } from './common';

const pool = new Pool({ connectionString: PG_URL, max: 10 });
const redis = new Redis({ host: process.env.CACHE_HOST!, port: 6379 });
redis.on('error', () => {});
let hits = 0, misses = 0, errors = 0;
const SQL = `SELECT h.id,h.number,h.book_id,h.chapter_id, rw.id AS riwaya_id, rw.source, rw.grade, rw.text_ar, rw.is_default, ra.id AS rawi_id, ra.name AS rawi_name, ra.tabaqa FROM hadith h JOIN riwaya rw ON rw.hadith_id=h.id JOIN rawi ra ON ra.id=rw.rawi_id WHERE h.id=$1 AND h.status='published' ORDER BY rw.is_default DESC, rw.id`;
const app = express();
app.get('/hadith/:id', async (req, res) => {
  try {
    // "rand": 80% of requests hit the hottest 10% of ids, 20% spread over all 20,000 (skewed, cache-friendly)
    const id = req.params.id === 'rand' ? (Math.random() < 0.8 ? 1 + Math.floor(Math.random() * 2000) : 1 + Math.floor(Math.random() * 20000)) : Number(req.params.id);
    const key = `hadith:${id}`;
    const c = await redis.get(key);
    if (c) { hits++; return res.type('json').send(c); }
    misses++;
    const r = await pool.query(SQL, [id]);
    if (!r.rows.length) return res.status(404).json({ error: 'not found' });
    const f = r.rows[0];
    const body = JSON.stringify({ id: f.id, number: f.number, book_id: f.book_id, chapter_id: f.chapter_id, riwayat: r.rows.map((x) => ({ id: x.riwaya_id, source: x.source, grade: x.grade, text: x.text_ar, default: x.is_default, rawi: { id: x.rawi_id, name: x.rawi_name, tabaqa: x.tabaqa } })) });
    redis.set(key, body, 'EX', 300).catch(() => errors++);
    res.type('json').send(body);
  } catch { errors++; res.status(500).json({ error: 'internal' }); }
});
app.get('/_stats', (_q, r) => { r.json({ hits, misses, errors }); });
app.post('/_reset', (_q, r) => { hits = misses = errors = 0; r.json({ ok: true }); });
app.listen(8080, '127.0.0.1');
