// S6: BullMQ (dedicated redis-queue) + transactional outbox. Child process used as producer, relay or worker.
import { Queue, Worker } from 'bullmq';
import { Pool } from 'pg';
import { PG_URL, pct, sleep } from './common';

const HOST = 'redis-queue';
let pool: Pool, queue: Queue, worker: Worker | undefined;
let relayRunning = false, relayLoop: Promise<void> | undefined;
const seen = new Map<number, number>(); const lat: number[] = [];
let total = 0, distinct = 0, lastEnd = 0;

const DDL = `CREATE TABLE IF NOT EXISTS outbox (id bigserial PRIMARY KEY, payload jsonb NOT NULL, created_at timestamptz NOT NULL DEFAULT now(), sent_at timestamptz, done_at timestamptz);
CREATE INDEX IF NOT EXISTS outbox_unsent ON outbox (id) WHERE sent_at IS NULL;`;

// one relay cycle: lock a batch of unsent rows, queue.add each with jobId = outbox id, then mark sent (second step)
async function cycle(batch: number, killAfterAdd: boolean): Promise<number> {
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    const r = await c.query('SELECT id, payload FROM outbox WHERE sent_at IS NULL ORDER BY id LIMIT $1 FOR UPDATE SKIP LOCKED', [batch]);
    if (!r.rows.length) { await c.query('COMMIT'); return 0; }
    await queue.addBulk(r.rows.map((x) => ({ name: 'reindex', data: x.payload, opts: { jobId: 'ob-' + x.id } })));
    if (killAfterAdd) process.kill(process.pid, 'SIGKILL');          // crash between queue.add and marking sent
    await c.query('UPDATE outbox SET sent_at = now() WHERE id = ANY($1)', [r.rows.map((x) => x.id)]);
    await c.query('COMMIT');
    return r.rows.length;
  } catch (e) { try { await c.query('ROLLBACK'); } catch {} throw e; } finally { c.release(); }
}

const H: Record<string, (x: any) => Promise<any>> = {
  async init({ keep = false } = {}) {
    pool = new Pool({ connectionString: PG_URL, max: 4 }); pool.on('error', () => {});
    await pool.query(DDL);
    queue = new Queue('jobs', { connection: { host: HOST, port: 6379 }, defaultJobOptions: { removeOnComplete: keep ? { age: 3600 } : true } }); queue.on('error', () => {});
  },
  async reset() { await queue.obliterate({ force: true }); await pool.query('TRUNCATE outbox'); },
  async publish({ n, inject, run, kill, killAfterCommit }) {
    let crashed = 0, ok = 0; const t0 = Date.now();
    for (let i = 0; i < n; i++) {
      const c = await pool.connect();
      try {
        await c.query('BEGIN');
        const r = await c.query('INSERT INTO content_versions(run,content_id,version) VALUES($1,$2,1) RETURNING id', [run, i]);
        await c.query('INSERT INTO outbox(payload) VALUES($1)', [JSON.stringify({ kind: 'reindex', i, cv: r.rows[0].id, run, t: Date.now() })]);
        if (inject) { if (kill) process.kill(process.pid, 'SIGKILL'); crashed++; c.release(true); continue; }   // crash before COMMIT
        await c.query('COMMIT');
        if (killAfterCommit) process.kill(process.pid, 'SIGKILL');                                           // crash after COMMIT, before any relay
        ok++; c.release();
      } catch (e) { try { c.release(true); } catch {} throw e; }
    }
    return { ms: Date.now() - t0, crashed, ok };
  },
  async relayOnce({ batch = 100, killAfterAdd = false }) { return { sent: await cycle(batch, killAfterAdd) }; },
  async relayDrain({ batch = 100 }) { const t0 = Date.now(); let n = 0, k; while ((k = await cycle(batch, false))) n += k; return { sent: n, ms: Date.now() - t0 }; },
  async relayStart({ batch = 100, pollMs = 100 }) {
    relayRunning = true;
    relayLoop = (async () => { while (relayRunning) { try { const n = await cycle(batch, false); if (!n) await sleep(pollMs); } catch { await sleep(pollMs); } } })();
  },
  async relayStop() { relayRunning = false; await relayLoop; },
  async unsent() { return (await pool.query('SELECT count(*)::int n FROM outbox WHERE sent_at IS NULL')).rows[0].n; },
  async notDone() { return (await pool.query('SELECT count(*)::int n FROM outbox WHERE done_at IS NULL')).rows[0].n; },
  async workerStart({ conc }) {
    seen.clear(); lat.length = 0; total = distinct = lastEnd = 0;
    worker = new Worker('jobs', async (job) => {
      const st = Date.now(); const d = job.data; const c = (seen.get(d.cv) ?? 0) + 1; seen.set(d.cv, c); total++; if (c === 1) distinct++;
      lat.push(st - d.t);
      await pool.query('UPDATE outbox SET done_at = now() WHERE id = $1', [String(job.id).replace('ob-', '')]);   // mark the reindex as done
      lastEnd = Date.now();
    }, { connection: { host: HOST, port: 6379, maxRetriesPerRequest: null }, concurrency: conc });
    worker.on('error', () => {}); await worker.waitUntilReady();
  },
  async progress() { return { distinct, total, lastEnd }; },
  async stats() { return { distinct, total, dups: total - distinct, lastEnd, lat: { p50: pct(lat, 50), p95: pct(lat, 95), p99: pct(lat, 99), n: lat.length } }; },
  async pending() { const c = await queue.getJobCounts('waiting', 'delayed', 'active', 'prioritized'); return Object.values(c).reduce((a, b) => a + b, 0); },
  async reindexIds({ run }) {
    const jobs = await queue.getJobs(['waiting', 'delayed', 'active', 'completed', 'failed', 'prioritized'], 0, -1);
    return jobs.filter((j) => j?.data?.run === run).map((j) => j.data.cv);
  },
  // documented reconciliation: re-enqueue every outbox row whose reindex is not marked done (jobId = outbox id, so repeats collapse)
  async reconcile() {
    const t0 = Date.now(); let n = 0;
    const rows = (await pool.query('SELECT id, payload FROM outbox WHERE done_at IS NULL ORDER BY id')).rows;
    for (let i = 0; i < rows.length; i += 1000) { await queue.addBulk(rows.slice(i, i + 1000).map((x) => ({ name: 'reindex', data: x.payload, opts: { jobId: 'ob-' + x.id } }))); n += Math.min(1000, rows.length - i); }
    return { rows: rows.length, enqueued: n, ms: Date.now() - t0 };
  },
  async close() { relayRunning = false; await worker?.close(true).catch(() => {}); await queue?.close().catch(() => {}); await pool?.end().catch(() => {}); },
};

process.on('message', async (m: any) => {
  try { const r = await H[m.cmd](m.args ?? {}); process.send!({ id: m.id, ok: true, r }); }
  catch (e: any) { process.send!({ id: m.id, ok: false, err: String(e?.stack ?? e) }); }
});
process.send!({ ready: true });
