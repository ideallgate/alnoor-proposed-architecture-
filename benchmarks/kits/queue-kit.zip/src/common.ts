import { execFile } from 'node:child_process';

export const PG_URL = 'postgres://noor:noor@postgres:5432/noor';
export type StackName = 'bullmq-dedicated' | 'bullmq-shared' | 'pg-boss' | 'graphile-worker';
export const STACKS: StackName[] = ['bullmq-dedicated', 'bullmq-shared', 'pg-boss', 'graphile-worker'];
export const HOSTS = { shared: 'redis-shared', queue: 'redis-queue', cache: 'redis-cache' };
export const CONTAINERS = { postgres: 'noor-postgres', 'redis-shared': 'noor-redis-shared', 'redis-queue': 'noor-redis-queue', 'redis-cache': 'noor-redis-cache' };

export interface Job { kind: 'noop' | 'audio' | 'delayed' | 'reindex'; i: number; t: number; s?: number; pad?: string; cv?: number; run?: string }

export const queueRedisHost = (s: StackName) => (s === 'bullmq-shared' ? HOSTS.shared : HOSTS.queue);
export const cacheRedisHost = (s: StackName | 'baseline-cache' | 'baseline-shared') =>
  s === 'bullmq-shared' || s === 'baseline-shared' ? HOSTS.shared : HOSTS.cache;

export const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));
export function pct(a: number[], p: number): number | null {
  if (!a.length) return null;
  const s = [...a].sort((x, y) => x - y);
  return s[Math.min(s.length - 1, Math.max(0, Math.ceil((p / 100) * s.length) - 1))];
}
export function median(a: number[]): number | null { const v = a.filter((x) => x != null && !Number.isNaN(x)); return pct(v, 50); }
export function sh(cmd: string, args: string[], timeout = 120000): Promise<string> {
  return new Promise((res, rej) => execFile(cmd, args, { timeout, maxBuffer: 64 << 20 }, (e, so, se) => (e ? rej(new Error(`${cmd} ${args.join(' ')}: ${se || e.message}`)) : res(so))));
}
