// Orchestrator: runs all scenarios, appends one JSON line per run to <out>/raw.jsonl (resumable).
import { fork, spawn, ChildProcess } from 'node:child_process';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { Redis } from 'ioredis';
import { Pool } from 'pg';
import { CONTAINERS, HOSTS, PG_URL, STACKS, StackName, cacheRedisHost, median, queueRedisHost, sh, sleep } from './common';

const argv = process.argv.slice(2);
const arg = (n: string, d?: string) => { const i = argv.indexOf('--' + n); return i >= 0 ? argv[i + 1] : d; };
const PASS = Number(arg('pass', '1'));
const SMOKE = argv.includes('--smoke');
const RUNS = Number(arg('runs', SMOKE ? '1' : '5'));
const ONLY = (arg('only', 'S1,S2,S3,S4,S5') as string).split(',');
const OUT = `/out/${SMOKE ? 'results-smoke' : 'results-pass' + PASS}`;
const ORDER: StackName[] = (PASS === 2 ? [...STACKS].reverse() : [...STACKS]).filter((s) => (arg('stacks') ? arg('stacks')!.split(',').includes(s) : true));
const K = SMOKE ? 10 : 1; // scale divisor for smoke runs
const N1 = 50000 / K, N_AUDIO = 5000 / K, N_DELAY = 10000 / K, N_Q = 20000 / K, AB_SECS = SMOKE ? 10 : 60, S5_N = 1000 / K;
fs.mkdirSync(OUT, { recursive: true });
const RAW = path.join(OUT, 'raw.jsonl');
const done = new Set<string>();
if (fs.existsSync(RAW)) for (const l of fs.readFileSync(RAW, 'utf8').split('\n').filter(Boolean)) { const r = JSON.parse(l); done.add(`${r.scenario}|${r.cell}|${r.conc ?? ''}|${r.run}`); }
const log = (...a: any[]) => console.log(new Date().toISOString().slice(11, 19), ...a);

// ---------- helpers ----------
class Agent {
  seq = 0; pend = new Map<number, { res: (v: any) => void; rej: (e: Error) => void }>(); cp: ChildProcess; dead = false;
  private constructor() { this.cp = fork(path.join(__dirname, 'agent.js')); }
  static async create(stack: StackName) {
    const a = new Agent();
    await new Promise<void>((res) => a.cp.once('message', () => res()));
    a.cp.on('message', (m: any) => { const p = a.pend.get(m.id); if (!p) return; a.pend.delete(m.id); m.ok ? p.res(m.r) : p.rej(new Error(m.err)); });
    a.cp.on('exit', () => { a.dead = true; for (const p of a.pend.values()) p.rej(new Error('agent exited')); a.pend.clear(); });
    await a.call('init', { stack });
    return a;
  }
  call(cmd: string, args: any = {}, timeout = 900000): Promise<any> {
    return new Promise((res, rej) => {
      const id = ++this.seq; const t = setTimeout(() => { this.pend.delete(id); rej(new Error(`agent ${cmd} timeout`)); }, timeout);
      this.pend.set(id, { res: (v) => { clearTimeout(t); res(v); }, rej: (e) => { clearTimeout(t); rej(e); } });
      this.cp.send({ id, cmd, args });
    });
  }
  async dispose() { try { await this.call('close', {}, 20000); } catch {} this.cp.kill('SIGKILL'); }
  kill() { this.cp.kill('SIGKILL'); }
}

const toMiB = (s: string) => { const m = s.trim().match(/([\d.]+)\s*(B|KiB|MiB|GiB|kB|MB|GB)/); if (!m) return 0; const v = Number(m[1]); return { B: v / 1048576, KiB: v / 1024, kB: v / 1024, MiB: v, MB: v, GiB: v * 1024, GB: v * 1024 }[m[2]] ?? 0; };
class Sampler {
  data: Record<string, { cpu: number[]; mem: number[] }> = {}; redisMax: Record<string, number> = {}; running = false; p?: Promise<void>;
  clients: Record<string, Redis> = {};
  start() {
    this.running = true;
    for (const h of Object.values(HOSTS)) if (!this.clients[h]) { this.clients[h] = new Redis({ host: h, lazyConnect: true, maxRetriesPerRequest: 1, retryStrategy: () => 1000 }); this.clients[h].on('error', () => {}); }
    this.p = (async () => {
      while (this.running) {
        try {
          const out = await sh('docker', ['stats', '--no-stream', '--format', '{{.Name}}|{{.CPUPerc}}|{{.MemUsage}}', ...Object.values(CONTAINERS), 'noor-runner'], 20000);
          for (const l of out.trim().split('\n')) { const [n, c, m] = l.split('|'); const d = (this.data[n] ??= { cpu: [], mem: [] }); d.cpu.push(parseFloat(c)); d.mem.push(toMiB(m.split('/')[0])); }
        } catch {}
        for (const [h, c] of Object.entries(this.clients)) { try { const i = await c.info('memory'); const u = Number(i.match(/used_memory:(\d+)/)![1]) / 1048576; this.redisMax[h] = Math.max(this.redisMax[h] ?? 0, u); } catch {} }
        await sleep(500);
      }
    })();
  }
  async stop() {
    this.running = false; await this.p;
    const r: any = { cpu_pct_avg: {}, cpu_pct_max: {}, mem_mib_max: {}, redis_used_mib_max: {} };
    for (const [n, d] of Object.entries(this.data)) { r.cpu_pct_avg[n] = d.cpu.length ? +(d.cpu.reduce((a, b) => a + b, 0) / d.cpu.length).toFixed(1) : null; r.cpu_pct_max[n] = d.cpu.length ? Math.max(...d.cpu) : null; r.mem_mib_max[n] = d.mem.length ? +Math.max(...d.mem).toFixed(1) : null; }
    for (const [h, v] of Object.entries(this.redisMax)) r.redis_used_mib_max[h] = +v.toFixed(1);
    this.data = {}; this.redisMax = {};
    return r;
  }
}
const sampler = new Sampler();

function record(scenario: string, cell: string, run: number, conc: number | undefined, metrics: any) {
  const r = { pass: PASS, scenario, cell, conc, run, at: new Date().toISOString(), ...metrics };
  fs.appendFileSync(RAW, JSON.stringify(r) + '\n'); done.add(`${scenario}|${cell}|${conc ?? ''}|${run}`);
  log(scenario, cell, conc ?? '', 'run', run, JSON.stringify(metrics).slice(0, 300));
}
const isDone = (s: string, c: string, conc: number | undefined, run: number) => done.has(`${s}|${c}|${conc ?? ''}|${run}`);

async function waitDrain(w: Agent, expected: number, stallMs = 60000, maxMs = 20 * 60000) {
  let last = -1, lastChange = Date.now(); const t0 = Date.now();
  for (;;) {
    const p = await w.call('progress');
    if (p.distinct >= expected) return { complete: true, reason: '' };
    if (p.distinct !== last) { last = p.distinct; lastChange = Date.now(); }
    else if (Date.now() - lastChange > stallMs) return { complete: false, reason: `no progress for ${stallMs / 1000}s at ${p.distinct}/${expected}` };
    if (Date.now() - t0 > maxMs) return { complete: false, reason: 'max time' };
    await sleep(250);
  }
}
async function waitUp(c: 'postgres' | 'redis', host: string, ms = 180000) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) {
    try {
      if (c === 'redis') { const r = new Redis({ host, lazyConnect: true, maxRetriesPerRequest: 1, retryStrategy: () => null }); r.on('error', () => {}); await r.connect(); const ok = (await r.ping()) === 'PONG' && !(await r.info('persistence')).includes('loading:1'); r.disconnect(); if (ok) return Date.now() - t0; }
      else { const p = new Pool({ connectionString: PG_URL, max: 1 }); p.on('error', () => {}); await p.query('select 1'); await p.end(); return Date.now() - t0; }
    } catch {}
    await sleep(300);
  }
  throw new Error('service did not come back');
}

// ---------- queue load shared by S2 and S3 ----------
async function prepareLoad(stack: StackName, conc: number) {
  const prod = await Agent.create(stack); await prod.call('reset');
  const wk = await Agent.create(stack); await wk.call('start', { conc });
  return { prod, wk, t0: 0, T: 0, ed: null as any, ea: null as any };
}
async function fireLoad(c: Awaited<ReturnType<typeof prepareLoad>>) {
  c.t0 = Date.now();
  c.T = Math.ceil((c.t0 + 10000) / 1000) * 1000;             // notification burst: all due in the same second, 10 s from now
  c.ed = await c.prod.call('enqueueGen', { kind: 'delayed', count: N_DELAY, s: c.T });
  c.ea = await c.prod.call('enqueueGen', { kind: 'audio', count: N_AUDIO });
}
async function endLoad(c: Awaited<ReturnType<typeof prepareLoad>>) { await c.wk.dispose(); await c.prod.dispose(); }
function loadMetrics(c: any, st: any, store_failed: number, complete: boolean, reason: string) {
  return {
    complete, reason, enq_delayed_ms: c.ed.ms, enq_audio_ms: c.ea.ms, enq_failed: c.ed.failed + c.ea.failed, enq_errs: [...c.ed.errs, ...c.ea.errs],
    enq_finished_after_due: c.t0 + c.ed.ms > c.T,
    completion_ms: complete ? st.lastEnd - c.t0 : null, executed: st.distinct, expected: c.ed.ok + c.ea.ok,
    delayed_done: st.kinds.delayed ?? 0, audio_done: st.kinds.audio ?? 0,
    late_p50: st.late.p50, late_p95: st.late.p95, late_p99: st.late.p99,
    lost: c.ed.ok + c.ea.ok - st.distinct, dups: st.dups, failed: st.lib.failed + store_failed + st.handlerErrors, stalled: st.lib.stalled, lib_errors: st.lib.error,
  };
}

// ---------- S1 ----------
async function S1(stack: StackName, conc: number, run: number) {
  const prod = await Agent.create(stack); await prod.call('reset');
  const wk = await Agent.create(stack); await wk.call('start', { conc });
  sampler.start();
  const t0 = Date.now();
  const enq = await prod.call('enqueueGen', { kind: 'noop', count: N1 });
  const tEnq = Date.now();
  const dr = await waitDrain(wk, enq.ok);
  await sleep(2000);
  const st = await wk.call('stats'); const sf = await prod.call('failed');
  const res = await sampler.stop();
  record('S1', stack, run, conc, {
    complete: dr.complete, reason: dr.reason, enq_ms: enq.ms, enq_rate: Math.round(enq.ok / (enq.ms / 1000)), enq_failed: enq.failed, enq_errs: enq.errs,
    total_ms: dr.complete ? st.lastEnd - t0 : null, drain_after_enq_ms: dr.complete ? Math.max(0, st.lastEnd - tEnq) : null,
    throughput: dr.complete ? Math.round(st.distinct / ((st.lastEnd - t0) / 1000)) : null,
    lat_p50: st.lat.p50, lat_p95: st.lat.p95, lat_p99: st.lat.p99,
    lost: enq.ok - st.distinct, dups: st.dups, failed: st.lib.failed + sf + st.handlerErrors, stalled: st.lib.stalled, lib_errors: st.lib.error, resources: res,
  });
  await wk.dispose(); await prod.dispose();
}

// ---------- S2 ----------
async function S2(stack: StackName, conc: number, run: number) {
  const c = await prepareLoad(stack, conc); sampler.start();
  await fireLoad(c);
  const dr = await waitDrain(c.wk, c.ed.ok + c.ea.ok);
  await sleep(2000);
  const st = await c.wk.call('stats'); const sf = await c.prod.call('failed');
  const res = await sampler.stop();
  record('S2', stack, run, conc, { ...loadMetrics(c, st, sf, dr.complete, dr.reason), resources: res });
  await endLoad(c);
}

// ---------- S3 ----------
async function S3(cell: string, run: number) {
  const stack = STACKS.includes(cell as StackName) ? (cell as StackName) : null;
  const host = cacheRedisHost(cell as any);
  const api = spawn('node', [path.join(__dirname, 'api.js')], { env: { ...process.env, CACHE_HOST: host }, stdio: 'inherit' });
  try {
    for (let i = 0; i < 100; i++) { try { await fetch('http://127.0.0.1:8080/_stats'); break; } catch { await sleep(200); } }
    const cr = new Redis({ host }); const keys: string[] = [];
    for await (const ks of cr.scanStream({ match: 'hadith:*', count: 1000 })) keys.push(...ks);
    for (let i = 0; i < keys.length; i += 1000) await cr.unlink(...keys.slice(i, i + 1000));
    cr.disconnect();
    await fetch('http://127.0.0.1:8080/_reset', { method: 'POST' });
    const ctx = stack ? await prepareLoad(stack, 10) : null;
    sampler.start();
    const ab = spawn('ab', ['-q', '-k', '-c', '100', '-t', String(AB_SECS), '-n', '1000000000', 'http://127.0.0.1:8080/hadith/rand']);
    let out = ''; ab.stdout.on('data', (d) => (out += d)); ab.stderr.on('data', (d) => (out += d));
    const abDone = new Promise<void>((r) => ab.on('close', () => r()));
    let loadM: any = null;
    if (ctx) { await sleep(2000); await fireLoad(ctx); }
    await abDone;
    if (ctx) {
      const p = await ctx.wk.call('progress'); const st = await ctx.wk.call('stats'); const sf = await ctx.prod.call('failed');
      const expected = ctx.ed.ok + ctx.ea.ok;
      loadM = { ...loadMetrics(ctx, st, sf, p.distinct >= expected, ''), done_at_ab_end: p.distinct, load_window_covered: p.distinct < expected, load_finished_ms: p.distinct >= expected ? st.lastEnd - ctx.t0 : null };
    }
    const res = await sampler.stop();
    const g = (re: RegExp) => { const m = out.match(re); return m ? Number(m[1]) : null; };
    const apiStats = await (await fetch('http://127.0.0.1:8080/_stats')).json();
    record('S3', cell, run, undefined, {
      rps: g(/Requests per second:\s+([\d.]+)/), p50: g(/\n\s*50%\s+(\d+)/), p95: g(/\n\s*95%\s+(\d+)/), p99: g(/\n\s*99%\s+(\d+)/), max: g(/\n\s*100%\s+(\d+)/),
      complete_requests: g(/Complete requests:\s+(\d+)/), failed_requests_total: g(/Failed requests:\s+(\d+)/), connect_fail: g(/Connect: (\d+)/), receive_fail: g(/Receive: (\d+)/), exceptions: g(/Exceptions: (\d+)/), length_mismatch: g(/Length: (\d+)/), non2xx: g(/Non-2xx responses:\s+(\d+)/) ?? 0,
      cache_hits: apiStats.hits, cache_misses: apiStats.misses, api_errors: apiStats.errors, queue_load: loadM, resources: res,
    });
    if (ctx) await endLoad(ctx);
  } finally { api.kill('SIGKILL'); await sleep(500); }
}

// ---------- S4 ----------
const PAD = 1024;
async function cacheWrites(admin: Redis, total: number) {
  const val = 'v'.repeat(8192); let ok = 0, failed = 0; const errs = new Set<string>();
  for (let b = 0; b < total / 100; b++) {
    const p = admin.pipeline(); for (let k = 0; k < 100; k++) p.set(`cache:${b}:${k}`, val);
    const r = await p.exec();
    for (const [e] of r!) { if (e) { failed++; errs.add(String(e.message).slice(0, 80)); } else ok++; }
  }
  return { ok, failed, errs: [...errs] };
}
async function S4ab(mode: 'a' | 'b', run: number) {
  const stack: StackName = 'bullmq-shared';
  const admin = new Redis({ host: HOSTS.shared });
  await admin.flushall(); await admin.config('SET', 'maxmemory', '256mb'); await admin.config('SET', 'maxmemory-policy', mode === 'a' ? 'allkeys-lru' : 'noeviction'); await admin.config('RESETSTAT');
  const prod = await Agent.create(stack); await prod.call('reset');
  const enq = await prod.call('enqueueGen', { kind: 'noop', count: N_Q, pad: PAD });
  const memQueue = Number((await admin.info('memory')).match(/used_memory:(\d+)/)![1]) / 1048576;
  const cw = await cacheWrites(admin, SMOKE ? 5000 : 50000);
  const info = await admin.info('stats'); const mem = await admin.info('memory');
  // integrity of the queue as stored in Redis
  const waitLen = await admin.llen('bull:jobs:wait'); const ids = await admin.lrange('bull:jobs:wait', 0, -1);
  let withHash = 0;
  for (let i = 0; i < ids.length; i += 1000) { const p = admin.pipeline(); ids.slice(i, i + 1000).forEach((id) => p.exists(`bull:jobs:${id}`)); (await p.exec())!.forEach(([, v]) => (withHash += Number(v))); }
  let hashes = 0; for await (const ks of admin.scanStream({ match: 'bull:jobs:*', count: 1000 })) hashes += ks.filter((k: string) => /^bull:jobs:\d+$/.test(k)).length;
  let extra = { ok: 0, failed: 0, errs: [] as string[] };
  if (mode === 'b') extra = await prod.call('enqueueGen', { kind: 'reindex', count: 1000 / K, start: 1000000, pad: PAD });
  // can the surviving queue still be worked?
  const wk = await Agent.create(stack); await wk.call('start', { conc: 50 });
  const dr = await waitDrain(wk, N_Q + extra.ok, 20000, 120000);
  await sleep(1000);
  const st = await wk.call('stats');
  record(mode === 'a' ? 'S4a' : 'S4b', mode === 'a' ? 'allkeys-lru' : 'noeviction', run, undefined, {
    queued: enq.ok, enq_failed: enq.failed, mem_after_queue_mib: +memQueue.toFixed(1), cache_writes_ok: cw.ok, cache_writes_failed: cw.failed, cache_errs: cw.errs,
    used_mem_mib_after: +(Number(mem.match(/used_memory:(\d+)/)![1]) / 1048576).toFixed(1), evicted_keys: Number(info.match(/evicted_keys:(\d+)/)![1]),
    wait_list_len: waitLen, job_hashes_present: hashes, listed_with_hash: withHash, listed_missing_hash: ids.length - withHash,
    extra_enqueue_ok: extra.ok, extra_enqueue_failed: extra.failed, extra_errs: extra.errs,
    executed: st.distinct, expected: N_Q + extra.ok, lost: N_Q - (st.kinds.noop ?? 0) + 0, worker_complete: dr.complete, worker_reason: dr.reason, lib_failed: st.lib.failed, lib_errors: st.lib.error, dups: st.dups,
  });
  await wk.dispose(); await prod.dispose();
  await admin.config('SET', 'maxmemory-policy', 'allkeys-lru'); await admin.flushall(); admin.disconnect();
}
async function S4c(stack: StackName, run: number) {
  const store = stack === 'bullmq-dedicated' ? 'redis-queue' : stack === 'bullmq-shared' ? 'redis-shared' : 'postgres';
  const container = CONTAINERS[store as keyof typeof CONTAINERS];
  const prod = await Agent.create(stack); await prod.call('reset');
  const enq = await prod.call('enqueueGen', { kind: 'noop', count: N_Q });
  const before = await prod.call('pending');
  await sh('docker', ['kill', '-s', 'KILL', container]); prod.kill();               // hard kill straight after the last enqueue is acknowledged
  await sh('docker', ['start', container]);
  const recoverMs = await waitUp(store === 'postgres' ? 'postgres' : 'redis', store);
  const chk = await Agent.create(stack); await chk.call('open');
  const survivors = await chk.call('pending');
  await chk.dispose();
  const wk = await Agent.create(stack); await wk.call('start', { conc: 50 });
  const dr = await waitDrain(wk, survivors, 30000, 180000); await sleep(1500);
  const st = await wk.call('stats');
  record('S4c', stack, run, undefined, {
    store, persistence: store === 'redis-queue' ? 'AOF everysec' : store === 'redis-shared' ? 'none' : 'WAL, synchronous_commit=on (default)',
    enqueued: enq.ok, enq_failed: enq.failed, pending_before_kill: before, survivors_after_restart: survivors, recover_ms: recoverMs,
    executed_after_restart: st.distinct, lost: enq.ok - st.distinct, lost_before_execution: enq.ok - survivors, dups: st.dups, worker_complete: dr.complete, lib_failed: st.lib.failed,
  });
  await wk.dispose();
}

// ---------- S5 ----------
async function S5(stack: StackName, run: number) {
  const id = `${PASS}-${stack}-${run}-${Date.now()}`;
  const pool = new Pool({ connectionString: PG_URL, max: 2 });
  const prod = await Agent.create(stack); await prod.call('reset');
  const ctl = await prod.call('publish', { n: S5_N, inject: false, run: id + '-ctl' });
  const inj = await prod.call('publish', { n: S5_N, inject: true, run: id + '-inj' });
  const KILLS = SMOKE ? 3 : 20; let killed = 0;
  for (let k = 0; k < KILLS; k++) {
    const a = await Agent.create(stack);
    try { await a.call('publish', { n: 1, inject: true, kill: true, run: id + '-kill' }, 60000); } catch { killed++; }
    a.kill();
  }
  const out: any = { crash_model: 'exception+connection drop (n injected) and real SIGKILL of the process (kills)', publish_ms_per_op_no_crash: +(ctl.ms / S5_N).toFixed(2), kills_requested: KILLS, kills_process_died: killed };
  for (const g of ['ctl', 'inj', 'kill']) {
    const committed: number[] = (await pool.query('SELECT id FROM content_versions WHERE run=$1', [`${id}-${g}`])).rows.map((r) => r.id);
    const jobs: number[] = await prod.call('reindexIds', { run: `${id}-${g}` });
    const js = new Set(jobs), cs = new Set(committed);
    out[g] = { attempts: g === 'kill' ? KILLS : S5_N, content_committed: committed.length, reindex_jobs: jobs.length, committed_without_job: committed.filter((x) => !js.has(x)).length, job_without_commit: jobs.filter((x) => !cs.has(x)).length };
  }
  record('S5', stack, run, undefined, out);
  await prod.dispose(); await pool.end();
}

// ---------- environment ----------
async function captureEnv() {
  const env: any = { when: new Date().toISOString(), pass: PASS, order: ORDER, smoke: SMOKE, node: process.version };
  env.docker = (await sh('docker', ['version', '--format', '{{.Server.Version}} {{.Server.Os}}/{{.Server.Arch}}'])).trim();
  env.docker_vm = (await sh('docker', ['info', '--format', 'CPUs={{.NCPU}} Mem={{.MemTotal}} Kernel={{.KernelVersion}}'])).trim();
  env.containers = {};
  for (const [k, n] of Object.entries({ ...CONTAINERS, runner: 'noor-runner' })) {
    const i = JSON.parse(await sh('docker', ['inspect', n]))[0];
    env.containers[k] = { image: i.Config.Image, image_id: i.Image, cpus: i.HostConfig.NanoCpus / 1e9, memory_mib: i.HostConfig.Memory / 1048576, cmd: i.Config.Cmd };
  }
  env.redis = {};
  for (const h of Object.values(HOSTS)) { const r = new Redis({ host: h }); const v = (await r.info('server')).match(/redis_version:(\S+)/)![1]; const cfg: any = {}; for (const key of ['maxmemory', 'maxmemory-policy', 'appendonly', 'appendfsync', 'save']) { const [, val] = (await r.config('GET', key)) as string[]; cfg[key] = val; } env.redis[h] = { version: v, ...cfg }; r.disconnect(); }
  const p = new Pool({ connectionString: PG_URL, max: 1 }); env.postgres = { version: (await p.query('select version()')).rows[0].version };
  for (const k of ['fsync', 'synchronous_commit', 'full_page_writes', 'wal_level', 'shared_buffers', 'max_connections', 'work_mem', 'checkpoint_timeout', 'autovacuum']) env.postgres[k] = (await p.query(`show ${k}`)).rows[0][k]; await p.end();
  env.libs = {}; for (const l of ['bullmq', 'ioredis', 'pg-boss', 'graphile-worker', 'pg', 'express']) env.libs[l] = JSON.parse(fs.readFileSync(`/app/node_modules/${l}/package.json`, 'utf8')).version;
  env.params = { N1, N_AUDIO, N_DELAY, N_Q, AB_SECS, S5_N, RUNS };
  fs.writeFileSync(path.join(OUT, 'environment.json'), JSON.stringify(env, null, 2));
}

// ---------- main ----------
(async () => {
  await captureEnv();
  const cooldown = () => sleep(SMOKE ? 500 : 4000);
  const step = async (sc: string, cell: string, conc: number | undefined, fn: (run: number) => Promise<void>) => {
    for (let r = 1; r <= RUNS; r++) {
      if (isDone(sc, cell, conc, r)) continue;
      try { await fn(r); } catch (e: any) { log('ERROR', sc, cell, conc, r, e.message); record(sc, cell, r, conc, { harness_error: String(e.message).slice(0, 400) }); }
      await cooldown();
    }
  };
  if (ONLY.includes('S1')) for (const conc of [10, 50]) for (const s of ORDER) await step('S1', s, conc, (r) => S1(s, conc, r));
  if (ONLY.includes('S2')) for (const conc of [10, 50]) for (const s of ORDER) await step('S2', s, conc, (r) => S2(s, conc, r));
  if (ONLY.includes('S3')) for (const cell of ['baseline-cache', 'baseline-shared', ...ORDER]) await step('S3', cell, undefined, (r) => S3(cell, r));
  if (ONLY.includes('S4')) {
    await step('S4a', 'allkeys-lru', undefined, (r) => S4ab('a', r));
    await step('S4b', 'noeviction', undefined, (r) => S4ab('b', r));
    for (const s of ORDER) await step('S4c', s, undefined, (r) => S4c(s, r));
  }
  if (ONLY.includes('S5')) for (const s of ORDER.filter((x) => x !== 'bullmq-shared' || true)) await step('S5', s, undefined, (r) => S5(s, r));
  log('ALL DONE'); process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
