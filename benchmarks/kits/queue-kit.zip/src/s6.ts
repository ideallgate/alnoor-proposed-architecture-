// S6 orchestrator: BullMQ + transactional outbox vs pg-boss vs graphile-worker. Output: /out/results-s6-pass<N>/raw.jsonl (resumable)
import { fork, ChildProcess } from 'node:child_process';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { Redis } from 'ioredis';
import { Pool } from 'pg';
import { CONTAINERS, PG_URL, sh, sleep } from './common';

const argv = process.argv.slice(2);
const arg = (n: string, d?: string) => { const i = argv.indexOf('--' + n); return i >= 0 ? argv[i + 1] : d; };
const PASS = Number(arg('pass', '1')); const SMOKE = argv.includes('--smoke'); const RUNS = Number(arg('runs', SMOKE ? '1' : '5'));
const ONLY = (arg('only', 'S6a,S6b,S6c,S6d,S6e') as string).split(',');
const OUT = `/out/${SMOKE ? 'results-s6-smoke' : 'results-s6-pass' + PASS}`;
const OUTBOX = 'bullmq-dedicated-outbox';
const BASE = [OUTBOX, 'pg-boss', 'graphile-worker'];
const ORDER = PASS === 2 ? [...BASE].reverse() : BASE;
const K = SMOKE ? 10 : 1;
const N_A = 1000 / K, N_B_KILLS = 50 / K, C_ROUNDS = 100 / K, C_BATCH = 10, N_D = 5000 / K, N_E = 1000 / K;
const POLL_MS = 100, RELAY_BATCH = 100;
const QUEUE_VOLUME = 'noor-queue-benchmark_queuedata';
const REDIS_IMAGE = 'redis@sha256:2c2dff791878316e3b083188be0d578423b24813cdda5de0e80ea4f7b3e6bfd6';
fs.mkdirSync(OUT, { recursive: true });
const RAW = path.join(OUT, 'raw.jsonl'); const done = new Set<string>();
if (fs.existsSync(RAW)) for (const l of fs.readFileSync(RAW, 'utf8').split('\n').filter(Boolean)) { const r = JSON.parse(l); done.add(`${r.scenario}|${r.cell}|${r.run}`); }
const log = (...a: any[]) => console.log(new Date().toISOString().slice(11, 19), ...a);

class Agent {
  seq = 0; pend = new Map<number, { res: (v: any) => void; rej: (e: Error) => void }>(); cp: ChildProcess;
  private constructor(script: string) { this.cp = fork(path.join(__dirname, script)); }
  static async create(script: string, init: any = {}) {
    const a = new Agent(script);
    await new Promise<void>((res) => a.cp.once('message', () => res()));
    a.cp.on('message', (m: any) => { const p = a.pend.get(m.id); if (!p) return; a.pend.delete(m.id); m.ok ? p.res(m.r) : p.rej(new Error(m.err)); });
    a.cp.on('exit', () => { for (const p of a.pend.values()) p.rej(new Error('agent exited')); a.pend.clear(); });
    await a.call('init', init);
    return a;
  }
  call(cmd: string, args: any = {}, timeout = 600000): Promise<any> {
    return new Promise((res, rej) => {
      const id = ++this.seq; const t = setTimeout(() => { this.pend.delete(id); rej(new Error(`agent ${cmd} timeout`)); }, timeout);
      this.pend.set(id, { res: (v) => { clearTimeout(t); res(v); }, rej: (e) => { clearTimeout(t); rej(e); } });
      this.cp.send({ id, cmd, args });
    });
  }
  async dispose() { try { await this.call('close', {}, 20000); } catch {} this.cp.kill('SIGKILL'); }
  kill() { this.cp.kill('SIGKILL'); }
}
const mk = (stack: string, keep = false) => (stack === OUTBOX ? Agent.create('s6agent.js', { keep }) : Agent.create('agent.js', { stack }));
const dbpool = new Pool({ connectionString: PG_URL, max: 2 }); dbpool.on('error', () => {});

function record(scenario: string, cell: string, run: number, metrics: any) {
  fs.appendFileSync(RAW, JSON.stringify({ pass: PASS, scenario, cell, run, at: new Date().toISOString(), ...metrics }) + '\n'); done.add(`${scenario}|${cell}|${run}`);
  log(scenario, cell, 'run', run, JSON.stringify(metrics).slice(0, 360));
}
async function waitDistinct(w: Agent, expected: number, stallMs = 30000, maxMs = 300000) {
  let last = -1, lc = Date.now(); const t0 = Date.now();
  for (;;) {
    const p = await w.call('progress');
    if (p.distinct >= expected) return true;
    if (p.distinct !== last) { last = p.distinct; lc = Date.now(); } else if (Date.now() - lc > stallMs) return false;
    if (Date.now() - t0 > maxMs) return false;
    await sleep(200);
  }
}
async function waitUp(kind: 'postgres' | 'redis', host: string, ms = 180000) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) {
    try {
      if (kind === 'redis') { const r = new Redis({ host, lazyConnect: true, maxRetriesPerRequest: 1, retryStrategy: () => null }); r.on('error', () => {}); await r.connect(); const ok = (await r.ping()) === 'PONG' && !(await r.info('persistence')).includes('loading:1'); r.disconnect(); if (ok) return Date.now() - t0; }
      else { const p = new Pool({ connectionString: PG_URL, max: 1 }); p.on('error', () => {}); await p.query('select 1'); await p.end(); return Date.now() - t0; }
    } catch {}
    await sleep(300);
  }
  throw new Error('service did not come back');
}
async function groupCounts(prod: Agent, runId: string) {
  const committed: number[] = (await dbpool.query('SELECT id FROM content_versions WHERE run=$1', [runId])).rows.map((r) => r.id);
  const jobs: number[] = await prod.call('reindexIds', { run: runId });
  const js = new Set(jobs), cs = new Set(committed);
  return { content_committed: committed.length, reindex_jobs: jobs.length, committed_without_job: committed.filter((x) => !js.has(x)).length, job_without_commit: jobs.filter((x) => !cs.has(x)).length };
}
async function startRelay(): Promise<Agent> { const r = await mk(OUTBOX); await r.call('relayStart', { batch: RELAY_BATCH, pollMs: POLL_MS }); return r; }
async function unsentZero(prod: Agent, ms = 60000) { const t0 = Date.now(); while (Date.now() - t0 < ms) { if ((await prod.call('unsent')) === 0) return Date.now() - t0; await sleep(50); } return -1; }

// S6a: crash before commit completes
async function S6a(stack: string, run: number) {
  const id = `s6a-${PASS}-${stack}-${run}-${Date.now()}`;
  const prod = await mk(stack); await prod.call('reset');
  const relay = stack === OUTBOX ? await startRelay() : null;
  const ctl = await prod.call('publish', { n: N_A, inject: false, run: id + '-ctl' });
  const inj = await prod.call('publish', { n: N_A, inject: true, run: id + '-inj' });
  let catchup = 0; if (relay) { catchup = await unsentZero(prod); await relay.call('relayStop'); await relay.dispose(); }
  record('S6a', stack, run, { injected: N_A, relay_catchup_ms: catchup, ctl: await groupCounts(prod, id + '-ctl'), inj: await groupCounts(prod, id + '-inj'), outbox_rows_unsent: stack === OUTBOX ? await prod.call('unsent') : null });
  await prod.dispose();
}
// S6b: crash (SIGKILL of the producer) right after COMMIT; then the relay catches up
async function S6b(stack: string, run: number) {
  const id = `s6b-${PASS}-${stack}-${run}-${Date.now()}`;
  const prod = await mk(stack); await prod.call('reset');
  let died = 0;
  for (let k = 0; k < N_B_KILLS; k++) {
    const a = await mk(stack);
    try { await a.call('publish', { n: 1, inject: false, run: id, killAfterCommit: true }, 60000); } catch { died++; }
    a.kill();
  }
  let catchup = 0, sent = 0;
  if (stack === OUTBOX) { const rl = await mk(OUTBOX); const r = await rl.call('relayDrain', { batch: RELAY_BATCH }); catchup = r.ms; sent = r.sent; await rl.dispose(); }
  record('S6b', stack, run, { kills_requested: N_B_KILLS, producers_died: died, relay_catchup_ms: catchup, relay_sent: sent, ...(await groupCounts(prod, id)) });
  await prod.dispose();
}
// S6c: relay killed between queue.add and marking sent (outbox only)
async function S6c(variant: 'worker-running' | 'worker-idle' | 'worker-running-keep-completed', run: number) {
  const keep = variant === 'worker-running-keep-completed';
  const cell = `${OUTBOX}/${variant}`; const id = `s6c-${PASS}-${variant}-${run}-${Date.now()}`;
  const prod = await mk(OUTBOX); await prod.call('reset');
  await prod.call('publish', { n: N_A, inject: false, run: id });
  const wk = await mk(OUTBOX, keep); if (variant !== 'worker-idle') await wk.call('workerStart', { conc: 10 });
  let killed = 0;
  for (let r = 0; r < C_ROUNDS; r++) {
    const a = await mk(OUTBOX, keep);
    try { await a.call('relayOnce', { batch: C_BATCH, killAfterAdd: true }, 60000); } catch { killed++; }
    a.kill();
    const b = await mk(OUTBOX, keep); await b.call('relayOnce', { batch: C_BATCH }); await b.dispose();   // restarted relay re-selects the same unsent rows and re-adds them
  }
  const d = await mk(OUTBOX, keep); await d.call('relayDrain', { batch: RELAY_BATCH }); await d.dispose();
  if (variant === 'worker-idle') await wk.call('workerStart', { conc: 10 });
  const complete = await waitDistinct(wk, N_A); await sleep(2500);
  const st = await wk.call('stats');
  record('S6c', cell, run, { relay_kills: killed, rounds: C_ROUNDS, rows: N_A, executed_distinct: st.distinct, executions_total: st.total, duplicate_executions: st.dups, lost: N_A - st.distinct, complete, outbox_not_done: await prod.call('notDone'), outbox_unsent: await prod.call('unsent') });
  await wk.dispose(); await prod.dispose();
}
// S6d: store wipe / restart with N_D jobs waiting
async function S6d(stack: string, run: number) {
  const id = `s6d-${PASS}-${stack}-${run}-${Date.now()}`;
  const prod = await mk(stack); await prod.call('reset');
  if (stack === OUTBOX) {
    const relay = await startRelay();
    await prod.call('publish', { n: N_D, inject: false, run: id });
    await unsentZero(prod); await relay.call('relayStop'); const before = await prod.call('pending');
    relay.kill(); prod.kill();
    await sh('docker', ['kill', '-s', 'KILL', CONTAINERS['redis-queue']]);
    await sh('docker', ['run', '--rm', '--entrypoint', 'sh', '-v', `${QUEUE_VOLUME}:/data`, REDIS_IMAGE, '-c', 'rm -rf /data/appendonlydir /data/*']);   // AOF deleted = total loss
    await sh('docker', ['start', CONTAINERS['redis-queue']]);
    const up = await waitUp('redis', 'redis-queue');
    const rc = await mk(OUTBOX); const survivors = await rc.call('pending');
    const t0 = Date.now(); const rec = await rc.call('reconcile'); const recMs = Date.now() - t0;
    await rc.call('workerStart', { conc: 10 }); const complete = await waitDistinct(rc, N_D); const fullMs = Date.now() - t0; await sleep(1500);
    const st = await rc.call('stats');
    record('S6d', stack, run, { jobs: N_D, waiting_before_wipe: before, survivors_after_wipe: survivors, lost_by_wipe: N_D - survivors, restart_ms: up, reconcile_rows: rec.rows, reconcile_enqueue_ms: recMs, reconcile_to_all_executed_ms: complete ? fullMs : null,
      recovered_and_executed: st.distinct, lost_after_reconcile: N_D - st.distinct, duplicate_executions: st.dups, complete, outbox_not_done_after: await rc.call('notDone') });
    await rc.dispose();
  } else {
    await prod.call('publish', { n: N_D, inject: false, run: id });
    const before = await prod.call('pending');
    await sh('docker', ['kill', '-s', 'KILL', CONTAINERS.postgres]); prod.kill();
    await sh('docker', ['start', CONTAINERS.postgres]);
    const up = await waitUp('postgres', 'postgres');
    const chk = await mk(stack); await chk.call('open'); const survivors = await chk.call('pending'); await chk.dispose();
    const committed = (await dbpool.query('SELECT count(*)::int n FROM content_versions WHERE run=$1', [id])).rows[0].n;
    const wk = await mk(stack); await wk.call('start', { conc: 50 });
    const complete = await waitDistinct(wk, survivors); await sleep(1500); const st = await wk.call('stats');
    record('S6d', stack, run, { jobs: N_D, waiting_before_kill: before, content_committed_after: committed, survivors_after_restart: survivors, lost_by_restart: N_D - survivors, restart_ms: up, reconcile_rows: 0, reconcile_enqueue_ms: 0, recovered_and_executed: st.distinct, lost_after_reconcile: N_D - st.distinct, duplicate_executions: st.dups, complete });
    await wk.dispose();
  }
}
// S6e: cost
async function S6e(stack: string, run: number) {
  const id = `s6e-${PASS}-${stack}-${run}-${Date.now()}`;
  let prod = await mk(stack); await prod.call('reset');
  const p1 = await prod.call('publish', { n: N_E, inject: false, run: id + '-a' });           // no relay / worker running
  await prod.dispose(); prod = await mk(stack); await prod.call('reset');
  const relay = stack === OUTBOX ? await startRelay() : null;
  const wk = await mk(stack); await wk.call(stack === OUTBOX ? 'workerStart' : 'start', { conc: 10 });
  await prod.call('publish', { n: N_E, inject: false, run: id + '-b' });
  const complete = await waitDistinct(wk, N_E); await sleep(1500);
  const st = await wk.call('stats'); const l = stack === OUTBOX ? st.lat : st.rlat;
  record('S6e', stack, run, { publish_ms_per_op: +(p1.ms / N_E).toFixed(3), latency_p50: l.p50, latency_p95: l.p95, latency_p99: l.p99, latency_n: l.n, executed: st.distinct, dups: st.dups, complete });
  if (relay) { await relay.call('relayStop'); await relay.dispose(); }
  await wk.dispose(); await prod.dispose();
}

(async () => {
  const env: any = { when: new Date().toISOString(), pass: PASS, order: ORDER, smoke: SMOKE,
    settings: { relay_poll_ms: POLL_MS, relay_batch: RELAY_BATCH, s6c_relay_batch: C_BATCH, s6c_rounds: C_ROUNDS, s6b_kills: N_B_KILLS, s6a_per_group: N_A, s6d_jobs: N_D, s6e_jobs: N_E, worker_concurrency_latency_test: 10, bullmq_jobId: 'outbox id', bullmq_removeOnComplete: true } };
  const r = new Redis({ host: 'redis-queue' }); env.redis_queue = {}; for (const k of ['maxmemory', 'maxmemory-policy', 'appendonly', 'appendfsync']) env.redis_queue[k] = ((await r.config('GET', k)) as string[])[1]; r.disconnect();
  env.postgres = {}; for (const k of ['fsync', 'synchronous_commit']) env.postgres[k] = (await dbpool.query(`show ${k}`)).rows[0][k];
  fs.writeFileSync(path.join(OUT, 'environment.json'), JSON.stringify(env, null, 2));
  const step = async (sc: string, cell: string, fn: (r: number) => Promise<void>) => {
    for (let r = 1; r <= RUNS; r++) {
      if (done.has(`${sc}|${cell}|${r}`)) continue;
      try { await fn(r); } catch (e: any) { log('ERROR', sc, cell, r, e.message); record(sc, cell, r, { harness_error: String(e.message).slice(0, 400) }); }
      await sleep(SMOKE ? 300 : 3000);
    }
  };
  for (const [sc, fn] of [['S6a', S6a], ['S6b', S6b]] as const) if (ONLY.includes(sc)) for (const s of ORDER) await step(sc, s, (r) => fn(s, r));
  if (ONLY.includes('S6c')) for (const v of ['worker-running', 'worker-idle', 'worker-running-keep-completed'] as const) await step('S6c', `${OUTBOX}/${v}`, (r) => S6c(v, r));
  if (ONLY.includes('S6d')) for (const s of ORDER) await step('S6d', s, (r) => S6d(s, r));
  if (ONLY.includes('S6e')) for (const s of ORDER) await step('S6e', s, (r) => S6e(s, r));
  log('ALL DONE'); process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
