// Child process used as producer or worker. Controlled by the orchestrator over IPC.
import { Pool } from 'pg';
import { Adapter, makeAdapter } from './adapters';
import { Job, PG_URL, StackName, pct, sleep } from './common';

let a: Adapter; let stack: StackName;
const seen: Record<string, Map<number, number>> = {};
const lat: number[] = []; const late: number[] = []; const rlat: number[] = [];
let total = 0, distinct = 0, lastEnd = 0, firstStart = 0, handlerErrors = 0, audioDone = 0;
function resetStats() { for (const k of Object.keys(seen)) delete seen[k]; lat.length = 0; late.length = 0; rlat.length = 0; total = distinct = lastEnd = firstStart = handlerErrors = audioDone = 0; }

async function handler(j: Job) {
  const st = Date.now();
  if (!firstStart) firstStart = st;
  try {
    const m = (seen[j.kind] ??= new Map());
    const c = (m.get(j.i) ?? 0) + 1; m.set(j.i, c); total++; if (c === 1) distinct++;
    if (j.kind === 'noop') lat.push(st - j.t);
    if (j.kind === 'reindex' && j.t) rlat.push(st - j.t);
    if (j.kind === 'delayed' && j.s) late.push(st - j.s);
    if (j.kind === 'audio') await sleep(200);
    if (j.kind === 'audio') audioDone++;
  } catch { handlerErrors++; throw new Error('handler'); }
  lastEnd = Date.now();
}

const H: Record<string, (x: any) => Promise<any>> = {
  async init({ stack: s }) { stack = s; a = makeAdapter(s); },
  async reset() { await a.reset(); },
  async open() { await a.open(); },
  async enqueueGen({ kind, count, start = 0, chunk = 1000, s, pad }) {
    const t0 = Date.now(); let ok = 0, failed = 0; const errs = new Set<string>();
    for (let o = 0; o < count; o += chunk) {
      const n = Math.min(chunk, count - o); const t = Date.now();
      const jobs: Job[] = Array.from({ length: n }, (_, k) => ({ kind, i: start + o + k, t, ...(s ? { s } : {}), ...(pad ? { pad: 'x'.repeat(pad) } : {}) }));
      try { await a.enqueue(jobs); ok += n; } catch (e: any) { failed += n; errs.add(String(e?.message).slice(0, 140)); }
    }
    return { ms: Date.now() - t0, ok, failed, errs: [...errs] };
  },
  async start({ conc }) { resetStats(); await a.startWorker(conc, handler); },
  async progress() { return { distinct, total, lastEnd, handlerErrors }; },
  async stats() {
    const kinds: Record<string, number> = {}; let dups = 0;
    for (const [k, m] of Object.entries(seen)) { kinds[k] = m.size; for (const c of m.values()) dups += c - 1; }
    return {
      distinct, total, dups, kinds, firstStart, lastEnd, handlerErrors, audioDone, lib: a.lib,
      lat: { p50: pct(lat, 50), p95: pct(lat, 95), p99: pct(lat, 99), n: lat.length },
      rlat: { p50: pct(rlat, 50), p95: pct(rlat, 95), p99: pct(rlat, 99), n: rlat.length },
      late: { p50: pct(late, 50), p95: pct(late, 95), p99: pct(late, 99), n: late.length },
    };
  },
  async stop() { await a.stopWorker(); },
  async pending() { return a.pending(); },
  async failed() { return a.failed(); },
  async close() { await a.close(); },

  // S5: "publish a content version" = DB change + reindex-job enqueue
  async publish({ n, inject, run, kill, killAfterCommit }) {
    const pool = new Pool({ connectionString: PG_URL, max: 4 });
    await a.open();
    let crashed = 0, ok = 0; const t0 = Date.now();
    for (let i = 0; i < n; i++) {
      const c = await pool.connect();
      try {
        await c.query('BEGIN');
        const r = await c.query('INSERT INTO content_versions(run,content_id,version) VALUES($1,$2,1) RETURNING id', [run, i]);
        const job: Job = { kind: 'reindex', i, t: Date.now(), cv: r.rows[0].id, run };
        if (a.enqueueInTx) {
          await a.enqueueInTx(c, job);                       // enqueue inside the same transaction
          if (inject) { if (kill) process.kill(process.pid, 'SIGKILL'); crashed++; c.release(true); continue; } // crash before COMMIT
          await c.query('COMMIT');
          if (killAfterCommit) process.kill(process.pid, 'SIGKILL');
        } else {
          await c.query('COMMIT');                           // BullMQ: DB commit first ...
          if (inject) { if (kill) process.kill(process.pid, 'SIGKILL'); crashed++; c.release(); continue; } // ... crash before enqueue
          await a.enqueue([job]);
        }
        ok++; c.release();
      } catch (e) { try { c.release(true); } catch {} throw e; }
    }
    await pool.end();
    return { ms: Date.now() - t0, crashed, ok };
  },
  async reindexIds({ run }) { return a.reindexIds(run); },
};

process.on('message', async (m: any) => {
  try { const r = await H[m.cmd](m.args ?? {}); process.send!({ id: m.id, ok: true, r }); }
  catch (e: any) { process.send!({ id: m.id, ok: false, err: String(e?.stack ?? e) }); }
});
process.send!({ ready: true });
