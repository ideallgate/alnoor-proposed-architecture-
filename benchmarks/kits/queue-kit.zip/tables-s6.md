## S6 pass 1

### S6a crash before commit completes (totals over runs; ctl = 1,000 normal publishes per run, inj = 1,000 injected crashes per run)

| stack | runs | injected crashes | content committed (inj) | committed w/o job (inj) | job w/o content (inj) | control: committed | control: jobs | control: committed w/o job | harness err |
|---|---|---|---|---|---|---|---|---|---|
| bullmq-dedicated-outbox | 5 | 5000 | 0 | 0 | 0 | 5000 | 5000 | 0 | 0 |
| pg-boss | 5 | 5000 | 0 | 0 | 0 | 5000 | 5000 | 0 | 0 |
| graphile-worker | 5 | 5000 | 0 | 0 | 0 | 5000 | 5000 | 0 | 0 |

### S6b producer SIGKILL right after COMMIT (50 kills per run), then relay catches up (totals over runs)

| stack | runs | producers killed | content committed | jobs present | committed w/o job | job w/o content | relay catch-up ms (median) | harness err |
|---|---|---|---|---|---|---|---|---|
| bullmq-dedicated-outbox | 5 | 250 | 250 | 250 | 0 | 0 | 17 | 0 |
| pg-boss | 5 | 250 | 250 | 250 | 0 | 0 | - | 0 |
| graphile-worker | 5 | 250 | 250 | 250 | 0 | 0 | - | 0 |

### S6c relay killed between queue.add and marking sent (100 kills per run, 1,000 rows per run; totals over runs)

| variant | runs | relay kills | rows | distinct executed | total executions | duplicate executions | lost | rows still not done | harness err |
|---|---|---|---|---|---|---|---|---|---|
| worker-running | 5 | 500 | 5000 | 5000 | 10000 | 5000 | 0 | 0 | 0 |
| worker-idle | 5 | 500 | 5000 | 5000 | 5000 | 0 | 0 | 0 | 0 |
| worker-running-keep-completed | 5 | 500 | 5000 | 5000 | 5000 | 0 | 0 | 0 | 0 |

### S6d store loss with 5,000 jobs waiting (medians; lost columns also summed over runs)

| stack | runs | jobs found after wipe/restart (median) | lost by wipe/restart (sum) | recovered+executed after reconciliation (median) | lost after reconciliation (sum) | duplicate executions (sum) | store restart ms | reconcile enqueue ms | reconcile -> all executed ms | harness err |
|---|---|---|---|---|---|---|---|---|---|---|
| bullmq-dedicated-outbox | 5 | 0 | 25000 | 5,000 | 0 | 0 | 321 | 215 | 1,025 | 0 |
| pg-boss | 5 | 5,000 | 0 | 5,000 | 0 | 0 | 323 | n/a | n/a | 0 |
| graphile-worker | 5 | 5,000 | 0 | 5,000 | 0 | 0 | 323 | n/a | n/a | 0 |

### S6e cost (medians of runs; 1,000 publishes per run; latency = commit/enqueue timestamp to job start, 10 workers)

| stack | runs | publish ms/op (no relay/worker) | latency p50 ms | p95 | p99 | dups | harness err |
|---|---|---|---|---|---|---|---|
| bullmq-dedicated-outbox | 5 | 0.39 | 2 | 98 | 104 | 0 | 0 |
| pg-boss | 5 | 0.84 | 1,711 | 1,973 | 2,000 | 0 | 0 |
| graphile-worker | 5 | 0.67 | 1 | 2 | 7 | 0 | 0 |

## S6 pass 2

### S6a crash before commit completes (totals over runs; ctl = 1,000 normal publishes per run, inj = 1,000 injected crashes per run)

| stack | runs | injected crashes | content committed (inj) | committed w/o job (inj) | job w/o content (inj) | control: committed | control: jobs | control: committed w/o job | harness err |
|---|---|---|---|---|---|---|---|---|---|
| bullmq-dedicated-outbox | 5 | 5000 | 0 | 0 | 0 | 5000 | 5000 | 0 | 0 |
| pg-boss | 5 | 5000 | 0 | 0 | 0 | 5000 | 5000 | 0 | 0 |
| graphile-worker | 5 | 5000 | 0 | 0 | 0 | 5000 | 5000 | 0 | 0 |

### S6b producer SIGKILL right after COMMIT (50 kills per run), then relay catches up (totals over runs)

| stack | runs | producers killed | content committed | jobs present | committed w/o job | job w/o content | relay catch-up ms (median) | harness err |
|---|---|---|---|---|---|---|---|---|
| bullmq-dedicated-outbox | 5 | 250 | 250 | 250 | 0 | 0 | 19 | 0 |
| pg-boss | 5 | 250 | 250 | 250 | 0 | 0 | - | 0 |
| graphile-worker | 5 | 250 | 250 | 250 | 0 | 0 | - | 0 |

### S6c relay killed between queue.add and marking sent (100 kills per run, 1,000 rows per run; totals over runs)

| variant | runs | relay kills | rows | distinct executed | total executions | duplicate executions | lost | rows still not done | harness err |
|---|---|---|---|---|---|---|---|---|---|
| worker-running | 5 | 500 | 5000 | 5000 | 10000 | 5000 | 0 | 0 | 0 |
| worker-idle | 5 | 500 | 5000 | 5000 | 5000 | 0 | 0 | 0 | 0 |
| worker-running-keep-completed | 5 | 500 | 5000 | 5000 | 5000 | 0 | 0 | 0 | 0 |

### S6d store loss with 5,000 jobs waiting (medians; lost columns also summed over runs)

| stack | runs | jobs found after wipe/restart (median) | lost by wipe/restart (sum) | recovered+executed after reconciliation (median) | lost after reconciliation (sum) | duplicate executions (sum) | store restart ms | reconcile enqueue ms | reconcile -> all executed ms | harness err |
|---|---|---|---|---|---|---|---|---|---|---|
| bullmq-dedicated-outbox | 5 | 0 | 25000 | 5,000 | 0 | 0 | 326 | 232 | 1,046 | 0 |
| pg-boss | 5 | 5,000 | 0 | 5,000 | 0 | 0 | 330 | n/a | n/a | 0 |
| graphile-worker | 5 | 5,000 | 0 | 5,000 | 0 | 0 | 334 | n/a | n/a | 0 |

### S6e cost (medians of runs; 1,000 publishes per run; latency = commit/enqueue timestamp to job start, 10 workers)

| stack | runs | publish ms/op (no relay/worker) | latency p50 ms | p95 | p99 | dups | harness err |
|---|---|---|---|---|---|---|---|
| bullmq-dedicated-outbox | 5 | 0.41 | 50 | 103 | 111 | 0 | 0 |
| pg-boss | 5 | 0.83 | 1,710 | 1,984 | 2,000 | 0 | 0 |
| graphile-worker | 5 | 0.74 | 1 | 2 | 8 | 0 | 0 |

