CREATE TABLE rawi (id serial PRIMARY KEY, name text, tabaqa text, bio text);
CREATE TABLE hadith (id serial PRIMARY KEY, book_id int, chapter_id int, number int, status text DEFAULT 'published');
CREATE TABLE riwaya (id serial PRIMARY KEY, hadith_id int REFERENCES hadith(id), source text, grade text, text_ar text, is_default bool, rawi_id int REFERENCES rawi(id));
INSERT INTO rawi SELECT g, 'Rawi '||g, 'Tabaqa '||(g%12), repeat('bio ',40) FROM generate_series(1,3000) g;
INSERT INTO hadith SELECT g, g%20, g%400, g, 'published' FROM generate_series(1,20000) g;
INSERT INTO riwaya (hadith_id,source,grade,text_ar,is_default,rawi_id)
SELECT h, 'Source '||(r), 'Sahih', repeat('حَدَّثَنَا عَبْدُ اللَّهِ ',12), r=1, (h*7+r)%3000+1 FROM generate_series(1,20000) h, generate_series(1,3) r;
CREATE INDEX ON riwaya(hadith_id);
CREATE TABLE content_versions (id serial PRIMARY KEY, run text NOT NULL, content_id int NOT NULL, version int NOT NULL, created_at timestamptz DEFAULT now());
CREATE INDEX ON content_versions(run);
ANALYZE;
